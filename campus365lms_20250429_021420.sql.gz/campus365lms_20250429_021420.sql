-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: campus365lms
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about_us`
--

DROP TABLE IF EXISTS `about_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about_us` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_desc` text COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `features` longtext COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `video_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mission_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mission_desc` text COLLATE utf8mb4_unicode_ci,
  `mission_icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mission_image` text COLLATE utf8mb4_unicode_ci,
  `vision_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vision_desc` text COLLATE utf8mb4_unicode_ci,
  `vision_icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vision_image` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about_us`
--

LOCK TABLES `about_us` WRITE;
/*!40000 ALTER TABLE `about_us` DISABLE KEYS */;
INSERT INTO `about_us` VALUES (1,1,'About Our University','A Few Words About the University',NULL,'<p>Our community is being called to reimagine the future. As the only university where a renowned design school comes together with premier colleges, we are making learning more relevant and transformational.<br /><br />We are proud to offer top ranige in employment services such and asser payroll and benefits administrato managemen and asistance with global business range ployment employer readings from religious texts or literature are also commonly inc compliance.</p>','null','about_img_05_1692915465.png',NULL,NULL,'Our Mission','<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable.</p>',NULL,NULL,'Our Vision','<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable.</p>',NULL,NULL,1,'2023-08-24 16:17:46','2023-08-24 16:17:46');
/*!40000 ALTER TABLE `about_us` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_settings`
--

DROP TABLE IF EXISTS `application_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `header_left` text COLLATE utf8mb4_unicode_ci,
  `header_center` text COLLATE utf8mb4_unicode_ci,
  `header_right` text COLLATE utf8mb4_unicode_ci,
  `body` text COLLATE utf8mb4_unicode_ci,
  `footer_left` text COLLATE utf8mb4_unicode_ci,
  `footer_center` text COLLATE utf8mb4_unicode_ci,
  `footer_right` text COLLATE utf8mb4_unicode_ci,
  `logo_left` text COLLATE utf8mb4_unicode_ci,
  `logo_right` text COLLATE utf8mb4_unicode_ci,
  `background` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `application_settings_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_settings`
--

LOCK TABLES `application_settings` WRITE;
/*!40000 ALTER TABLE `application_settings` DISABLE KEYS */;
INSERT INTO `application_settings` VALUES (1,'admission','Apply to admission on our university',NULL,NULL,NULL,'<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\',</p>',NULL,NULL,NULL,'campus_365_(1)_1716408466.png','campus_365_(1)_1716408466.png',NULL,1,'2023-02-13 11:05:47','2024-05-22 14:07:46');
/*!40000 ALTER TABLE `application_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `registration_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `apply_date` date DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father_occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father_photo` text COLLATE utf8mb4_unicode_ci,
  `mother_photo` text COLLATE utf8mb4_unicode_ci,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `present_province` int(10) unsigned DEFAULT NULL,
  `present_district` int(10) unsigned DEFAULT NULL,
  `present_village` text COLLATE utf8mb4_unicode_ci,
  `present_address` text COLLATE utf8mb4_unicode_ci,
  `permanent_province` int(10) unsigned DEFAULT NULL,
  `permanent_district` int(10) unsigned DEFAULT NULL,
  `permanent_village` text COLLATE utf8mb4_unicode_ci,
  `permanent_address` text COLLATE utf8mb4_unicode_ci,
  `gender` int(11) NOT NULL COMMENT '1 Male, 2 Female & 3 Other',
  `dob` date NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `religion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caste` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_tongue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` int(11) DEFAULT NULL,
  `blood_group` int(11) DEFAULT NULL,
  `nationality` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `national_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_name` text COLLATE utf8mb4_unicode_ci,
  `school_exam_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_graduation_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_graduation_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_graduation_point` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collage_name` text COLLATE utf8mb4_unicode_ci,
  `collage_exam_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collage_graduation_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collage_graduation_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collage_graduation_point` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` text COLLATE utf8mb4_unicode_ci,
  `signature` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Rejected, 1 Pending, 2 Approve',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `applications_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (1,'10000001',NULL,4,'2023-02-13','Judah','Bryant','Ira Preston','Reuben Cooper','Explicabo Reiciendi','Earum aliquid vel au',NULL,NULL,NULL,2,7,NULL,'Hic rem consequat A',4,12,NULL,'Corrupti sapiente l',2,'1982-02-08','haca@mailinator.com','+1 (366) 959-1883',NULL,NULL,NULL,NULL,1,5,NULL,'21879584857','878454545454','Penelope Mack','5487854',NULL,'2004','99.3','Genevieve Hammond','6787877',NULL,'2006','78.8','staff1_1664732856_1676308260.jpg','book_covers.jpg_1664732856_1676308260.jpg',1,1,NULL,'2023-02-13 11:11:00','2023-02-13 11:11:00'),(2,'10000002',NULL,2,'2023-02-13','Jerome','Sellers','Laurel Evans','Carlos Hess','Id explicabo Repel','Adipisicing reiciend',NULL,NULL,NULL,3,11,NULL,'Eius duis debitis no',2,7,NULL,'Quasi magna id dolo',1,'1998-01-21','loxut@mailinator.com','+1 (431) 155-5046',NULL,NULL,NULL,NULL,2,4,NULL,'878654548','258897878','Dorian Cortez','356897',NULL,'2009','68.3','Tobias Love','899564',NULL,'2010','67.8','staff2_1664711842_1676308347.jpg','book_cover2.jpg_1664711842_1676308347.jpg',0,1,1,'2023-02-13 11:12:27','2023-02-13 11:14:39');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assigned_courses`
--

DROP TABLE IF EXISTS `assigned_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assigned_courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assigned_courses_teacher_id_foreign` (`teacher_id`),
  KEY `assigned_courses_subject_id_foreign` (`subject_id`),
  KEY `assigned_courses_session_id_foreign` (`session_id`),
  KEY `assigned_courses_program_id_foreign` (`program_id`),
  KEY `assigned_courses_semester_id_foreign` (`semester_id`),
  KEY `assigned_courses_section_id_foreign` (`section_id`),
  CONSTRAINT `assigned_courses_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assigned_courses_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assigned_courses_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assigned_courses_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assigned_courses_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assigned_courses_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assigned_courses`
--

LOCK TABLES `assigned_courses` WRITE;
/*!40000 ALTER TABLE `assigned_courses` DISABLE KEYS */;
INSERT INTO `assigned_courses` VALUES (1,3,9,2,1,1,1,1,'2025-04-25 17:43:46','2025-04-25 17:43:46'),(2,4,1,2,1,1,1,1,'2025-04-25 17:43:46','2025-04-25 17:43:46'),(3,5,2,2,1,1,1,1,'2025-04-25 17:43:46','2025-04-25 17:43:46'),(4,7,3,2,1,1,1,1,'2025-04-25 17:44:06','2025-04-25 17:44:06'),(5,3,8,2,1,1,1,1,'2025-04-25 17:44:06','2025-04-25 17:44:06'),(6,3,8,2,1,1,2,1,'2025-04-25 17:44:23','2025-04-25 17:44:23');
/*!40000 ALTER TABLE `assigned_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `semester_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `total_marks` decimal(5,2) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `assign_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assignments_subject_id_foreign` (`subject_id`),
  KEY `assignments_assign_by_foreign` (`assign_by`),
  CONSTRAINT `assignments_assign_by_foreign` FOREIGN KEY (`assign_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assignments_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments`
--

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
INSERT INTO `assignments` VALUES (1,1,1,2,1,0,9,'FFADDGF','<p>sdfsdfszf</p>',20.00,'2025-04-12','2025-04-12',NULL,1,3,'2025-04-12 12:27:50','2025-04-12 12:27:50');
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_program`
--

DROP TABLE IF EXISTS `batch_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_program` (
  `batch_id` int(10) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  KEY `batch_program_batch_id_foreign` (`batch_id`),
  KEY `batch_program_program_id_foreign` (`program_id`),
  CONSTRAINT `batch_program_batch_id_foreign` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `batch_program_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_program`
--

LOCK TABLES `batch_program` WRITE;
/*!40000 ALTER TABLE `batch_program` DISABLE KEYS */;
INSERT INTO `batch_program` VALUES (1,2),(2,2),(3,1),(4,1),(5,3),(6,3);
/*!40000 ALTER TABLE `batch_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batches`
--

DROP TABLE IF EXISTS `batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `batches_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batches`
--

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
INSERT INTO `batches` VALUES (1,'28th Batch','2024-01-01',1,'2025-04-03 03:11:14','2025-04-03 03:12:39'),(2,'29th Batch','2025-01-01',1,'2025-04-03 03:11:43','2025-04-03 03:12:52'),(3,'40th Batch','2024-01-01',1,'2025-04-03 03:14:39','2025-04-03 03:14:39'),(4,'41st Batch','2025-01-03',1,'2025-04-03 03:15:07','2025-04-03 03:15:07'),(5,'15th Batch','2025-01-01',1,'2025-04-03 03:15:48','2025-04-03 03:15:48'),(6,'16th Batch','2025-04-01',1,'2025-04-03 03:16:04','2025-04-03 03:16:04');
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_categories`
--

DROP TABLE IF EXISTS `book_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `book_categories_title_unique` (`title`),
  UNIQUE KEY `book_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_categories`
--

LOCK TABLES `book_categories` WRITE;
/*!40000 ALTER TABLE `book_categories` DISABLE KEYS */;
INSERT INTO `book_categories` VALUES (1,'Fiction Books','fiction-books',NULL,1,'2022-09-30 14:13:20','2022-09-30 14:13:20'),(2,'Crime & Mystery','crime-mystery',NULL,1,'2022-09-30 14:13:35','2022-09-30 14:13:35'),(3,'History','history',NULL,1,'2022-09-30 14:13:50','2022-09-30 14:13:50'),(4,'Magazine','magazine',NULL,1,'2022-09-30 14:14:12','2022-09-30 14:14:12');
/*!40000 ALTER TABLE `book_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_requests`
--

DROP TABLE IF EXISTS `book_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isbn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publisher` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edition` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `request_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Rejected, 1 Pending, 2 Progress, 3 Approved',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `book_requests_category_id_foreign` (`category_id`),
  CONSTRAINT `book_requests_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `book_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_requests`
--

LOCK TABLES `book_requests` WRITE;
/*!40000 ALTER TABLE `book_requests` DISABLE KEYS */;
INSERT INTO `book_requests` VALUES (1,1,'Repudiandae sunt qu',NULL,NULL,'Nostrud provident e','Voluptatum sit exped','Quia consectetur est','1990','Quas et impedit vol',NULL,421,'Rafael Britt','+1 (695) 757-2712','nunanavy@mailinator.com','Asperiores elit ill','Reprehenderit illum',NULL,1,1,NULL,'2023-02-13 12:11:02','2023-02-13 12:11:02'),(2,2,'Quos asperiores ut a',NULL,NULL,'Voluptate quia dolor','Doloribus reprehende','Anim eius ratione qu','2010','Dolor tenetur exerci',NULL,324,'Caldwell Stanton','+1 (877) 683-7177','norigaruzy@mailinator.com','Harum dicta sint et','Tempor doloremque do',NULL,1,1,NULL,'2023-02-13 12:11:18','2023-02-13 12:11:18');
/*!40000 ALTER TABLE `book_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isbn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publisher` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edition` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `section` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `column` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Lost, 1 Available, 2 Damage',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `books_isbn_unique` (`isbn`),
  UNIQUE KEY `books_code_unique` (`code`),
  KEY `books_category_id_foreign` (`category_id`),
  CONSTRAINT `books_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `book_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,3,'Corporis laboriosam','978-3-16-148410-0',NULL,'Devid','Iure quis est imped','Enim id voluptas del','1970','English',36.00,132,'17','5','2','Dolor qui veritatis','Consectetur molestia',NULL,1,1,1,'2022-10-01 12:38:52','2022-10-27 13:26:56'),(2,3,'Voluptatibus volupta','1-56619-909-3',NULL,'Jeff','Harum ad placeat es','Repellendus Et recu','1978','English',10.00,702,'47','8','18','Et eiusmod animi si','Assumenda pariatur','book-cover2_1664653683.jpg',1,1,1,'2022-10-01 12:41:00','2022-10-27 13:26:39'),(3,1,'Quod sed sed in in e','978-3-16-146347-5',NULL,'Alex','Tempora earum adipis','Eiusmod enim consequ','1987','English',14.00,385,'7','78','52','Fuga Optio ea offi','In consectetur ea om',NULL,1,1,1,'2022-10-01 12:45:56','2022-10-27 13:26:28'),(4,4,'Et qui aut nisi do a','978-3-16-785410-9',NULL,'Arman','Assumenda architecto','Ea aute excepturi eu','1981','English',10.00,349,'78','01','14','Vel nisi ut et rem q','Voluptas ea suscipit',NULL,1,1,1,'2022-10-01 13:07:42','2022-10-27 13:26:11'),(5,2,'A Story of Your Childhood','1-566147-548-7',NULL,'Saif','Rerum ab eum esse s','Dicta ut quaerat eaq','2000','English',17.00,435,'17','77','47','Unde voluptatem ut u','Sequi veniam non se',NULL,1,1,1,'2022-10-01 13:10:51','2022-10-27 13:26:01'),(6,1,'Et sequi sit obcaeca','1-254147-457-9',NULL,'Arman','Itaque ut in odio es','Eu cupidatat rem ips','1982','English',45.00,758,'77','14','23','Quae irure aut conse','Numquam mollit aliqu','book-covers_1664653539.jpg',1,1,1,'2022-10-01 13:45:39','2022-10-27 13:25:51');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_to_actions`
--

DROP TABLE IF EXISTS `call_to_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `call_to_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_title` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `bg_image` text COLLATE utf8mb4_unicode_ci,
  `button_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_to_actions`
--

LOCK TABLES `call_to_actions` WRITE;
/*!40000 ALTER TABLE `call_to_actions` DISABLE KEYS */;
INSERT INTO `call_to_actions` VALUES (1,1,'Scholarship Programs','At Campus365, we prepare you to launch your career by providing a supportive, creative, and professional environment from which to learn practical skills and build a network of industry contacts.',NULL,NULL,'Campus365','https://www.campus365.pro/',NULL,1,'2023-08-24 16:01:48','2024-05-22 14:14:59');
/*!40000 ALTER TABLE `call_to_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificate_templates`
--

DROP TABLE IF EXISTS `certificate_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificate_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_left` text COLLATE utf8mb4_unicode_ci,
  `header_center` text COLLATE utf8mb4_unicode_ci,
  `header_right` text COLLATE utf8mb4_unicode_ci,
  `body` text COLLATE utf8mb4_unicode_ci,
  `footer_left` text COLLATE utf8mb4_unicode_ci,
  `footer_center` text COLLATE utf8mb4_unicode_ci,
  `footer_right` text COLLATE utf8mb4_unicode_ci,
  `logo_left` text COLLATE utf8mb4_unicode_ci,
  `logo_right` text COLLATE utf8mb4_unicode_ci,
  `background` text COLLATE utf8mb4_unicode_ci,
  `width` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `height` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `student_photo` tinyint(1) NOT NULL DEFAULT '0',
  `barcode` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `certificate_templates_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate_templates`
--

LOCK TABLES `certificate_templates` WRITE;
/*!40000 ALTER TABLE `certificate_templates` DISABLE KEYS */;
INSERT INTO `certificate_templates` VALUES (1,'Provisional Certificate',NULL,NULL,NULL,'This is to certify that  [first_name] [last_name] son / daughter of  [father_name] and [mother_name] passed [program] degree under [faculty] examination of the university held in [ending_year]. And that he/she was placed [cgpa] with grade of [grade]. \r\n\r\nHe/She completed the course of  [credits] credits and all of the requirements for the award of the Bachelor\'s degree.','Controller','Director','Register','logo_1664614758.jpg',NULL,'background-border_1664614748.png','800px','auto',1,1,1,'2022-10-01 02:56:19','2022-10-02 16:11:17'),(2,'Transfer Certificate',NULL,NULL,NULL,'This is to certify that  [first_name] [last_name] son / daughter of  [father_name] and [mother_name] passed [program] degree under [faculty] examination of the university held in [ending_year]. And that he/she was placed [cgpa] with grade of [grade]. \r\n\r\nHe/She completed the course of  [credits] credits and all of the requirements for the award of the Bachelor\'s degree.','Controller','Director','Register','logo_1664614963.jpg',NULL,'background-border_1664614963.png','800px','auto',1,0,1,'2022-10-01 03:02:43','2022-10-02 16:11:27');
/*!40000 ALTER TABLE `certificate_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `template_id` int(10) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  `serial_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `starting_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ending_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credits` decimal(5,2) NOT NULL,
  `point` decimal(5,2) NOT NULL,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `certificates_template_id_foreign` (`template_id`),
  KEY `certificates_student_id_foreign` (`student_id`),
  CONSTRAINT `certificates_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `certificates_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `certificate_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates`
--

LOCK TABLES `certificates` WRITE;
/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_rooms`
--

DROP TABLE IF EXISTS `class_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `floor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `class_rooms_title_unique` (`title`),
  UNIQUE KEY `class_rooms_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_rooms`
--

LOCK TABLES `class_rooms` WRITE;
/*!40000 ALTER TABLE `class_rooms` DISABLE KEYS */;
INSERT INTO `class_rooms` VALUES (1,'101','101','Social Science Building',NULL,NULL,NULL,1,'2025-04-11 12:49:16','2025-04-11 12:49:16'),(2,'102','102','Social Science Building',NULL,NULL,NULL,1,'2025-04-11 12:49:29','2025-04-11 12:49:29'),(3,'103','103','Social Science Building',NULL,NULL,NULL,1,'2025-04-11 12:49:35','2025-04-11 12:49:35'),(4,'104','104','Social Science Building',NULL,NULL,NULL,1,'2025-04-11 12:49:42','2025-04-11 12:49:42');
/*!40000 ALTER TABLE `class_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_routines`
--

DROP TABLE IF EXISTS `class_routines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_routines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `room_id` int(10) unsigned NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `day` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `class_routines_teacher_id_foreign` (`teacher_id`),
  KEY `class_routines_subject_id_foreign` (`subject_id`),
  KEY `class_routines_room_id_foreign` (`room_id`),
  KEY `class_routines_session_id_foreign` (`session_id`),
  KEY `class_routines_program_id_foreign` (`program_id`),
  KEY `class_routines_semester_id_foreign` (`semester_id`),
  KEY `class_routines_section_id_foreign` (`section_id`),
  CONSTRAINT `class_routines_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_routines_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `class_rooms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_routines_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_routines_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_routines_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_routines_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_routines_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_routines`
--

LOCK TABLES `class_routines` WRITE;
/*!40000 ALTER TABLE `class_routines` DISABLE KEYS */;
INSERT INTO `class_routines` VALUES (1,3,9,2,2,1,1,1,'08:00:00','09:30:00',1,1,'2025-04-11 12:52:09','2025-04-25 17:43:46'),(2,4,1,1,2,1,1,1,'10:00:00','11:30:00',1,1,'2025-04-11 12:52:09','2025-04-11 12:52:09'),(3,5,2,2,2,1,1,1,'12:00:00','13:30:00',1,1,'2025-04-11 12:52:09','2025-04-11 12:52:09'),(4,7,3,1,2,1,1,1,'08:30:00','10:00:00',2,1,'2025-04-11 12:55:11','2025-04-11 12:55:11'),(5,3,8,1,2,1,1,1,'10:30:00','12:00:00',2,1,'2025-04-11 12:55:12','2025-04-11 12:55:12'),(6,3,9,1,2,1,1,1,'01:27:00','01:27:00',3,1,'2025-04-20 13:28:01','2025-04-20 13:28:01'),(7,3,8,1,2,1,1,2,'01:34:00','01:34:00',1,1,'2025-04-20 13:34:39','2025-04-20 13:34:39');
/*!40000 ALTER TABLE `class_routines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complain_sources`
--

DROP TABLE IF EXISTS `complain_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complain_sources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `complain_sources_title_unique` (`title`),
  UNIQUE KEY `complain_sources_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complain_sources`
--

LOCK TABLES `complain_sources` WRITE;
/*!40000 ALTER TABLE `complain_sources` DISABLE KEYS */;
INSERT INTO `complain_sources` VALUES (1,'Staff','staff',NULL,1,'2022-10-01 03:56:33','2022-10-01 03:56:33'),(2,'Student','student',NULL,1,'2022-10-01 03:56:40','2022-10-01 03:56:40'),(3,'Parent','parent',NULL,1,'2022-10-01 03:56:47','2022-10-01 03:56:47'),(4,'Teacher','teacher',NULL,1,'2022-10-01 03:56:58','2022-10-01 03:56:58');
/*!40000 ALTER TABLE `complain_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complain_types`
--

DROP TABLE IF EXISTS `complain_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complain_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `complain_types_title_unique` (`title`),
  UNIQUE KEY `complain_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complain_types`
--

LOCK TABLES `complain_types` WRITE;
/*!40000 ALTER TABLE `complain_types` DISABLE KEYS */;
INSERT INTO `complain_types` VALUES (1,'Fees','fees',NULL,1,'2022-10-01 03:53:14','2022-10-01 03:53:14'),(2,'Study','study',NULL,1,'2022-10-01 03:53:29','2022-10-01 03:53:29'),(3,'Teacher','teacher',NULL,1,'2022-10-01 03:53:37','2022-10-01 03:53:37'),(4,'Sports','sports',NULL,1,'2022-10-01 03:53:42','2022-10-01 03:53:42'),(5,'Transport','transport',NULL,1,'2022-10-01 03:53:51','2022-10-01 03:53:51'),(6,'Hostel','hostel',NULL,1,'2022-10-01 03:54:00','2022-10-01 03:54:00'),(7,'Instrument','instrument',NULL,1,'2022-10-01 03:54:55','2022-10-01 03:54:55'),(8,'Exam','exam',NULL,1,'2022-10-01 03:55:27','2022-10-01 03:55:27'),(9,'Library','library',NULL,1,'2022-10-01 03:55:41','2022-10-01 03:55:41');
/*!40000 ALTER TABLE `complain_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complains`
--

DROP TABLE IF EXISTS `complains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complains` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `source_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `action_taken` text COLLATE utf8mb4_unicode_ci,
  `assigned` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issue` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complains_type_id_foreign` (`type_id`),
  KEY `complains_source_id_foreign` (`source_id`),
  CONSTRAINT `complains_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `complain_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complains`
--

LOCK TABLES `complains` WRITE;
/*!40000 ALTER TABLE `complains` DISABLE KEYS */;
INSERT INTO `complains` VALUES (1,7,2,'Alika Lucas','Velma Flores','+1 (919) 213-5151','firutesygi@mailinator.com','2021-02-13','Ordered','Liz','Amet velit accusant','Fuga Aliqua Molest',NULL,1,1,1,'2022-10-01 12:29:41','2022-10-27 13:29:43'),(2,9,3,'Beverly Rich','Alyssa Pitts','+1 (904) 655-2551','cidynyb@mailinator.com','2020-08-02','Solved','Saif','Commodo corporis ips','Ullamco cupidatat qu','book-cover2_1664656121.jpg',1,1,1,'2022-10-01 12:30:16','2022-10-27 13:29:18'),(3,3,1,'Constance Stephens','Colorado Knight','+1 (842) 238-6678','vavomul@mailinator.com','2022-06-22','Suspend','8','Eligendi totam quis','Quia est ut amet vo',NULL,0,1,1,'2022-10-01 12:30:38','2023-02-13 12:27:14'),(4,5,2,'Ezekiel Hooper','Mollie Browning','+1 (859) 183-6191','furus@mailinator.com','2020-03-23','Change','Alex','Iusto laboris ipsa','Delectus ex accusam',NULL,1,1,1,'2022-10-01 12:31:10','2022-10-27 13:28:34'),(5,9,1,'Kaden Reyes','Ruth Petty','+1 (293) 256-2963','tabyxuge@mailinator.com','2020-02-03','Solved','Andre','Saepe rerum nulla co','Aut sunt sunt ea qua','book-covers_1664656151.jpg',1,1,1,'2022-10-01 12:31:21','2022-10-27 13:28:21'),(6,5,3,'Barry Hull','Travis Fuller','+1 (561) 218-6774','weripazu@mailinator.com','2022-12-03',NULL,'9','Perferendis necessit','Autem quibusdam aut',NULL,0,1,1,'2023-02-13 12:27:46','2023-08-25 07:33:40'),(7,3,3,'Yuri Prince','Winifred Key','+1 (419) 319-4835','hufomyc@mailinator.com','2023-08-17','On Going','9','Distinctio Id volu','Autem dolorum aut et',NULL,1,1,1,'2023-08-25 07:29:47','2023-08-25 07:33:13'),(8,6,2,'Nina Sweet','Suki Compton','+1 (149) 229-1336','muxasi@mailinator.com','2023-07-30','Solved','9','Perferendis at amet','Velit laudantium ip',NULL,3,1,1,'2023-08-25 07:30:22','2023-08-25 07:33:37');
/*!40000 ALTER TABLE `complains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_types`
--

DROP TABLE IF EXISTS `content_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_types_title_unique` (`title`),
  UNIQUE KEY `content_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_types`
--

LOCK TABLES `content_types` WRITE;
/*!40000 ALTER TABLE `content_types` DISABLE KEYS */;
INSERT INTO `content_types` VALUES (1,'Syllabus','syllabus',NULL,1,'2022-09-30 13:55:02','2022-09-30 13:55:02'),(2,'Lecture Sheet','lecture-sheet',NULL,1,'2022-09-30 13:55:07','2022-09-30 13:55:07');
/*!40000 ALTER TABLE `content_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contentables`
--

DROP TABLE IF EXISTS `contentables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contentables` (
  `content_id` bigint(20) NOT NULL,
  `contentable_id` bigint(20) NOT NULL,
  `contentable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contentables`
--

LOCK TABLES `contentables` WRITE;
/*!40000 ALTER TABLE `contentables` DISABLE KEYS */;
INSERT INTO `contentables` VALUES (1,8,'App\\Models\\Student'),(1,7,'App\\Models\\Student'),(3,14,'App\\Models\\Student'),(3,12,'App\\Models\\Student'),(3,11,'App\\Models\\Student'),(3,10,'App\\Models\\Student');
/*!40000 ALTER TABLE `contentables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contents`
--

DROP TABLE IF EXISTS `contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `semester_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `date` date NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contents_type_id_foreign` (`type_id`),
  CONSTRAINT `contents_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `content_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contents`
--

LOCK TABLES `contents` WRITE;
/*!40000 ALTER TABLE `contents` DISABLE KEYS */;
INSERT INTO `contents` VALUES (1,2,2,4,1,1,2,'Optical Physics 1st Class',NULL,'2022-10-03',NULL,'book-covers_1664802778.jpg',1,1,NULL,'2022-10-03 07:12:58','2022-10-03 07:12:58'),(2,2,3,4,1,0,1,'Full Syllabus 2022','<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose</p>','2022-10-03',NULL,'book-cover2_1664802896.jpg',1,1,1,'2022-10-03 07:14:56','2022-10-03 14:56:00'),(3,2,3,4,1,0,2,'2nd Class Of English',NULL,'2022-10-04',NULL,'Provisional Certificate-100001_1664888967.pdf',1,1,NULL,'2022-10-04 07:09:27','2022-10-04 07:09:27');
/*!40000 ALTER TABLE `contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `faculty` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semesters` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credits` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `courses` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fee` double(10,2) DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `courses_title_unique` (`title`),
  UNIQUE KEY `courses_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,1,'Public Administration','public-administration','Political Science','12','134','60','4 Years',1250.00,'<p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy text of the printing.</p>\r\n<p>The world of search engine optimization is complex and ever-changing, but you can easily understand the basics, and even a small amount of SEO knowledge can make a big difference. Free SEO education is also widely available on the web, including in guides like this! (Woohoo!) This guide is designed to describe all major aspects of SEO, from finding the terms and phrases (keywords) that can generate qualified traffic to your website, to making your site friendly to search engines, to building links and marketing the unique value of your site.Etiam pharetra erat sed fermentum feugiat velit mauris egestas quam ut erat justo.</p>\r\n<h4>What You Will Learn</h4>\r\n<p>Fusce eleifend donec sapien sed phase lusa pellentesque lacus.Vivamus lorem arcu semper duiac. Cras ornare arcu avamus nda leo Etiam ind arcu. Morbi justo mauris tempus pharetra interdum at congue semper purus. Lorem ipsum dolor sit.The world of search engine optimization is complex and ever-changing, but you can easily understand the basics.</p>\r\n<p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy text of the printing.</p>\r\n<p>&nbsp;</p>','couress_img_3_1692962811.jpg',1,'2023-08-25 05:22:05','2023-08-25 05:26:51'),(2,1,'Computer Engineering','computer-engineering','Engineering','12','127','66','4 Years',6520.00,'<p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy text of the printing.</p>\r\n<p>The world of search engine optimization is complex and ever-changing, but you can easily understand the basics, and even a small amount of SEO knowledge can make a big difference. Free SEO education is also widely available on the web, including in guides like this! (Woohoo!) This guide is designed to describe all major aspects of SEO, from finding the terms and phrases (keywords) that can generate qualified traffic to your website, to making your site friendly to search engines, to building links and marketing the unique value of your site.Etiam pharetra erat sed fermentum feugiat velit mauris egestas quam ut erat justo.</p>\r\n<h4>What You Will Learn</h4>\r\n<p>Fusce eleifend donec sapien sed phase lusa pellentesque lacus.Vivamus lorem arcu semper duiac. Cras ornare arcu avamus nda leo Etiam ind arcu. Morbi justo mauris tempus pharetra interdum at congue semper purus. Lorem ipsum dolor sit.The world of search engine optimization is complex and ever-changing, but you can easily understand the basics.</p>\r\n<p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy text of the printing.</p>\r\n<p>&nbsp;</p>','couress_img_2_1692962832.jpg',1,'2023-08-25 05:24:10','2023-08-25 05:27:12'),(3,1,'Fine Arts and Design','fine-arts-and-design','Humanities','8','115','55','4 Years',4210.00,'<p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy text of the printing.</p>\r\n<p>The world of search engine optimization is complex and ever-changing, but you can easily understand the basics, and even a small amount of SEO knowledge can make a big difference. Free SEO education is also widely available on the web, including in guides like this! (Woohoo!) This guide is designed to describe all major aspects of SEO, from finding the terms and phrases (keywords) that can generate qualified traffic to your website, to making your site friendly to search engines, to building links and marketing the unique value of your site.Etiam pharetra erat sed fermentum feugiat velit mauris egestas quam ut erat justo.</p>\r\n<h4>What You Will Learn</h4>\r\n<p>Fusce eleifend donec sapien sed phase lusa pellentesque lacus.Vivamus lorem arcu semper duiac. Cras ornare arcu avamus nda leo Etiam ind arcu. Morbi justo mauris tempus pharetra interdum at congue semper purus. Lorem ipsum dolor sit.The world of search engine optimization is complex and ever-changing, but you can easily understand the basics.</p>\r\n<p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy text of the printing.</p>\r\n<p>&nbsp;</p>','couress_img_4_1692962782.jpg',1,'2023-08-25 05:26:23','2023-08-25 05:26:23');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departments_title_unique` (`title`),
  UNIQUE KEY `departments_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Admission','admission',NULL,1,'2022-09-30 14:02:55','2022-09-30 14:02:55'),(2,'Finance','finance',NULL,1,'2022-09-30 14:03:04','2022-10-01 04:16:23'),(3,'Library','library',NULL,1,'2022-09-30 14:03:14','2022-09-30 14:03:14'),(4,'IT Support','it-support',NULL,1,'2022-09-30 14:03:33','2022-09-30 14:03:33'),(5,'Faculty','faculty',NULL,1,'2022-09-30 14:03:44','2022-09-30 14:03:44'),(6,'Sports','sports',NULL,1,'2022-10-01 04:16:51','2022-10-01 04:16:51'),(10,'Faculty of Science','faculty-of-science',NULL,1,'2025-04-03 06:59:30','2025-04-03 06:59:30'),(11,'Faculty of Engineering','faculty-of-engineering',NULL,1,'2025-04-03 06:59:30','2025-04-03 06:59:30');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `designations`
--

DROP TABLE IF EXISTS `designations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `designations_title_unique` (`title`),
  UNIQUE KEY `designations_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `designations`
--

LOCK TABLES `designations` WRITE;
/*!40000 ALTER TABLE `designations` DISABLE KEYS */;
INSERT INTO `designations` VALUES (1,'Instructor','instructor',NULL,1,'2022-09-30 14:04:24','2022-09-30 14:04:24'),(2,'Admin','admin',NULL,1,'2022-09-30 14:04:34','2022-10-01 04:17:39'),(3,'Professor','professor',NULL,1,'2022-09-30 14:04:45','2022-09-30 14:04:45'),(4,'Accountant','accountant',NULL,1,'2022-09-30 14:05:06','2022-09-30 14:05:06'),(5,'Librarian','librarian',NULL,1,'2022-09-30 14:05:17','2022-09-30 14:05:17'),(6,'Receptionist','receptionist',NULL,1,'2022-09-30 14:06:12','2022-09-30 14:06:12'),(7,'Director','director',NULL,1,'2022-10-01 04:17:59','2022-10-01 04:17:59'),(8,'Chancellor','chancellor',NULL,1,'2022-10-01 04:18:48','2022-10-01 04:18:48'),(9,'Exam Controller','exam-controller',NULL,1,'2022-10-01 04:19:03','2022-10-01 04:19:03');
/*!40000 ALTER TABLE `designations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `districts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `province_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `districts_province_id_foreign` (`province_id`),
  CONSTRAINT `districts_province_id_foreign` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES (1,1,'Gazipur',NULL,1,'2022-09-30 14:17:34','2022-09-30 14:17:34'),(2,1,'Tangail',NULL,1,'2022-09-30 14:17:46','2022-09-30 14:17:46'),(3,4,'Kurigram',NULL,1,'2022-09-30 14:17:55','2022-09-30 14:17:55'),(4,4,'Dinajpur',NULL,1,'2022-09-30 14:18:04','2022-09-30 14:18:04'),(5,4,'Nilphamari',NULL,1,'2022-10-01 03:17:43','2022-10-01 03:17:43'),(6,1,'Munshiganj',NULL,1,'2022-10-01 03:17:57','2022-10-01 03:19:17'),(7,2,'Hobigonj',NULL,1,'2022-10-01 03:18:20','2022-10-01 03:18:20'),(8,3,'Jessore',NULL,1,'2022-10-01 03:18:50','2022-10-01 03:18:50'),(9,3,'Kustia',NULL,1,'2022-10-01 03:19:35','2022-10-01 03:19:35'),(10,3,'Norail',NULL,1,'2022-10-01 03:19:50','2022-10-01 03:19:50'),(11,3,'Magura',NULL,1,'2022-10-01 03:20:02','2022-10-01 03:20:02'),(12,4,'Gaibandha',NULL,1,'2022-10-01 03:20:31','2022-10-01 03:20:31'),(13,2,'Sylhet',NULL,1,'2022-10-01 03:20:50','2022-10-01 03:21:09');
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docables`
--

DROP TABLE IF EXISTS `docables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docables` (
  `document_id` bigint(20) unsigned NOT NULL,
  `docable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `docable_id` bigint(20) unsigned NOT NULL,
  UNIQUE KEY `docables_document_id_docable_id_docable_type_unique` (`document_id`,`docable_id`,`docable_type`),
  KEY `docables_docable_type_docable_id_index` (`docable_type`,`docable_id`),
  CONSTRAINT `docables_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docables`
--

LOCK TABLES `docables` WRITE;
/*!40000 ALTER TABLE `docables` DISABLE KEYS */;
INSERT INTO `docables` VALUES (4,'App\\Models\\Student',2),(5,'App\\Models\\Student',4),(6,'App\\Models\\Student',8),(7,'App\\Models\\Student',9),(8,'App\\Models\\Student',13),(9,'App\\Models\\Student',14),(1,'App\\User',4),(2,'App\\User',7),(3,'App\\User',9);
/*!40000 ALTER TABLE `docables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES (1,'NID Copy','book-cover2.jpg_1664711842.jpg',1,'2022-10-02 05:57:22','2022-10-02 05:57:22'),(2,'Passport Copy','book-covers.jpg_1664732229.jpg',1,'2022-10-02 11:37:09','2022-10-02 11:37:09'),(3,'Experiance Cer','book-covers.jpg_1664732856.jpg',1,'2022-10-02 11:47:36','2022-10-02 11:47:36'),(4,'Marksheet','book-covers.jpg_1664734667.jpg',1,'2022-10-02 12:17:47','2022-10-02 12:17:47'),(5,'Marksheet','book-cover2.jpg_1664734905.jpg',1,'2022-10-02 12:21:45','2022-10-02 12:21:45'),(6,'Marksheet','book-covers.jpg_1664735357.jpg',1,'2022-10-02 12:29:17','2022-10-02 12:29:17'),(7,'Transfer Doc','background-border.png_1664835743.png',1,'2022-10-03 16:22:23','2022-10-03 16:22:23'),(8,'Marksheet','book-cover2.jpg_1664884572.jpg',1,'2022-10-04 05:56:12','2022-10-04 05:56:12'),(9,'Marksheet','book-covers.jpg_1664884807.jpg',1,'2022-10-04 06:00:07','2022-10-04 06:00:07');
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_notifies`
--

DROP TABLE IF EXISTS `email_notifies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_notifies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `semester_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `receive_count` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_notifies`
--

LOCK TABLES `email_notifies` WRITE;
/*!40000 ALTER TABLE `email_notifies` DISABLE KEYS */;
INSERT INTO `email_notifies` VALUES (1,2,2,4,0,0,'Your Fees Due Date Is Very Close','This depends on when you enrol. Your fees are due 30 days from your starting date. For more information, please see Fees due dates.',2,1,1,NULL,'2022-10-03 11:54:16','2022-10-03 11:54:16'),(2,2,3,3,1,1,'Ready for attend our special class on sunday!','Note: If any of these dates fall on a holiday or weekend, the due date for fee payment will be the first working day following the holiday/weekend.',4,1,1,NULL,'2022-10-03 12:06:14','2022-10-03 12:06:14');
/*!40000 ALTER TABLE `email_notifies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enquiries`
--

DROP TABLE IF EXISTS `enquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquiries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reference_id` int(10) unsigned DEFAULT NULL,
  `source_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `purpose` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `date` date NOT NULL,
  `follow_up_date` date DEFAULT NULL,
  `assigned` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_of_students` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enquiries_reference_id_foreign` (`reference_id`),
  KEY `enquiries_source_id_foreign` (`source_id`),
  KEY `enquiries_program_id_foreign` (`program_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enquiries`
--

LOCK TABLES `enquiries` WRITE;
/*!40000 ALTER TABLE `enquiries` DISABLE KEYS */;
INSERT INTO `enquiries` VALUES (1,3,3,3,'Kim Sandoval',NULL,'+1 (939) 845-9236','voxagikib@mailinator.com','Aspernatur doloremqu','Odit et in qui et nu','Harum et deleniti ac','2022-10-01','2022-12-07','3',1,3,1,1,'2022-10-01 12:24:34','2023-08-25 07:28:58'),(2,3,1,1,'Jesse Sandoval',NULL,'+1 (752) 181-9433','morexy@mailinator.com','Eum velit ratione qu','Pariatur Facilis in','Enim esse quidem min','2019-04-02',NULL,'Architecto',1,0,1,1,'2022-10-01 12:25:14','2022-10-01 12:27:18'),(3,5,1,1,'Malachi Buckner',NULL,'+1 (774) 745-9417','wicodikico@mailinator.com','Laboriosam laudanti','Adipisicing aspernat','Sint vel animi tem','2021-09-25','2022-12-29','Arman',1,1,1,1,'2022-10-01 12:25:59','2022-10-01 12:26:58'),(4,2,4,1,'Ann Castro',NULL,'+1 (225) 849-6955','lela@mailinator.com','Molestias elit aut','Qui laborum Dicta n','Eum soluta quia est','2020-12-13',NULL,'Aperiam',1,1,1,NULL,'2022-10-01 12:26:30','2022-10-01 12:26:30'),(5,1,NULL,4,'Georgia Shepard',NULL,'+1 (907) 196-5628','gapi@mailinator.com','Fugiat sequi aut qu','Aut anim ipsa eaque','Et ex doloremque min','2021-04-05','2022-10-13','Saif',1,1,1,1,'2022-10-01 12:27:53','2022-10-01 12:28:07'),(6,1,1,5,'Coby Kline',NULL,'+1 (582) 879-4372','hoge@mailinator.com','Consequat Consequat','Asperiores quod null','Quod quas amet quid','2023-02-13','2023-04-10','4',1,2,1,1,'2023-02-13 12:25:51','2023-08-25 07:28:53'),(7,3,1,1,'Maggie Curry',NULL,'+1 (953) 288-2346','xaxe@mailinator.com','Est suscipit vel ul','Nam sit ut voluptate','Cum est est et aut','2023-08-21','2024-03-12','5',1,1,1,NULL,'2023-08-25 07:28:46','2023-08-25 07:28:46');
/*!40000 ALTER TABLE `enquiries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enquiry_references`
--

DROP TABLE IF EXISTS `enquiry_references`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquiry_references` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `enquiry_references_title_unique` (`title`),
  UNIQUE KEY `enquiry_references_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enquiry_references`
--

LOCK TABLES `enquiry_references` WRITE;
/*!40000 ALTER TABLE `enquiry_references` DISABLE KEYS */;
INSERT INTO `enquiry_references` VALUES (1,'Staff','staff',NULL,1,'2022-10-01 03:50:35','2022-10-01 03:50:35'),(2,'Parent','parent',NULL,1,'2022-10-01 03:50:46','2022-10-01 03:50:46'),(3,'Student','student',NULL,1,'2022-10-01 03:50:53','2022-10-01 03:50:53'),(4,'Self','self',NULL,1,'2022-10-01 03:51:01','2022-10-01 03:51:01'),(5,'Promotional Partner','promotional-partner',NULL,1,'2022-10-01 03:52:48','2022-10-01 03:52:48');
/*!40000 ALTER TABLE `enquiry_references` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enquiry_sources`
--

DROP TABLE IF EXISTS `enquiry_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquiry_sources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `enquiry_sources_title_unique` (`title`),
  UNIQUE KEY `enquiry_sources_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enquiry_sources`
--

LOCK TABLES `enquiry_sources` WRITE;
/*!40000 ALTER TABLE `enquiry_sources` DISABLE KEYS */;
INSERT INTO `enquiry_sources` VALUES (1,'Front Office','front-office',NULL,1,'2022-10-01 03:48:47','2022-10-01 03:48:47'),(2,'Advertisement','advertisement',NULL,1,'2022-10-01 03:48:55','2022-10-01 03:48:55'),(3,'University Website','university-website',NULL,1,'2022-10-01 03:49:10','2022-10-01 03:50:15'),(4,'Google Ads','google-ads',NULL,1,'2022-10-01 03:49:20','2022-10-01 03:49:20'),(5,'Admission Campaign','admission-campaign',NULL,1,'2022-10-01 03:49:28','2022-10-01 03:49:28'),(6,'Social Media','social-media',NULL,1,'2022-10-01 03:49:42','2022-10-01 03:49:42');
/*!40000 ALTER TABLE `enquiry_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enroll_subject_subject`
--

DROP TABLE IF EXISTS `enroll_subject_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enroll_subject_subject` (
  `enroll_subject_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  KEY `enroll_subject_subject_enroll_subject_id_foreign` (`enroll_subject_id`),
  KEY `enroll_subject_subject_subject_id_foreign` (`subject_id`),
  CONSTRAINT `enroll_subject_subject_enroll_subject_id_foreign` FOREIGN KEY (`enroll_subject_id`) REFERENCES `enroll_subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `enroll_subject_subject_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enroll_subject_subject`
--

LOCK TABLES `enroll_subject_subject` WRITE;
/*!40000 ALTER TABLE `enroll_subject_subject` DISABLE KEYS */;
INSERT INTO `enroll_subject_subject` VALUES (1,1),(1,2),(1,3),(1,8),(1,9),(2,1),(2,2),(2,3),(2,8),(2,9),(3,87),(3,88),(3,89),(3,90),(3,91),(4,87),(4,88),(4,89),(4,90),(4,91),(5,100),(5,101),(5,102),(5,103),(5,104),(6,100),(6,101),(6,102),(6,103),(6,104);
/*!40000 ALTER TABLE `enroll_subject_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enroll_subjects`
--

DROP TABLE IF EXISTS `enroll_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enroll_subjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `program_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enroll_subjects_program_id_foreign` (`program_id`),
  KEY `enroll_subjects_semester_id_foreign` (`semester_id`),
  KEY `enroll_subjects_section_id_foreign` (`section_id`),
  CONSTRAINT `enroll_subjects_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `enroll_subjects_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `enroll_subjects_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enroll_subjects`
--

LOCK TABLES `enroll_subjects` WRITE;
/*!40000 ALTER TABLE `enroll_subjects` DISABLE KEYS */;
INSERT INTO `enroll_subjects` VALUES (1,1,1,1,1,'2025-04-11 12:28:26','2025-04-11 12:28:26'),(2,1,1,2,1,'2025-04-11 12:28:26','2025-04-11 12:28:26'),(3,2,1,1,1,'2025-04-11 12:28:26','2025-04-11 12:28:26'),(4,2,1,2,1,'2025-04-11 12:28:26','2025-04-11 12:28:26'),(5,3,9,1,1,'2025-04-11 12:28:27','2025-04-11 12:28:27'),(6,3,9,2,1,'2025-04-11 12:28:27','2025-04-11 12:28:27');
/*!40000 ALTER TABLE `enroll_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'Eid Holiday','2023-10-03','2023-10-17','#70c24a',1,'2022-10-03 11:38:23','2023-08-25 06:38:31'),(2,'Marry Crismach','2023-11-03','2023-11-10','#4a5cc2',1,'2022-10-03 11:39:06','2023-08-25 06:38:21'),(3,'Durga Puja','2023-10-27','2023-11-01','#c24a4e',1,'2022-10-03 11:39:24','2023-08-25 06:38:11'),(4,'Final Exam','2023-11-23','2023-12-03','#c2b44a',1,'2022-10-03 11:39:54','2023-08-25 06:38:02'),(5,'Summer Vacation','2023-11-22','2023-12-06','#4aaec2',1,'2022-10-03 11:41:19','2023-08-25 06:37:52'),(6,'New Year Vacation','2023-12-24','2024-01-08','#c24ac2',1,'2022-10-03 11:41:57','2023-08-25 06:37:42');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_routine_room`
--

DROP TABLE IF EXISTS `exam_routine_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_routine_room` (
  `exam_routine_id` bigint(20) unsigned NOT NULL,
  `room_id` int(10) unsigned NOT NULL,
  KEY `exam_routine_room_exam_routine_id_foreign` (`exam_routine_id`),
  KEY `exam_routine_room_room_id_foreign` (`room_id`),
  CONSTRAINT `exam_routine_room_exam_routine_id_foreign` FOREIGN KEY (`exam_routine_id`) REFERENCES `exam_routines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_routine_room_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `class_rooms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_routine_room`
--

LOCK TABLES `exam_routine_room` WRITE;
/*!40000 ALTER TABLE `exam_routine_room` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_routine_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_routine_user`
--

DROP TABLE IF EXISTS `exam_routine_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_routine_user` (
  `exam_routine_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  KEY `exam_routine_user_exam_routine_id_foreign` (`exam_routine_id`),
  KEY `exam_routine_user_user_id_foreign` (`user_id`),
  CONSTRAINT `exam_routine_user_exam_routine_id_foreign` FOREIGN KEY (`exam_routine_id`) REFERENCES `exam_routines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_routine_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_routine_user`
--

LOCK TABLES `exam_routine_user` WRITE;
/*!40000 ALTER TABLE `exam_routine_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_routine_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_routines`
--

DROP TABLE IF EXISTS `exam_routines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_routines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `exam_type_id` int(10) unsigned NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exam_routines_exam_type_id_foreign` (`exam_type_id`),
  KEY `exam_routines_session_id_foreign` (`session_id`),
  KEY `exam_routines_program_id_foreign` (`program_id`),
  KEY `exam_routines_semester_id_foreign` (`semester_id`),
  KEY `exam_routines_section_id_foreign` (`section_id`),
  KEY `exam_routines_subject_id_foreign` (`subject_id`),
  CONSTRAINT `exam_routines_exam_type_id_foreign` FOREIGN KEY (`exam_type_id`) REFERENCES `exam_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_routines_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_routines_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_routines_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_routines_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_routines_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_routines`
--

LOCK TABLES `exam_routines` WRITE;
/*!40000 ALTER TABLE `exam_routines` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_routines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_types`
--

DROP TABLE IF EXISTS `exam_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marks` decimal(5,2) NOT NULL,
  `contribution` decimal(5,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `exam_types_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_types`
--

LOCK TABLES `exam_types` WRITE;
/*!40000 ALTER TABLE `exam_types` DISABLE KEYS */;
INSERT INTO `exam_types` VALUES (1,'Final Exam',100.00,50.00,NULL,1,NULL,'2023-02-13 11:50:36'),(2,'Midterm Exam',50.00,20.00,NULL,1,NULL,'2023-02-13 11:50:36'),(3,'Test Exam',20.00,0.00,NULL,1,NULL,'2023-02-13 11:50:36'),(4,'Class Test 1',20.00,0.00,'9',1,'2025-04-12 11:44:03','2025-04-12 11:44:03');
/*!40000 ALTER TABLE `exam_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exams` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_enroll_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `exam_type_id` int(10) unsigned DEFAULT NULL,
  `attendance` int(11) NOT NULL DEFAULT '2' COMMENT '1-Present, 2-Absent',
  `marks` decimal(5,2) DEFAULT NULL,
  `achieve_marks` decimal(5,2) DEFAULT NULL,
  `contribution` decimal(5,2) NOT NULL DEFAULT '0.00',
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exams_student_enroll_id_foreign` (`student_enroll_id`),
  KEY `exams_subject_id_foreign` (`subject_id`),
  KEY `exams_exam_type_id_foreign` (`exam_type_id`),
  CONSTRAINT `exams_student_enroll_id_foreign` FOREIGN KEY (`student_enroll_id`) REFERENCES `student_enrolls` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exams_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (1,471,9,3,1,20.00,15.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(2,2,9,3,1,20.00,16.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(3,450,9,3,1,20.00,12.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(4,361,9,3,1,20.00,10.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(5,116,9,3,1,20.00,13.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(6,17,9,3,1,20.00,5.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(7,257,9,3,1,20.00,8.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(8,132,9,3,1,20.00,0.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(9,179,9,3,1,20.00,10.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(10,331,9,3,1,20.00,19.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(11,400,9,3,1,20.00,14.50,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(12,466,9,3,1,20.00,5.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(13,321,9,3,1,20.00,7.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(14,314,9,3,1,20.00,2.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(15,153,9,3,1,20.00,13.00,0.00,'',1,1,1,'2025-04-11 12:59:05','2025-04-12 11:55:01','2025-04-01',NULL),(16,471,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(17,2,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(18,450,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(19,361,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(20,116,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(21,17,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(22,257,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(23,132,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(24,179,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(25,331,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(26,400,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(27,466,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(28,321,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(29,314,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL),(30,153,9,4,1,20.00,NULL,0.00,NULL,1,1,NULL,'2025-04-17 12:30:51','2025-04-17 12:30:51','2025-04-17',NULL);
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_categories`
--

DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `expense_categories_title_unique` (`title`),
  UNIQUE KEY `expense_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_categories`
--

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
INSERT INTO `expense_categories` VALUES (1,'Electricity BIll','electricity-bill',NULL,1,'2022-09-30 14:09:42','2022-09-30 14:09:42'),(2,'Internet Bill','internet-bill',NULL,1,'2022-09-30 14:10:08','2022-09-30 14:10:08'),(3,'Snacks','snacks',NULL,1,'2022-09-30 14:10:40','2022-09-30 14:10:40'),(4,'Stationery Purchase','stationery-purchase',NULL,1,'2022-10-01 04:11:52','2022-10-01 04:11:52'),(5,'Flower','flower',NULL,1,'2022-10-01 04:12:06','2022-10-01 04:12:06');
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_category_id_foreign` (`category_id`),
  CONSTRAINT `expenses_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `expense_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,1,'Beatae corporis sit','874596',954.00,'2020-07-07',NULL,'Voluptas incidunt a',NULL,1,1,1,'2022-10-01 13:22:35','2022-10-01 13:24:33',NULL),(2,4,'Neque architecto aut','89654',841.00,'2020-08-09',NULL,'Officiis dolor fugia',NULL,1,1,1,'2022-10-01 13:22:50','2022-10-01 13:24:17',NULL),(3,3,'Pizza for all Staffs','987456',544.00,'2021-05-08',NULL,'Sint non ullamco eum','background-border_1664652223.png',1,1,1,'2022-10-01 13:23:43','2022-10-01 13:24:02',NULL),(4,5,'Voluptate qui ex cup','98654',740.00,'2022-01-22',NULL,'Qui cumque in aut ma',NULL,1,1,NULL,'2022-10-01 13:25:03','2022-10-01 13:25:03',NULL),(5,1,'Ut laboriosam eum e','87459',740.00,'2022-04-28',4,'Sequi perspiciatis',NULL,1,1,1,'2022-10-01 13:25:25','2023-02-13 12:06:11',NULL),(6,2,'Quia inventore ex co','89456',214.00,'2019-12-19',NULL,'Sint dolorem sit si','background-border_1664652398.png',1,1,NULL,'2022-10-01 13:26:38','2022-10-01 13:26:38',NULL),(7,2,'Tempor voluptates no','57854',961.00,'2023-02-10',5,'Et voluptas earum ad',NULL,1,1,1,'2023-02-13 12:07:13','2023-02-13 12:07:29',NULL),(8,4,'Tempor qui id ea non','4454',844.00,'2023-08-12',5,'Occaecat ut enim con',NULL,1,1,NULL,'2023-08-25 06:34:50','2023-08-25 06:34:50','Facere exercitation'),(9,1,'Voluptatibus sint so','46546',920.00,'2023-05-09',3,'Exercitationem volup',NULL,1,1,1,'2023-08-25 06:43:48','2023-08-25 06:43:59','Omnis velit dolores');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculties`
--

DROP TABLE IF EXISTS `faculties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shortcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `faculties_title_unique` (`title`),
  UNIQUE KEY `faculties_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculties`
--

LOCK TABLES `faculties` WRITE;
/*!40000 ALTER TABLE `faculties` DISABLE KEYS */;
INSERT INTO `faculties` VALUES (1,'Institute of Business Administration','institute-of-business-administration','IBA-JU',1,'2025-04-03 03:07:15','2025-04-03 03:07:15');
/*!40000 ALTER TABLE `faculties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `faqs_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,1,'What is the minimum qualification for admission?','Our community is being called to reimagine the future. As the only university where a renowned design school comes together with premier colleges, we are making learning more relevant and transformational. We are enriched by the wide range.',NULL,1,'2023-08-24 15:56:49','2023-08-24 15:56:49'),(2,1,'What the required document for admission?','Our community is being called to reimagine the future. As the only university where a renowned design school comes together with premier colleges, we are making learning more relevant and transformational. We are enriched by the wide range.',NULL,1,'2023-08-24 15:57:23','2023-08-24 15:57:23'),(3,1,'What is the admission process?','Our community is being called to reimagine the future. As the only university where a renowned design school comes together with premier colleges, we are making learning more relevant and transformational. We are enriched by the wide range.',NULL,1,'2023-08-24 15:57:54','2023-08-24 15:57:54'),(4,1,'How to apply for under graduation?','Our community is being called to reimagine the future. As the only university where a renowned design school comes together with premier colleges, we are making learning more relevant and transformational. We are enriched by the wide range.',NULL,1,'2023-08-24 15:58:32','2023-08-24 15:58:32'),(5,1,'How much is admission fees?','Our community is being called to reimagine the future. As the only university where a renowned design school comes together with premier colleges, we are making learning more relevant and transformational. We are enriched by the wide range.',NULL,1,'2023-08-24 15:59:16','2023-08-24 15:59:16');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `features_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features`
--

LOCK TABLES `features` WRITE;
/*!40000 ALTER TABLE `features` DISABLE KEYS */;
INSERT INTO `features` VALUES (1,1,'Education Services','Seamlessly visualize quality ellectual capital without superior collaboration and idea sharing listically',NULL,NULL,1,'2023-08-24 15:54:29','2023-08-24 15:54:29'),(2,1,'International Hubs','Seamlessly visualize quality ellectual capital without superior collaboration and idea sharing listically',NULL,NULL,1,'2023-08-24 15:54:48','2023-08-24 15:54:48'),(3,1,'Bachelor’s and Master’s','Seamlessly visualize quality ellectual capital without superior collaboration and idea sharing listically',NULL,NULL,1,'2023-08-24 15:55:08','2023-08-24 15:55:08');
/*!40000 ALTER TABLE `features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees`
--

DROP TABLE IF EXISTS `fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_enroll_id` bigint(20) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `fee_amount` double(10,2) NOT NULL,
  `fine_amount` double(10,2) NOT NULL DEFAULT '0.00',
  `discount_amount` double(10,2) NOT NULL DEFAULT '0.00',
  `paid_amount` double(10,2) NOT NULL,
  `assign_date` date NOT NULL,
  `due_date` date NOT NULL,
  `pay_date` date DEFAULT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 Unpaid, 1 Paid',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fees_student_enroll_id_foreign` (`student_enroll_id`),
  KEY `fees_category_id_foreign` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees`
--

LOCK TABLES `fees` WRITE;
/*!40000 ALTER TABLE `fees` DISABLE KEYS */;
INSERT INTO `fees` VALUES (1,1,1,3500.00,0.00,300.00,3200.00,'2022-10-03','2022-10-13','2022-10-04',3,NULL,1,1,1,'2022-10-03 12:31:20','2022-10-04 09:22:54'),(2,2,1,3500.00,0.00,350.00,3150.00,'2022-10-03','2022-10-13',NULL,NULL,NULL,0,1,1,'2022-10-03 12:31:20','2022-10-04 09:22:16'),(3,3,1,3500.00,0.00,0.00,0.00,'2022-10-03','2022-10-13',NULL,NULL,NULL,2,1,1,'2022-10-03 12:31:20','2022-10-03 14:24:47'),(4,4,1,3500.00,0.00,300.00,3200.00,'2022-10-03','2022-10-13','2022-10-04',5,'Online',1,1,1,'2022-10-03 12:31:20','2022-10-04 09:23:56'),(5,7,1,4500.00,0.00,450.00,4050.00,'2022-10-03','2022-10-03','2022-10-03',2,NULL,1,NULL,1,'2022-10-03 13:38:36','2022-10-03 13:39:15'),(6,5,2,2000.00,0.00,0.00,0.00,'2022-10-04','2022-10-20',NULL,NULL,NULL,0,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59'),(7,6,2,2000.00,0.00,0.00,0.00,'2022-10-04','2022-10-20',NULL,NULL,NULL,0,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59'),(8,7,2,2000.00,0.00,0.00,0.00,'2022-10-04','2022-10-20',NULL,NULL,NULL,0,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59'),(9,8,2,2000.00,0.00,0.00,0.00,'2022-10-04','2022-10-20',NULL,NULL,NULL,0,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59'),(10,9,2,2000.00,0.00,200.00,1800.00,'2022-10-04','2022-10-20','2023-08-25',2,NULL,1,1,1,'2022-10-04 07:26:59','2023-08-25 06:29:56'),(11,10,2,2000.00,0.00,0.00,0.00,'2022-10-04','2022-10-20',NULL,NULL,NULL,0,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59'),(12,11,2,2000.00,0.00,0.00,0.00,'2022-10-04','2022-10-20',NULL,NULL,NULL,0,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59'),(13,12,2,2000.00,0.00,200.00,1800.00,'2022-10-04','2022-10-20','2022-10-04',4,NULL,1,1,1,'2022-10-04 07:26:59','2022-10-04 10:23:58'),(14,13,2,2000.00,0.00,200.00,1800.00,'2022-10-04','2022-10-20','2023-08-25',3,NULL,1,1,1,'2022-10-04 07:26:59','2023-08-25 06:29:24'),(15,14,2,2000.00,0.00,200.00,1800.00,'2022-10-04','2022-10-20','2022-10-04',1,NULL,1,1,1,'2022-10-04 07:26:59','2022-10-04 10:11:26'),(16,15,2,2000.00,0.00,0.00,0.00,'2022-10-04','2022-10-20',NULL,NULL,NULL,0,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59'),(17,16,2,2000.00,0.00,200.00,1800.00,'2022-10-04','2022-10-20','2022-10-04',3,NULL,1,1,1,'2022-10-04 07:26:59','2022-10-04 10:11:18'),(18,17,2,2000.00,0.00,0.00,0.00,'2022-10-04','2022-10-20',NULL,NULL,NULL,0,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59'),(19,18,2,2000.00,0.00,200.00,1800.00,'2022-10-04','2022-10-20','2022-10-04',2,'Testing',1,1,1,'2022-10-04 07:26:59','2022-10-04 09:21:36'),(20,5,3,2000.00,0.00,200.00,1800.00,'2023-02-13','2023-02-28','2023-02-13',1,'Paid',1,1,1,'2023-02-13 11:53:18','2023-02-13 11:55:00'),(21,6,3,2000.00,0.00,0.00,0.00,'2023-02-13','2023-02-28',NULL,NULL,NULL,0,1,NULL,'2023-02-13 11:53:18','2023-02-13 11:53:18'),(22,7,3,2000.00,0.00,0.00,0.00,'2023-02-13','2023-02-28',NULL,NULL,NULL,0,1,NULL,'2023-02-13 11:53:18','2023-02-13 11:53:18'),(23,8,3,2000.00,0.00,200.00,1800.00,'2023-02-13','2023-02-28','2023-02-13',2,NULL,1,1,1,'2023-02-13 11:53:18','2023-02-13 11:54:05'),(24,17,3,2000.00,0.00,0.00,0.00,'2023-02-13','2023-02-28',NULL,NULL,NULL,0,1,NULL,'2023-02-13 11:53:18','2023-02-13 11:53:18');
/*!40000 ALTER TABLE `fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_categories`
--

DROP TABLE IF EXISTS `fees_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fees_categories_title_unique` (`title`),
  UNIQUE KEY `fees_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_categories`
--

LOCK TABLES `fees_categories` WRITE;
/*!40000 ALTER TABLE `fees_categories` DISABLE KEYS */;
INSERT INTO `fees_categories` VALUES (1,'Admission Fees','admission-fees',NULL,1,NULL,'2022-10-01 04:21:10'),(2,'Semester Fees','semester-fees',NULL,1,NULL,'2022-10-01 04:21:21'),(3,'Exam Fees','exam-fees',NULL,1,NULL,'2022-10-01 04:21:16');
/*!40000 ALTER TABLE `fees_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_category_fees_discount`
--

DROP TABLE IF EXISTS `fees_category_fees_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees_category_fees_discount` (
  `fees_category_id` int(10) unsigned NOT NULL,
  `fees_discount_id` int(10) unsigned NOT NULL,
  KEY `fees_category_fees_discount_fees_category_id_foreign` (`fees_category_id`),
  KEY `fees_category_fees_discount_fees_discount_id_foreign` (`fees_discount_id`),
  CONSTRAINT `fees_category_fees_discount_fees_category_id_foreign` FOREIGN KEY (`fees_category_id`) REFERENCES `fees_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fees_category_fees_discount_fees_discount_id_foreign` FOREIGN KEY (`fees_discount_id`) REFERENCES `fees_discounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_category_fees_discount`
--

LOCK TABLES `fees_category_fees_discount` WRITE;
/*!40000 ALTER TABLE `fees_category_fees_discount` DISABLE KEYS */;
INSERT INTO `fees_category_fees_discount` VALUES (3,3),(2,3),(1,2);
/*!40000 ALTER TABLE `fees_category_fees_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_category_fees_fine`
--

DROP TABLE IF EXISTS `fees_category_fees_fine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees_category_fees_fine` (
  `fees_category_id` int(10) unsigned NOT NULL,
  `fees_fine_id` int(10) unsigned NOT NULL,
  KEY `fees_category_fees_fine_fees_category_id_foreign` (`fees_category_id`),
  KEY `fees_category_fees_fine_fees_fine_id_foreign` (`fees_fine_id`),
  CONSTRAINT `fees_category_fees_fine_fees_category_id_foreign` FOREIGN KEY (`fees_category_id`) REFERENCES `fees_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fees_category_fees_fine_fees_fine_id_foreign` FOREIGN KEY (`fees_fine_id`) REFERENCES `fees_fines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_category_fees_fine`
--

LOCK TABLES `fees_category_fees_fine` WRITE;
/*!40000 ALTER TABLE `fees_category_fees_fine` DISABLE KEYS */;
INSERT INTO `fees_category_fees_fine` VALUES (1,1),(3,1),(2,1),(1,2),(3,2),(2,2);
/*!40000 ALTER TABLE `fees_category_fees_fine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_discount_status_type`
--

DROP TABLE IF EXISTS `fees_discount_status_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees_discount_status_type` (
  `fees_discount_id` int(10) unsigned NOT NULL,
  `status_type_id` int(10) unsigned NOT NULL,
  KEY `fees_discount_status_type_fees_discount_id_foreign` (`fees_discount_id`),
  KEY `fees_discount_status_type_status_type_id_foreign` (`status_type_id`),
  CONSTRAINT `fees_discount_status_type_fees_discount_id_foreign` FOREIGN KEY (`fees_discount_id`) REFERENCES `fees_discounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fees_discount_status_type_status_type_id_foreign` FOREIGN KEY (`status_type_id`) REFERENCES `status_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_discount_status_type`
--

LOCK TABLES `fees_discount_status_type` WRITE;
/*!40000 ALTER TABLE `fees_discount_status_type` DISABLE KEYS */;
INSERT INTO `fees_discount_status_type` VALUES (2,2),(2,7),(2,4),(2,1),(2,3),(2,5),(2,6),(3,2),(3,7),(3,4),(3,1),(3,3),(3,5);
/*!40000 ALTER TABLE `fees_discount_status_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_discounts`
--

DROP TABLE IF EXISTS `fees_discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees_discounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '1 Fixed & 2 Percentange',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_discounts`
--

LOCK TABLES `fees_discounts` WRITE;
/*!40000 ALTER TABLE `fees_discounts` DISABLE KEYS */;
INSERT INTO `fees_discounts` VALUES (2,'Winter Discount','2022-10-03','2022-10-31',300.00,1,1,'2022-10-03 13:14:13','2022-10-04 08:50:10'),(3,'Covid-19 Discount','2022-10-04','2023-10-04',10.00,2,1,'2022-10-04 08:48:04','2022-10-04 08:50:20');
/*!40000 ALTER TABLE `fees_discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_fines`
--

DROP TABLE IF EXISTS `fees_fines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees_fines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `start_day` int(11) NOT NULL,
  `end_day` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '1 Fixed, 2 Percentage',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_fines`
--

LOCK TABLES `fees_fines` WRITE;
/*!40000 ALTER TABLE `fees_fines` DISABLE KEYS */;
INSERT INTO `fees_fines` VALUES (1,1,5,15.00,2,1,'2022-09-30 13:58:24','2022-09-30 13:58:24'),(2,6,30,500.00,1,1,'2022-09-30 13:58:59','2022-09-30 13:58:59');
/*!40000 ALTER TABLE `fees_fines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_master_student_enroll`
--

DROP TABLE IF EXISTS `fees_master_student_enroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees_master_student_enroll` (
  `fees_master_id` bigint(20) unsigned NOT NULL,
  `student_enroll_id` bigint(20) unsigned NOT NULL,
  KEY `fees_master_student_enroll_fees_master_id_foreign` (`fees_master_id`),
  KEY `fees_master_student_enroll_student_enroll_id_foreign` (`student_enroll_id`),
  CONSTRAINT `fees_master_student_enroll_fees_master_id_foreign` FOREIGN KEY (`fees_master_id`) REFERENCES `fees_masters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fees_master_student_enroll_student_enroll_id_foreign` FOREIGN KEY (`student_enroll_id`) REFERENCES `student_enrolls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_master_student_enroll`
--

LOCK TABLES `fees_master_student_enroll` WRITE;
/*!40000 ALTER TABLE `fees_master_student_enroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `fees_master_student_enroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees_masters`
--

DROP TABLE IF EXISTS `fees_masters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fees_masters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `faculty_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `semester_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `assign_date` date NOT NULL,
  `due_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '1 Fixed, 2 Per Credit',
  PRIMARY KEY (`id`),
  KEY `fees_masters_category_id_foreign` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees_masters`
--

LOCK TABLES `fees_masters` WRITE;
/*!40000 ALTER TABLE `fees_masters` DISABLE KEYS */;
INSERT INTO `fees_masters` VALUES (1,1,2,3,3,0,0,3500.00,'2022-10-03','2022-10-13',1,1,NULL,'2022-10-03 12:31:20','2022-10-03 12:31:20',1),(2,2,0,0,0,0,0,2000.00,'2022-10-04','2022-10-20',1,1,NULL,'2022-10-04 07:26:59','2022-10-04 07:26:59',1),(3,3,2,2,0,0,0,200.00,'2023-02-13','2023-02-28',1,1,NULL,'2023-02-13 11:53:18','2023-02-13 11:53:18',2);
/*!40000 ALTER TABLE `fees_masters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fields_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'user_father_name',1,NULL,NULL),(2,'user_mother_name',1,NULL,NULL),(3,'user_joining_date',1,NULL,NULL),(4,'user_ending_date',1,NULL,NULL),(5,'user_emergency_phone',1,NULL,NULL),(6,'user_religion',0,NULL,NULL),(7,'user_caste',0,NULL,NULL),(8,'user_mother_tongue',0,NULL,NULL),(9,'user_nationality',0,NULL,NULL),(10,'user_marital_status',1,NULL,NULL),(11,'user_blood_group',1,NULL,NULL),(12,'user_national_id',1,NULL,NULL),(13,'user_passport_no',1,NULL,NULL),(14,'user_address',1,NULL,NULL),(15,'user_education',1,NULL,NULL),(16,'user_epf_no',1,NULL,NULL),(17,'user_bank_account',1,NULL,NULL),(18,'user_signature',1,NULL,NULL),(19,'user_resume',1,NULL,NULL),(20,'user_joining_letter',1,NULL,NULL),(21,'user_documents',1,NULL,NULL),(22,'student_father_name',1,NULL,NULL),(23,'student_mother_name',1,NULL,NULL),(24,'student_father_occupation',1,NULL,NULL),(25,'student_mother_occupation',1,NULL,NULL),(26,'student_emergency_phone',1,NULL,NULL),(27,'student_religion',1,NULL,NULL),(28,'student_caste',0,NULL,NULL),(29,'student_mother_tongue',0,NULL,NULL),(30,'student_nationality',0,NULL,NULL),(31,'student_marital_status',1,NULL,NULL),(32,'student_blood_group',1,NULL,NULL),(33,'student_national_id',1,NULL,NULL),(34,'student_passport_no',1,NULL,NULL),(35,'student_address',1,NULL,NULL),(36,'student_school_info',1,NULL,NULL),(37,'student_collage_info',1,NULL,NULL),(38,'student_relatives',1,NULL,NULL),(39,'student_photo',1,NULL,NULL),(40,'student_signature',1,NULL,NULL),(41,'student_documents',1,NULL,NULL),(42,'application_father_name',1,NULL,NULL),(43,'application_mother_name',1,NULL,NULL),(44,'application_father_occupation',1,NULL,NULL),(45,'application_mother_occupation',1,NULL,NULL),(46,'application_emergency_phone',0,NULL,NULL),(47,'application_religion',0,NULL,NULL),(48,'application_caste',0,NULL,NULL),(49,'application_mother_tongue',0,NULL,NULL),(50,'application_nationality',0,NULL,NULL),(51,'application_marital_status',1,NULL,NULL),(52,'application_blood_group',1,NULL,NULL),(53,'application_national_id',1,NULL,NULL),(54,'application_passport_no',1,NULL,NULL),(55,'application_address',1,NULL,NULL),(56,'application_school_info',1,NULL,NULL),(57,'application_collage_info',1,NULL,NULL),(58,'application_photo',1,NULL,NULL),(59,'application_signature',1,NULL,NULL),(60,'panel_class_routine',1,NULL,NULL),(61,'panel_exam_routine',1,NULL,NULL),(62,'panel_attendance',1,NULL,NULL),(63,'panel_leave',1,NULL,NULL),(64,'panel_fees_report',1,NULL,NULL),(65,'panel_library',1,NULL,NULL),(66,'panel_notice',1,NULL,NULL),(67,'panel_assignment',1,NULL,NULL),(68,'panel_download',1,NULL,NULL),(69,'panel_transcript',1,NULL,NULL),(70,'panel_profile',1,NULL,NULL);
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` VALUES (1,1,'01',NULL,'protfolio_img01_1692915624.jpg',1,'2023-08-24 16:20:24','2023-08-24 16:20:24'),(2,1,'02',NULL,'protfolio_img02_1692915631.jpg',1,'2023-08-24 16:20:31','2023-08-24 16:20:31'),(3,1,'03',NULL,'protfolio_img03_1692915639.jpg',1,'2023-08-24 16:20:39','2023-08-24 16:20:39'),(4,1,'04',NULL,'protfolio_img04_1692915646.jpg',1,'2023-08-24 16:20:47','2023-08-24 16:20:47'),(5,1,'05',NULL,'protfolio_img05_1692915654.jpg',1,'2023-08-24 16:20:55','2023-08-24 16:20:55'),(6,1,'06',NULL,'protfolio_img06_1692915663.jpg',1,'2023-08-24 16:21:03','2023-08-24 16:21:03');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grades`
--

DROP TABLE IF EXISTS `grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `point` decimal(5,2) NOT NULL,
  `min_mark` decimal(5,2) NOT NULL,
  `max_mark` decimal(5,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `grades_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grades`
--

LOCK TABLES `grades` WRITE;
/*!40000 ALTER TABLE `grades` DISABLE KEYS */;
INSERT INTO `grades` VALUES (1,'A',5.00,80.00,100.00,1,NULL,NULL,NULL),(2,'B',4.00,70.00,79.99,1,NULL,NULL,NULL),(3,'C',3.00,60.00,69.99,1,NULL,NULL,NULL),(4,'D',2.00,50.00,59.99,1,NULL,'2022-10-02 15:21:33',NULL),(5,'E',1.00,40.00,49.99,1,NULL,NULL,NULL),(6,'F',0.00,0.00,39.99,1,NULL,'2022-10-02 15:21:41',NULL);
/*!40000 ALTER TABLE `grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel_members`
--

DROP TABLE IF EXISTS `hostel_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hostel_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hostelable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hostelable_id` bigint(20) unsigned NOT NULL,
  `hostel_room_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Inactive, 1 Active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hostel_members_hostelable_type_hostelable_id_index` (`hostelable_type`,`hostelable_id`),
  KEY `hostel_members_hostel_room_id_foreign` (`hostel_room_id`),
  CONSTRAINT `hostel_members_hostel_room_id_foreign` FOREIGN KEY (`hostel_room_id`) REFERENCES `hostel_rooms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel_members`
--

LOCK TABLES `hostel_members` WRITE;
/*!40000 ALTER TABLE `hostel_members` DISABLE KEYS */;
INSERT INTO `hostel_members` VALUES (1,'App\\Models\\Student',14,2,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:12:29','2023-02-13 13:12:29'),(2,'App\\Models\\Student',12,3,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:12:39','2023-02-13 13:12:39'),(3,'App\\Models\\Student',10,2,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:12:45','2023-02-13 13:12:45'),(4,'App\\Models\\Student',9,1,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:13:00','2023-02-13 13:13:00'),(5,'App\\User',8,5,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:13:32','2023-02-13 13:13:32'),(6,'App\\User',3,6,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:13:37','2023-02-13 13:13:37'),(7,'App\\User',2,6,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:13:42','2023-02-13 13:13:42');
/*!40000 ALTER TABLE `hostel_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel_room_types`
--

DROP TABLE IF EXISTS `hostel_room_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hostel_room_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee` double(10,2) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hostel_room_types_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel_room_types`
--

LOCK TABLES `hostel_room_types` WRITE;
/*!40000 ALTER TABLE `hostel_room_types` DISABLE KEYS */;
INSERT INTO `hostel_room_types` VALUES (1,'AC 2 Bed',2500.00,NULL,1,'2023-02-13 13:03:07','2023-02-13 13:03:07'),(2,'AC 3 Bed',2000.00,NULL,1,'2023-02-13 13:03:17','2023-02-13 13:03:17'),(3,'Non-AC 2 Bed',1700.00,NULL,1,'2023-02-13 13:03:41','2023-02-13 13:03:41'),(4,'Non-AC 3 Bed',1200.00,NULL,1,'2023-02-13 13:03:54','2023-02-13 13:03:54');
/*!40000 ALTER TABLE `hostel_room_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostel_rooms`
--

DROP TABLE IF EXISTS `hostel_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hostel_rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hostel_id` int(10) unsigned NOT NULL,
  `room_type_id` int(10) unsigned NOT NULL,
  `bed` int(11) NOT NULL DEFAULT '1',
  `fee` double(10,2) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hostel_rooms_hostel_id_foreign` (`hostel_id`),
  KEY `hostel_rooms_room_type_id_foreign` (`room_type_id`),
  CONSTRAINT `hostel_rooms_hostel_id_foreign` FOREIGN KEY (`hostel_id`) REFERENCES `hostels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `hostel_rooms_room_type_id_foreign` FOREIGN KEY (`room_type_id`) REFERENCES `hostel_room_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostel_rooms`
--

LOCK TABLES `hostel_rooms` WRITE;
/*!40000 ALTER TABLE `hostel_rooms` DISABLE KEYS */;
INSERT INTO `hostel_rooms` VALUES (1,'A1',3,1,2,NULL,'Ex atque consequatur',1,'2023-02-13 13:06:01','2023-02-13 13:06:01'),(2,'A2',2,4,3,NULL,'Et ut ut sint ex rat',1,'2023-02-13 13:06:13','2023-02-13 13:07:29'),(3,'A3',3,4,3,NULL,'Fugiat aut sit nost',1,'2023-02-13 13:06:25','2023-02-13 13:06:25'),(4,'A4',2,2,3,NULL,'Sit voluptate fugia',1,'2023-02-13 13:06:40','2023-02-13 13:06:56'),(5,'A5',1,4,3,NULL,'Eveniet eu consecte',1,'2023-02-13 13:07:16','2023-02-13 13:07:16'),(6,'A6',1,1,2,NULL,'Enim quis molestias',1,'2023-02-13 13:07:50','2023-02-13 13:07:50');
/*!40000 ALTER TABLE `hostel_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostels`
--

DROP TABLE IF EXISTS `hostels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hostels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '1 Boys, 2 Girls, 3 Staff, 4 Combain',
  `capacity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warden_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warden_contact` text COLLATE utf8mb4_unicode_ci,
  `address` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hostels_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostels`
--

LOCK TABLES `hostels` WRITE;
/*!40000 ALTER TABLE `hostels` DISABLE KEYS */;
INSERT INTO `hostels` VALUES (1,'City Garden',3,'50',NULL,NULL,'Ut non proident pra',NULL,1,'2023-02-13 13:04:25','2023-02-13 13:10:40'),(2,'House of Mystery',1,'150',NULL,NULL,'Excepteur dicta magn',NULL,1,'2023-02-13 13:04:43','2023-02-13 13:10:47'),(3,'Rose and Rings',2,'120',NULL,NULL,'Commodo fugit quia',NULL,1,'2023-02-13 13:05:00','2023-02-13 13:09:47');
/*!40000 ALTER TABLE `hostels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `id_card_settings`
--

DROP TABLE IF EXISTS `id_card_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `id_card_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` text COLLATE utf8mb4_unicode_ci,
  `background` text COLLATE utf8mb4_unicode_ci,
  `website_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `student_photo` tinyint(1) NOT NULL DEFAULT '0',
  `signature` tinyint(1) NOT NULL DEFAULT '0',
  `barcode` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_card_settings_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `id_card_settings`
--

LOCK TABLES `id_card_settings` WRITE;
/*!40000 ALTER TABLE `id_card_settings` DISABLE KEYS */;
INSERT INTO `id_card_settings` VALUES (1,'student-card','Campus365 Digital Space for Universities','Digital Space for Universities',NULL,NULL,NULL,'5','Savar, Dhaka 1208',0,0,0,1,'2022-09-30 12:16:48','2024-05-22 14:02:48'),(2,'library-card','Our University Library Card','Our University Slogan',NULL,NULL,NULL,'5','Mirpur, Dhaka 1208',0,0,0,1,'2022-09-30 14:14:49','2022-09-30 14:14:49');
/*!40000 ALTER TABLE `id_card_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income_categories`
--

DROP TABLE IF EXISTS `income_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `income_categories_title_unique` (`title`),
  UNIQUE KEY `income_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income_categories`
--

LOCK TABLES `income_categories` WRITE;
/*!40000 ALTER TABLE `income_categories` DISABLE KEYS */;
INSERT INTO `income_categories` VALUES (1,'Shop Rent','shop-rent',NULL,1,'2022-09-30 14:07:22','2022-09-30 14:07:22'),(2,'Hostel Fees','hostel-fees',NULL,1,'2022-09-30 14:07:58','2022-09-30 14:07:58'),(3,'Waste Sell','waste-sell',NULL,1,'2022-09-30 14:09:14','2022-09-30 14:09:14'),(4,'Donation','donation',NULL,1,'2022-10-01 04:09:18','2022-10-01 04:09:18'),(5,'Book Sell','book-sell',NULL,1,'2022-10-01 04:10:13','2022-10-01 04:10:13'),(6,'Uniform Sell','uniform-sell',NULL,1,'2022-10-01 04:10:55','2022-10-01 04:10:55');
/*!40000 ALTER TABLE `income_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incomes`
--

DROP TABLE IF EXISTS `incomes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incomes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `incomes_category_id_foreign` (`category_id`),
  CONSTRAINT `incomes_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `income_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incomes`
--

LOCK TABLES `incomes` WRITE;
/*!40000 ALTER TABLE `incomes` DISABLE KEYS */;
INSERT INTO `incomes` VALUES (1,1,'Sint reprehenderit','789452',758.00,'2021-02-25',NULL,'Praesentium et nostr','background-border_1664651865.png',1,1,NULL,'2022-10-01 13:17:45','2022-10-01 13:17:45',NULL),(2,4,'Rerum in ducimus es','78147',365.00,'2022-03-01',1,'Commodo enim maxime',NULL,1,1,1,'2022-10-01 13:18:15','2023-02-13 12:05:42',NULL),(3,3,'Velit iure velit qui','78458',254.00,'2020-07-19',NULL,'Aliquid at sit inci',NULL,1,1,1,'2022-10-01 13:18:33','2022-10-01 13:18:49',NULL),(4,5,'Expedita voluptas pr','758426',905.00,'2022-05-19',2,'Esse laboris quis re',NULL,1,1,1,'2022-10-01 13:19:17','2023-02-13 12:05:34',NULL),(5,6,'Fugiat ad non digni','458752',548.00,'2022-05-30',3,'Quidem temporibus qu','background-border_1664651984.png',1,1,1,'2022-10-01 13:19:44','2023-02-13 12:05:26',NULL),(6,3,'Non in voluptatem A','87458',654.00,'2021-11-22',NULL,'Ut deleniti voluptas',NULL,1,1,1,'2022-10-01 13:20:24','2022-10-01 13:20:36',NULL),(7,4,'Illum est cumque ma','5454',530.00,'2023-06-17',2,'Dignissimos aut esse',NULL,1,1,NULL,'2023-08-25 06:35:17','2023-08-25 06:35:17','Mollitia dolor esse'),(8,5,'Ipsum dignissimos v','4545',690.00,'2023-05-27',4,'Enim omnis nesciunt',NULL,1,1,NULL,'2023-08-25 06:35:55','2023-08-25 06:35:55','Suscipit mollit aut'),(9,1,'Eum magnam non venia','454',670.00,'2023-07-02',5,'Esse molestiae est',NULL,1,1,NULL,'2023-08-25 06:42:55','2023-08-25 06:42:55','Voluptas voluptates');
/*!40000 ALTER TABLE `incomes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_returns`
--

DROP TABLE IF EXISTS `issue_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_returns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) unsigned NOT NULL,
  `book_id` bigint(20) unsigned NOT NULL,
  `issue_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `penalty` decimal(10,2) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Lost, 1 Issued, 2 Returned',
  `issued_by` bigint(20) unsigned DEFAULT NULL,
  `received_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_returns_member_id_foreign` (`member_id`),
  KEY `issue_returns_book_id_foreign` (`book_id`),
  CONSTRAINT `issue_returns_book_id_foreign` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_returns_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `library_members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_returns`
--

LOCK TABLES `issue_returns` WRITE;
/*!40000 ALTER TABLE `issue_returns` DISABLE KEYS */;
INSERT INTO `issue_returns` VALUES (1,3,5,'2022-10-03','2022-10-13','2022-10-03',NULL,2,1,1,'2022-10-03 15:05:37','2022-10-03 15:07:20'),(2,5,3,'2022-10-03','2023-01-12',NULL,NULL,1,1,NULL,'2022-10-03 15:06:13','2022-10-03 15:06:13'),(3,14,4,'2022-10-03','2022-12-21',NULL,NULL,1,1,NULL,'2022-10-03 15:06:34','2022-10-03 15:06:34'),(4,9,1,'2022-10-03','2022-12-13',NULL,NULL,1,1,NULL,'2022-10-03 15:06:58','2022-10-03 15:06:58'),(5,21,2,'2022-10-04','2022-11-14',NULL,NULL,1,1,NULL,'2022-10-04 07:41:08','2022-10-04 07:41:08'),(6,21,5,'2022-10-04','2022-10-14','2022-10-04',NULL,2,1,1,'2022-10-04 07:42:03','2022-10-04 07:42:24');
/*!40000 ALTER TABLE `issue_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_categories`
--

DROP TABLE IF EXISTS `item_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_categories_title_unique` (`title`),
  UNIQUE KEY `item_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_categories`
--

LOCK TABLES `item_categories` WRITE;
/*!40000 ALTER TABLE `item_categories` DISABLE KEYS */;
INSERT INTO `item_categories` VALUES (1,'Chemistry Lab Equipment','chemistry-lab-equipment',NULL,1,'2023-02-13 13:22:02','2023-02-13 13:22:23'),(2,'Sports Equipment','sports-equipment',NULL,1,'2023-02-13 13:22:10','2023-02-13 13:22:31'),(3,'Electrical Lab Equipment','electrical-lab-equipment',NULL,1,'2023-02-13 13:23:01','2023-02-13 13:23:01');
/*!40000 ALTER TABLE `item_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_issues`
--

DROP TABLE IF EXISTS `item_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_issues` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `issue_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `penalty` decimal(10,2) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Lost, 1 Issued, 2 Returned',
  `issued_by` bigint(20) unsigned DEFAULT NULL,
  `received_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_issues_item_id_foreign` (`item_id`),
  KEY `item_issues_user_id_foreign` (`user_id`),
  CONSTRAINT `item_issues_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `item_issues_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_issues`
--

LOCK TABLES `item_issues` WRITE;
/*!40000 ALTER TABLE `item_issues` DISABLE KEYS */;
INSERT INTO `item_issues` VALUES (1,1,5,2,'2023-02-06','2023-02-08',NULL,NULL,NULL,NULL,1,1,NULL,'2023-02-13 13:34:54','2023-02-13 13:34:54'),(2,4,2,1,'2023-02-13','2023-02-13','2023-02-13',NULL,NULL,NULL,2,1,1,'2023-02-13 13:35:32','2023-02-13 13:35:52'),(3,3,5,2,'2023-08-25','2023-08-31',NULL,NULL,NULL,NULL,1,1,NULL,'2023-08-25 06:39:32','2023-08-25 06:39:32');
/*!40000 ALTER TABLE `item_issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_stocks`
--

DROP TABLE IF EXISTS `item_stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_stocks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `store_id` int(10) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `price` decimal(10,2) DEFAULT NULL,
  `date` date NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_stocks_item_id_foreign` (`item_id`),
  KEY `item_stocks_store_id_foreign` (`store_id`),
  CONSTRAINT `item_stocks_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `item_stocks_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `item_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_stocks`
--

LOCK TABLES `item_stocks` WRITE;
/*!40000 ALTER TABLE `item_stocks` DISABLE KEYS */;
INSERT INTO `item_stocks` VALUES (1,3,1,1,10,650.00,'2022-10-10',NULL,1,'Quia et et aliquam q',NULL,1,1,NULL,'2023-02-13 13:30:33','2023-02-13 13:30:33'),(2,4,1,1,5,350.00,'2023-01-19',NULL,5,'Laborum in tempore',NULL,1,1,NULL,'2023-02-13 13:31:19','2023-02-13 13:31:19'),(3,1,2,2,17,230.00,'2023-01-21',NULL,4,'Cumque praesentium v',NULL,1,1,NULL,'2023-02-13 13:32:02','2023-02-13 13:32:02');
/*!40000 ALTER TABLE `item_stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_stores`
--

DROP TABLE IF EXISTS `item_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_stores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `in_charge` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_stores_title_unique` (`title`),
  UNIQUE KEY `item_stores_store_no_unique` (`store_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_stores`
--

LOCK TABLES `item_stores` WRITE;
/*!40000 ALTER TABLE `item_stores` DISABLE KEYS */;
INSERT INTO `item_stores` VALUES (1,'Sports Store','001',NULL,'rurapovome@mailinator.com','+1 (904) 944-3416','Building 1',1,'2023-02-13 13:25:30','2023-02-13 13:25:58'),(2,'Lab Store','002',NULL,'vofujyweh@mailinator.com','+1 (603) 435-3949','Building 2',1,'2023-02-13 13:25:51','2023-02-13 13:25:51');
/*!40000 ALTER TABLE `item_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_suppliers`
--

DROP TABLE IF EXISTS `item_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `contact_person` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_suppliers_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_suppliers`
--

LOCK TABLES `item_suppliers` WRITE;
/*!40000 ALTER TABLE `item_suppliers` DISABLE KEYS */;
INSERT INTO `item_suppliers` VALUES (1,'DJ Sports Ltd','satudo@mailinator.com','+1 (226) 353-9362','Enim nihil aperiam v','Habib','Manager','zenigigyqo@mailinator.com','+1 (662) 469-3061','Molestias distinctio',1,'2023-02-13 13:24:00','2023-02-13 13:24:00'),(2,'SF Cemix','pezu@mailinator.com','+1 (713) 437-2232','Id ex veniam in et','Saif','Executive','cusopiwu@mailinator.com','+1 (819) 924-8146','Sed quis magnam elig',1,'2023-02-13 13:24:49','2023-02-13 13:24:49');
/*!40000 ALTER TABLE `item_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `items_name_unique` (`name`),
  KEY `items_category_id_foreign` (`category_id`),
  CONSTRAINT `items_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `item_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'Acid',1,'Pound',NULL,0,NULL,NULL,1,'2023-02-13 13:26:53','2023-02-13 13:29:35'),(2,'Volt Metar',3,'Digital',NULL,0,NULL,NULL,1,'2023-02-13 13:27:57','2023-02-13 13:29:51'),(3,'Cricket Bat',2,'M Size',NULL,0,NULL,NULL,1,'2023-02-13 13:28:15','2023-02-13 13:29:01'),(4,'Football',2,'5 No',NULL,0,NULL,NULL,1,'2023-02-13 13:28:27','2023-02-13 13:29:10');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'default','{\"uuid\":\"0f4d90f6-5119-40d4-a7e6-51335f14c8ad\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:153;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"302428bf-42e9-45e4-a1e5-4f6daffb4816\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(2,'default','{\"uuid\":\"84ba5ae2-8760-4d85-9fe6-1272c5d8e9b0\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:314;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"533c5544-a138-48a0-a1f5-e3f18a560bd1\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(3,'default','{\"uuid\":\"5a70abc0-5424-4ee6-bf80-1cfbb84d687c\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:321;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"3a34ce78-33da-4e9a-b9f3-28305410e571\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(4,'default','{\"uuid\":\"e356b62b-b55c-42de-be50-134e1ae9b65d\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:466;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"a722a019-0416-4b93-906c-ff4c7d822dbd\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(5,'default','{\"uuid\":\"61f72e79-0ba2-4737-9b76-197309ed7c97\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:400;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"f3e536fd-22a8-47fc-bde8-4038cc2e3a74\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(6,'default','{\"uuid\":\"5b108eb7-b9dd-4cd7-8f5b-b787f205b3f0\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:331;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"79c83a45-af4b-4e70-b6ca-2b154e38f463\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(7,'default','{\"uuid\":\"6d801d3e-8ab0-4150-af9c-eed4aeb43728\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:179;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"9c8bd634-aba1-4890-b37a-766b22250a1b\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(8,'default','{\"uuid\":\"c8612ca9-c5b8-4d96-8dc1-7d59f5299015\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:132;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"fb645414-46a2-4ef2-bbfa-1f2dc4ee182c\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(9,'default','{\"uuid\":\"7a799b62-2bd4-4827-85a2-874be25fbeaa\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:257;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"144e06dc-ba1c-47a1-80d2-f4b0128b708f\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(10,'default','{\"uuid\":\"c468df35-154d-4ee2-ac54-a7d87e29099a\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:17;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"3aaa2678-c4d8-4540-8a6b-4bf9b069531a\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(11,'default','{\"uuid\":\"9788d33c-d748-4bd3-a32c-0af45b1221a7\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:116;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"2e7bdad0-b609-4fd8-8cd6-e29f2a7a2d6d\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(12,'default','{\"uuid\":\"ff0237ed-9a4e-40d1-b982-830d748c3c2b\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:361;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"16ff6d53-5fae-4224-8a60-a7c6a748c371\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(13,'default','{\"uuid\":\"078801d1-5d39-429e-9c00-78929afb3939\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:450;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"d19034fe-c3b3-4f58-b0db-482c45c904e8\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(14,'default','{\"uuid\":\"a2432654-5714-4336-b7c7-3913c34f9e10\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:2;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"d69c4aa0-656c-4de0-8c9d-ad55d9cb4645\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470),(15,'default','{\"uuid\":\"1aa23606-3770-48c9-8119-ea75147b27e4\",\"displayName\":\"App\\\\Notifications\\\\AssignmentNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Student\\\";s:2:\\\"id\\\";a:1:{i:0;i:471;}s:9:\\\"relations\\\";a:3:{i:0;s:7:\\\"program\\\";i:1;s:13:\\\"currentEnroll\\\";i:2;s:22:\\\"currentEnroll.subjects\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:40:\\\"App\\\\Notifications\\\\AssignmentNotification\\\":2:{s:7:\\\"\\u0000*\\u0000data\\\";a:3:{s:2:\\\"id\\\";i:1;s:5:\\\"title\\\";s:7:\\\"FFADDGF\\\";s:4:\\\"type\\\";s:10:\\\"assignment\\\";}s:2:\\\"id\\\";s:36:\\\"546d9881-dba0-4d9e-8742-756fcb680435\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1744482470,1744482470);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `direction` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 LTR, 1 RTL',
  `default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 Not Default, 1 Default',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `languages_name_unique` (`name`),
  UNIQUE KEY `languages_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English','en',NULL,0,1,1,'2022-09-30 12:00:47','2022-09-30 12:00:47');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `limit` int(11) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leave_types_title_unique` (`title`),
  UNIQUE KEY `leave_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_types`
--

LOCK TABLES `leave_types` WRITE;
/*!40000 ALTER TABLE `leave_types` DISABLE KEYS */;
INSERT INTO `leave_types` VALUES (1,'Casual Leave','casual-leave',NULL,NULL,1,NULL,NULL),(2,'Sick Leave','sick-leave',NULL,NULL,1,NULL,NULL),(3,'Maternity Leave','maternity-leave',NULL,NULL,1,NULL,NULL),(4,'Marriage Leave','marriage-leave',NULL,NULL,1,NULL,NULL),(5,'Bereavement Leave','bereavement-leave',NULL,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `leave_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leaves`
--

DROP TABLE IF EXISTS `leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leaves` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `review_by` bigint(20) unsigned DEFAULT NULL,
  `apply_date` date NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `pay_type` int(11) NOT NULL DEFAULT '1' COMMENT '1 Paid & 2 Unpaid',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 Pending, 1 Approved and 2 Rejected',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leaves_type_id_foreign` (`type_id`),
  KEY `leaves_user_id_foreign` (`user_id`),
  CONSTRAINT `leaves_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leaves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaves`
--

LOCK TABLES `leaves` WRITE;
/*!40000 ALTER TABLE `leaves` DISABLE KEYS */;
INSERT INTO `leaves` VALUES (1,1,1,1,'2022-10-02','2022-10-02','2022-10-08','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',NULL,NULL,1,2,'2022-10-02 12:00:39','2022-10-02 12:02:46'),(2,2,1,1,'2022-10-02','2022-10-20','2022-10-24','It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).','book-covers_1664733674.jpg',NULL,2,1,'2022-10-02 12:01:14','2022-10-02 12:02:50');
/*!40000 ALTER TABLE `leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_members`
--

DROP TABLE IF EXISTS `library_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `library_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `memberable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memberable_id` bigint(20) unsigned NOT NULL,
  `library_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Inactive, 1 Active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `library_members_memberable_type_memberable_id_index` (`memberable_type`,`memberable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_members`
--

LOCK TABLES `library_members` WRITE;
/*!40000 ALTER TABLE `library_members` DISABLE KEYS */;
INSERT INTO `library_members` VALUES (1,'App\\Models\\Student',1,'L1001','2027-10-03',1,1,NULL,'2022-10-03 05:32:53','2022-10-03 05:32:53'),(2,'App\\Models\\Student',2,'L1002','2027-10-03',0,1,1,'2022-10-03 05:33:11','2022-10-03 05:42:05'),(3,'App\\Models\\Student',3,'L1003','2027-10-03',1,1,NULL,'2022-10-03 05:33:18','2022-10-03 05:33:18'),(4,'App\\Models\\Student',5,'L1004','2027-10-03',1,1,NULL,'2022-10-03 05:33:48','2022-10-03 05:33:48'),(5,'App\\Models\\Student',6,'L1005','2027-10-03',1,1,NULL,'2022-10-03 05:33:57','2022-10-03 05:33:57'),(6,'App\\Models\\Student',8,'L1006','2027-10-03',1,1,NULL,'2022-10-03 05:35:11','2022-10-03 05:35:11'),(7,'App\\User',9,'L1009','2027-10-03',1,1,NULL,'2022-10-03 05:40:24','2022-10-03 05:40:24'),(8,'App\\User',8,'L1010','2027-10-03',1,1,NULL,'2022-10-03 05:40:39','2022-10-03 05:40:39'),(9,'App\\User',6,'L1011','2027-10-03',1,1,NULL,'2022-10-03 05:40:49','2022-10-03 05:40:49'),(10,'App\\User',5,'L1012','2027-10-03',1,1,NULL,'2022-10-03 05:40:59','2022-10-03 05:40:59'),(11,'App\\User',4,'L1013','2027-10-03',0,1,1,'2022-10-03 05:41:09','2022-10-03 05:41:49'),(12,'App\\User',3,'L1014','2027-10-03',1,1,NULL,'2022-10-03 05:41:20','2022-10-03 05:41:20'),(13,'App\\User',1,'L1015','2027-10-03',1,1,NULL,'2022-10-03 05:41:29','2022-10-03 05:41:29'),(14,'App\\Models\\OutsideUser',1,'L1016','2027-10-03',1,1,NULL,'2022-10-03 05:44:53','2022-10-03 05:44:53'),(15,'App\\Models\\OutsideUser',2,'L1017','2027-10-03',1,1,NULL,'2022-10-03 05:45:41','2022-10-03 05:45:41'),(16,'App\\Models\\OutsideUser',3,'L1018','2027-10-03',0,1,1,'2022-10-03 05:46:30','2022-10-03 05:48:52'),(17,'App\\Models\\OutsideUser',4,'L1020','2027-10-03',1,1,NULL,'2022-10-03 05:48:01','2022-10-03 05:48:01'),(18,'App\\Models\\Student',10,'L1021','2027-10-04',1,1,NULL,'2022-10-04 07:39:22','2022-10-04 07:39:22'),(19,'App\\Models\\Student',11,'L1022','2027-10-04',1,1,NULL,'2022-10-04 07:39:31','2022-10-04 07:39:31'),(20,'App\\Models\\Student',13,'L1023','2027-10-04',0,1,1,'2022-10-04 07:39:42','2022-10-04 07:39:45'),(21,'App\\Models\\Student',14,'L1024','2027-10-04',1,1,NULL,'2022-10-04 07:39:52','2022-10-04 07:39:52');
/*!40000 ALTER TABLE `library_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_settings`
--

DROP TABLE IF EXISTS `mail_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `driver` text COLLATE utf8mb4_unicode_ci,
  `host` text COLLATE utf8mb4_unicode_ci,
  `port` text COLLATE utf8mb4_unicode_ci,
  `username` text COLLATE utf8mb4_unicode_ci,
  `password` text COLLATE utf8mb4_unicode_ci,
  `encryption` text COLLATE utf8mb4_unicode_ci,
  `sender_email` text COLLATE utf8mb4_unicode_ci,
  `sender_name` text COLLATE utf8mb4_unicode_ci,
  `reply_email` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_settings`
--

LOCK TABLES `mail_settings` WRITE;
/*!40000 ALTER TABLE `mail_settings` DISABLE KEYS */;
INSERT INTO `mail_settings` VALUES (1,'smtp','smtp.mailtrap.io','2525','5b1c119ce5a400','e177cd2e8894b5','tls','info@mail.com','Info Company','info@mail.com',1,'2022-09-30 12:00:47','2022-09-30 12:00:47');
/*!40000 ALTER TABLE `mail_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marksheet_settings`
--

DROP TABLE IF EXISTS `marksheet_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marksheet_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_left` text COLLATE utf8mb4_unicode_ci,
  `header_center` text COLLATE utf8mb4_unicode_ci,
  `header_right` text COLLATE utf8mb4_unicode_ci,
  `body` text COLLATE utf8mb4_unicode_ci,
  `footer_left` text COLLATE utf8mb4_unicode_ci,
  `footer_center` text COLLATE utf8mb4_unicode_ci,
  `footer_right` text COLLATE utf8mb4_unicode_ci,
  `logo_left` text COLLATE utf8mb4_unicode_ci,
  `logo_right` text COLLATE utf8mb4_unicode_ci,
  `background` text COLLATE utf8mb4_unicode_ci,
  `width` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `height` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `student_photo` tinyint(1) NOT NULL DEFAULT '0',
  `barcode` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `marksheet_settings_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marksheet_settings`
--

LOCK TABLES `marksheet_settings` WRITE;
/*!40000 ALTER TABLE `marksheet_settings` DISABLE KEYS */;
INSERT INTO `marksheet_settings` VALUES (1,'Our University Academic Transcript',NULL,NULL,NULL,NULL,'Controller','Director','Register','campus_365_(1)_1716408793.png','campus_365_(1)_1716408793.png',NULL,'800px','auto',0,0,1,'2022-10-01 02:44:46','2024-05-22 14:13:13');
/*!40000 ALTER TABLE `marksheet_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_schedules`
--

DROP TABLE IF EXISTS `meeting_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meeting_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `purpose` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `id_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `persons` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meeting_schedules_type_id_foreign` (`type_id`),
  CONSTRAINT `meeting_schedules_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `meeting_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_schedules`
--

LOCK TABLES `meeting_schedules` WRITE;
/*!40000 ALTER TABLE `meeting_schedules` DISABLE KEYS */;
INSERT INTO `meeting_schedules` VALUES (1,1,4,'Channing Hicks','Felix Conway','+1 (169) 929-4323','webizigi@mailinator.com','Ut sed proident del','Fugit provident ip','Est quam amet nobi','45','Pass-100001','2023-10-09','17:29:00','08:22:00','1',NULL,0,1,1,'2023-02-13 12:30:58','2023-08-25 07:41:26'),(2,2,8,'Elaine Guerra','Zeus Phelps','+1 (274) 544-4761','zaja@mailinator.com','Aut neque saepe pari','Fuga Obcaecati haru','Est minim iste ea re','54877','Pass-100002','2023-02-13','09:45:00','02:04:00','2',NULL,1,1,1,'2023-02-13 12:31:57','2023-02-13 12:37:11'),(3,2,5,'Kasimir Cooper','Yvonne Reid','+1 (322) 377-7963','dinalezo@mailinator.com','Provident omnis opt','Perspiciatis non cu','Aut est molestiae od','234','Pass-100003','2024-01-25','04:52:00','14:49:00','2',NULL,3,1,1,'2023-08-25 07:39:50','2023-08-25 07:41:35'),(4,1,1,'Rebekah Calderon','Kyle Armstrong','+1 (928) 388-3493','qezug@mailinator.com','Irure ipsam distinct','Et non et consequatu','Aliqua Et eu velit','35','Pass-100004','2024-03-05','23:35:00','13:21:00','1',NULL,1,1,NULL,'2023-08-25 07:40:20','2023-08-25 07:40:20');
/*!40000 ALTER TABLE `meeting_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_types`
--

DROP TABLE IF EXISTS `meeting_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meeting_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `meeting_types_title_unique` (`title`),
  UNIQUE KEY `meeting_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_types`
--

LOCK TABLES `meeting_types` WRITE;
/*!40000 ALTER TABLE `meeting_types` DISABLE KEYS */;
INSERT INTO `meeting_types` VALUES (1,'Board Meeting','board-meeting',NULL,1,'2023-02-13 12:23:18','2023-02-13 12:23:18'),(2,'Parent Teacher Meeting','parent-teacher-meeting',NULL,1,'2023-02-13 12:23:34','2023-02-13 12:23:34');
/*!40000 ALTER TABLE `meeting_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_12_14_000001_create_personal_access_tokens_table',1),(4,'2021_06_04_092405_create_faculties_table',1),(5,'2021_06_04_102314_create_programs_table',1),(6,'2021_06_04_114619_create_batches_table',1),(7,'2021_06_04_120154_create_sessions_table',1),(8,'2021_06_04_131456_create_semesters_table',1),(9,'2021_06_04_132856_create_sections_table',1),(10,'2021_06_04_141432_create_class_rooms_table',1),(11,'2021_06_05_121933_create_income_categories_table',1),(12,'2021_06_05_125236_create_incomes_table',1),(13,'2021_06_05_144224_create_expense_categories_table',1),(14,'2021_06_05_150317_create_expenses_table',1),(15,'2021_06_07_152605_create_subjects_table',1),(16,'2021_06_07_155306_create_enroll_subjects_table',1),(17,'2021_06_07_160042_create_enroll_subject_subject_table',1),(18,'2021_06_08_102053_create_program_subject_table',1),(19,'2021_06_08_105550_create_batch_program_table',1),(20,'2021_06_08_125338_create_program_semester_table',1),(21,'2021_06_08_125531_create_program_class_room_table',1),(22,'2021_06_08_180439_create_program_session_table',1),(23,'2021_06_08_182844_create_program_semester_sections_table',1),(24,'2021_06_09_133442_create_class_routines_table',1),(25,'2021_06_12_153215_create_departments_table',1),(26,'2021_06_12_155411_create_designations_table',1),(27,'2021_06_13_075755_create_leave_types_table',1),(28,'2021_06_13_125451_create_leaves_table',1),(29,'2021_06_13_173512_create_work_shift_types_table',1),(30,'2021_06_13_175400_create_tax_settings_table',1),(31,'2021_06_13_193417_create_user_program_table',1),(32,'2021_06_15_184223_create_staff_attendances_table',1),(33,'2021_06_16_180912_create_staff_hourly_attendances_table',1),(34,'2021_06_17_083411_create_payrolls_table',1),(35,'2021_06_22_185503_create_jobs_table',1),(36,'2021_07_07_081616_create_students_table',1),(37,'2021_07_07_182329_create_student_relatives_table',1),(38,'2021_07_07_190034_create_documents_table',1),(39,'2021_07_07_192727_create_docables_table',1),(40,'2021_07_08_054948_create_student_enrolls_table',1),(41,'2021_07_08_172152_create_student_transfers_table',1),(42,'2021_07_08_195650_create_transfer_creadits_table',1),(43,'2021_07_09_061940_create_status_types_table',1),(44,'2021_07_09_092958_create_status_type_student_table',1),(45,'2021_07_09_163443_create_student_enroll_subject_table',1),(46,'2021_07_09_173413_create_student_leaves_table',1),(47,'2021_07_09_194126_create_student_attendances_table',1),(48,'2021_07_17_160726_create_events_table',1),(49,'2021_07_18_074323_create_notice_categories_table',1),(50,'2021_07_18_080209_create_notices_table',1),(51,'2021_07_18_105550_create_noticeables_table',1),(52,'2021_07_19_182908_create_email_notifies_table',1),(53,'2021_07_19_200327_create_s_m_s_notifies_table',1),(54,'2021_09_01_070002_create_exam_types_table',1),(55,'2021_09_01_071547_create_result_contributions_table',1),(56,'2021_09_01_084615_create_grades_table',1),(57,'2021_09_02_184433_create_exams_table',1),(58,'2021_09_04_101915_create_subject_markings_table',1),(59,'2021_09_27_183257_create_certificate_templates_table',1),(60,'2021_10_01_163600_create_certificates_table',1),(61,'2021_10_15_182241_create_marksheet_settings_table',1),(62,'2022_01_21_142336_create_print_settings_table',1),(63,'2022_01_21_170648_create_visit_purposes_table',1),(64,'2022_01_21_171901_create_visitors_table',1),(65,'2022_01_21_185105_create_postal_exchange_types_table',1),(66,'2022_01_21_185152_create_postal_exchanges_table',1),(67,'2022_01_21_185201_create_phone_logs_table',1),(68,'2022_01_22_103339_create_complain_types_table',1),(69,'2022_01_22_103551_create_complain_sources_table',1),(70,'2022_01_22_103657_create_complains_table',1),(71,'2022_01_23_103439_create_enquiry_sources_table',1),(72,'2022_01_23_110653_create_enquiry_references_table',1),(73,'2022_01_23_114509_create_enquiries_table',1),(74,'2022_01_24_174515_create_assignments_table',1),(75,'2022_01_24_179252_create_student_assignments_table',1),(76,'2022_01_24_181419_create_content_types_table',1),(77,'2022_01_25_165931_create_contents_table',1),(78,'2022_01_26_105511_create_contentables_table',1),(79,'2022_01_27_100200_create_notifications_table',1),(80,'2022_01_28_131433_create_book_categories_table',1),(81,'2022_01_28_173902_create_books_table',1),(82,'2022_01_29_045003_create_outside_users_table',1),(83,'2022_01_29_045120_create_library_members_table',1),(84,'2022_01_29_093915_create_issue_returns_table',1),(85,'2022_01_31_061950_create_notes_table',1),(86,'2022_02_15_173515_create_fees_categories_table',1),(87,'2022_02_15_182124_create_fees_masters_table',1),(88,'2022_02_16_100327_create_fees_master_student_enroll',1),(89,'2022_02_26_184930_create_fees_fines_table',1),(90,'2022_02_26_191642_create_fees_category_fees_fine_table',1),(91,'2022_03_04_172257_create_fees_discounts_table',1),(92,'2022_03_05_132058_create_fees_category_fees_discount_table',1),(93,'2022_03_05_132541_create_fees_discount_status_type_table',1),(94,'2022_03_05_195051_create_fees_table',1),(95,'2022_03_05_203440_create_transactions_table',1),(96,'2022_03_10_131324_create_exam_routines_table',1),(97,'2022_03_10_131936_create_exam_routine_user_table',1),(98,'2022_03_10_132124_create_exam_routine_room_table',1),(99,'2022_03_31_074913_create_id_card_settings_table',1),(100,'2022_04_01_125726_create_settings_table',1),(101,'2022_04_01_210417_create_languages_table',1),(102,'2022_04_02_144303_create_permission_tables',1),(103,'2022_04_03_103141_create_mail_settings_table',1),(104,'2022_04_03_173021_create_s_m_s_settings_table',1),(105,'2022_04_03_174009_create_schedule_settings_table',1),(106,'2022_04_04_123222_create_provinces_table',1),(107,'2022_04_04_173222_create_districts_table',1),(108,'2021_06_17_183706_create_payroll_details_table',2),(109,'2021_07_04_172713_create_application_settings_table',2),(110,'2021_07_06_121630_create_applications_table',2),(111,'2022_01_23_192650_create_meeting_types_table',2),(112,'2022_01_23_202252_create_meeting_schedules_table',2),(113,'2022_01_28_195224_create_book_requests_table',2),(114,'2022_11_20_171503_create_item_categories_table',2),(115,'2022_11_20_182303_create_item_stores_table',2),(116,'2022_11_20_185841_create_item_suppliers_table',2),(117,'2022_11_21_190954_create_items_table',2),(118,'2022_11_21_194218_create_item_stocks_table',2),(119,'2022_11_21_200834_create_item_issues_table',2),(120,'2022_12_08_140339_create_hostel_room_types_table',2),(121,'2022_12_08_193208_create_hostels_table',2),(122,'2022_12_10_203126_create_hostel_rooms_table',2),(123,'2022_12_14_181050_create_hostel_members_table',2),(124,'2022_12_22_112935_create_transport_routes_table',2),(125,'2022_12_23_110116_create_transport_vehicles_table',2),(126,'2022_12_23_112400_create_transport_route_transport_vehicle_table',2),(127,'2022_12_24_121402_create_transport_members_table',2),(128,'2022_12_29_173356_add_fields_to_tables',2),(129,'2023_08_12_153552_add_fields_v3_to_table',3),(130,'2023_08_12_174813_create_fields_table',3),(131,'2023_08_15_010030_create_topbar_settings_table',3),(132,'2023_08_15_010553_create_social_settings_table',3),(133,'2023_08_15_025440_create_sliders_table',3),(134,'2023_08_15_034340_create_features_table',3),(135,'2023_08_15_043734_create_about_us_table',3),(136,'2023_08_15_112651_create_faqs_table',3),(137,'2023_08_15_115731_create_testimonials_table',3),(138,'2023_08_15_121544_create_call_to_actions_table',3),(139,'2023_08_16_172019_create_galleries_table',3),(140,'2023_08_16_172620_create_courses_table',3),(141,'2023_08_16_173224_create_web_events_table',3),(142,'2023_08_16_173331_create_news_table',3),(143,'2023_08_23_142818_create_pages_table',3),(144,'2025_04_25_231234_create_assigned_courses_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\User',1),(4,'App\\User',2),(6,'App\\User',3),(6,'App\\User',4),(6,'App\\User',5),(5,'App\\User',6),(6,'App\\User',7),(3,'App\\User',8),(2,'App\\User',9);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,1,'With our vastly improved notifications system, users have more control','with-our-vastly-improved-notifications-system-users-have-more-control','2023-07-27','<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo amet set for your cool happiness for lyour loyal city.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deser unt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusant ium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit asperna tur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisq.</p>\r\n<p>&nbsp;</p>',NULL,NULL,'inner_b1_1692916385.jpg',1,'2023-08-24 16:30:23','2023-08-25 05:33:37'),(2,1,'There are many variations passages of like consectetur lorem ipsum available.','there-are-many-variations-passages-of-like-consectetur-lorem-ipsum-available','2023-08-01','<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo amet set for your cool happiness for lyour loyal city.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deser unt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusant ium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit asperna tur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisq.</p>\r\n<p>&nbsp;</p>',NULL,NULL,'inner_b2_1692916294.jpg',1,'2023-08-24 16:31:34','2023-08-25 05:33:19'),(3,1,'I must explain to you how all this mistaken idea of denouncing pleasure.','i-must-explain-to-you-how-all-this-mistaken-idea-of-denouncing-pleasure','2023-08-24','<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo amet set for your cool happiness for lyour loyal city.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deser unt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusant ium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit asperna tur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisq.</p>\r\n<p>&nbsp;</p>',NULL,NULL,'inner_b3_1692916324.jpg',1,'2023-08-24 16:32:04','2023-08-24 16:32:04');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `noteable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `noteable_id` bigint(20) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notes_noteable_type_noteable_id_index` (`noteable_type`,`noteable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (1,'App\\User',7,'Ex maxime do expedit','Eligendi placeat ea',NULL,1,1,NULL,'2022-10-02 11:56:15','2022-10-02 11:56:15'),(2,'App\\User',9,'Nemo libero maiores','Est nemo irure qui e','book-covers_1664733426.jpg',1,1,1,'2022-10-02 11:56:20','2022-10-02 11:57:06'),(3,'App\\User',8,'Dolorum voluptatem e','Mollitia at odit num',NULL,1,1,NULL,'2022-10-02 11:56:55','2022-10-02 11:56:55'),(4,'App\\Models\\Student',3,'Dolor aut excepturi','Culpa labore fugit',NULL,1,1,NULL,'2022-10-02 12:40:45','2022-10-02 12:40:45'),(5,'App\\Models\\Student',6,'Magna culpa distinc','At ullam magni autem','book-covers_1664736057.jpg',1,1,NULL,'2022-10-02 12:40:57','2022-10-02 12:40:57'),(6,'App\\Models\\Student',4,'Et nulla sint ut no','Rerum sit nostrud l',NULL,1,1,NULL,'2022-10-02 12:41:02','2022-10-02 12:41:02'),(7,'App\\Models\\Student',1,'Est magnam exercita','Aliquid deserunt asp','book-cover2_1664736079.jpg',1,1,NULL,'2022-10-02 12:41:19','2022-10-02 12:41:19'),(8,'App\\Models\\Student',13,'Assumenda ad corpori','Qui ea impedit a ex','background-border_1664885966.png',1,1,NULL,'2022-10-04 06:19:26','2022-10-04 06:19:26');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice_categories`
--

DROP TABLE IF EXISTS `notice_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notice_categories_title_unique` (`title`),
  UNIQUE KEY `notice_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_categories`
--

LOCK TABLES `notice_categories` WRITE;
/*!40000 ALTER TABLE `notice_categories` DISABLE KEYS */;
INSERT INTO `notice_categories` VALUES (1,'Exam','exam',NULL,1,'2022-09-30 14:11:08','2022-09-30 14:11:54'),(2,'Vacation','vacation',NULL,1,'2022-09-30 14:11:23','2022-09-30 14:12:05'),(3,'Festival','festival',NULL,1,'2022-09-30 14:11:41','2022-09-30 14:12:00'),(4,'Competitive Event','competitive-event',NULL,1,'2022-10-01 04:08:04','2022-10-01 04:08:04');
/*!40000 ALTER TABLE `notice_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `noticeables`
--

DROP TABLE IF EXISTS `noticeables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `noticeables` (
  `notice_id` bigint(20) NOT NULL,
  `noticeable_id` bigint(20) NOT NULL,
  `noticeable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `noticeables`
--

LOCK TABLES `noticeables` WRITE;
/*!40000 ALTER TABLE `noticeables` DISABLE KEYS */;
INSERT INTO `noticeables` VALUES (1,4,'App\\Models\\Student'),(1,3,'App\\Models\\Student'),(1,2,'App\\Models\\Student'),(1,1,'App\\Models\\Student'),(2,14,'App\\Models\\Student'),(2,12,'App\\Models\\Student'),(2,11,'App\\Models\\Student'),(2,10,'App\\Models\\Student');
/*!40000 ALTER TABLE `noticeables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `semester_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `notice_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `date` date NOT NULL,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notices_notice_no_unique` (`notice_no`),
  KEY `notices_category_id_foreign` (`category_id`),
  CONSTRAINT `notices_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `notice_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` VALUES (1,2,3,0,0,0,4,'1001','Android Development Hackathon 2022','<p>Hackathon Android App Innovation Challenge in will happen on Feb 20th 2022. ... To develop an innovative applications which can be helpful for society.</p>\r\n<p>&nbsp;</p>','2022-10-03','book-covers_1664819413.jpg',1,1,1,'2022-10-03 11:50:13','2022-10-03 14:55:38'),(2,2,3,4,1,0,2,'1004','Winter Vacation Pick On From Sunday','<p>Winter Vacations for Sun and Scene Seekers: The Caribbean​​ The Caribbean has long drawn couples, families and friends for easy warm-weather getaways, thanks to</p>','2022-10-04','Provisional Certificate-100001_1664890296.pdf',1,1,NULL,'2022-10-04 07:31:36','2022-10-04 07:31:36');
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('011f54a5-007b-47ec-8ca0-ef8d4d02377e','App\\Notifications\\ContentNotification','App\\Models\\Student',12,'{\"id\":3,\"title\":\"2nd Class Of English\",\"type\":\"content\"}',NULL,'2022-10-04 07:22:41','2022-10-04 07:22:41'),('07aab651-5c90-4523-86b8-d27aae1056ec','App\\Notifications\\NoticeNotification','App\\Models\\Student',1,'{\"id\":1,\"title\":\"Android Development Hackathon 2022\",\"type\":\"notice\"}',NULL,'2022-10-03 11:50:13','2022-10-03 11:50:13'),('11a62dee-3881-4ac4-8a3b-df96a73781de','App\\Notifications\\NoticeNotification','App\\Models\\Student',10,'{\"id\":2,\"title\":\"Winter Vacation Pick On From Sunday\",\"type\":\"notice\"}',NULL,'2022-10-04 07:31:37','2022-10-04 07:31:37'),('141e4e0d-3663-43b1-a7be-dc7674e5928d','App\\Notifications\\ContentNotification','App\\Models\\Student',11,'{\"id\":3,\"title\":\"2nd Class Of English\",\"type\":\"content\"}',NULL,'2022-10-04 07:22:41','2022-10-04 07:22:41'),('15b99a58-fcc8-4de2-a8dc-f47df77d7134','App\\Notifications\\AssignmentNotification','App\\Models\\Student',3,'{\"id\":1,\"title\":\"Theory of relativity\",\"type\":\"assignment\"}',NULL,'2022-10-03 11:10:03','2022-10-03 11:10:03'),('1664d794-1262-4ee9-aca5-c3ea560e4291','App\\Notifications\\NoticeNotification','App\\Models\\Student',4,'{\"id\":1,\"title\":\"Android Development Hackathon 2022\",\"type\":\"notice\"}',NULL,'2022-10-03 11:50:13','2022-10-03 11:50:13'),('1e6faade-b601-4573-8611-252bd426a5e4','App\\Notifications\\ContentNotification','App\\Models\\Student',14,'{\"id\":3,\"title\":\"2nd Class Of English\",\"type\":\"content\"}','2022-10-04 07:32:42','2022-10-04 07:22:41','2022-10-04 07:32:42'),('27700e79-b1ef-4aea-84a5-dca35601e2c7','App\\Notifications\\AssignmentNotification','App\\Models\\Student',14,'{\"id\":5,\"title\":\"Rules of voice change\",\"type\":\"assignment\"}','2022-10-04 07:32:47','2022-10-04 07:22:41','2022-10-04 07:32:47'),('31bf7290-9e38-4131-9f5c-7a972e49616a','App\\Notifications\\NoticeNotification','App\\Models\\Student',14,'{\"id\":2,\"title\":\"Winter Vacation Pick On From Sunday\",\"type\":\"notice\"}','2022-10-04 07:32:02','2022-10-04 07:31:37','2022-10-04 07:32:02'),('5b2538da-38e9-4a7a-9d5e-12a5b71bdf90','App\\Notifications\\ContentNotification','App\\Models\\Student',7,'{\"id\":1,\"title\":\"Optical Physics 1st Class\",\"type\":\"content\"}',NULL,'2022-10-03 07:12:59','2022-10-03 07:12:59'),('6ca44526-326d-40f7-80a2-cd99f3a77fcd','App\\Notifications\\AssignmentNotification','App\\Models\\Student',10,'{\"id\":3,\"title\":\"Rules of Article\",\"type\":\"assignment\"}',NULL,'2022-10-04 07:22:41','2022-10-04 07:22:41'),('70bf8a20-bd71-403e-bd84-006b6e524a66','App\\Notifications\\AssignmentNotification','App\\Models\\Student',1,'{\"id\":1,\"title\":\"Theory of relativity\",\"type\":\"assignment\"}',NULL,'2022-10-03 11:10:03','2022-10-03 11:10:03'),('785f549e-c101-40f4-b4f8-134c2cd2a0fe','App\\Notifications\\AssignmentNotification','App\\Models\\Student',11,'{\"id\":3,\"title\":\"Rules of Article\",\"type\":\"assignment\"}',NULL,'2022-10-04 07:22:41','2022-10-04 07:22:41'),('839d685b-468a-459c-b7e1-8d4b74e7d5df','App\\Notifications\\AssignmentNotification','App\\Models\\Student',8,'{\"id\":2,\"title\":\"Measurement and Height\",\"type\":\"assignment\"}',NULL,'2022-10-03 11:13:04','2022-10-03 11:13:04'),('93f6ddc6-d6a9-4e6d-b492-d417e1b9b2f7','App\\Notifications\\AssignmentNotification','App\\Models\\Student',4,'{\"id\":1,\"title\":\"Theory of relativity\",\"type\":\"assignment\"}',NULL,'2022-10-03 11:10:03','2022-10-03 11:10:03'),('9ba811dd-0e6a-4070-b216-069614bc2b9d','App\\Notifications\\ContentNotification','App\\Models\\Student',10,'{\"id\":3,\"title\":\"2nd Class Of English\",\"type\":\"content\"}',NULL,'2022-10-04 07:22:41','2022-10-04 07:22:41'),('a3f21e8d-3610-40b8-a2e5-7b1a94bf90e6','App\\Notifications\\AssignmentNotification','App\\Models\\Student',10,'{\"id\":5,\"title\":\"Rules of voice change\",\"type\":\"assignment\"}',NULL,'2022-10-04 07:22:41','2022-10-04 07:22:41'),('a67fd579-3132-4fb3-9107-9108ecc310c8','App\\Notifications\\AssignmentNotification','App\\Models\\Student',12,'{\"id\":3,\"title\":\"Rules of Article\",\"type\":\"assignment\"}','2022-10-04 07:23:16','2022-10-04 07:22:41','2022-10-04 07:23:16'),('a9e0eaac-ddc8-44b7-9a05-c280aa5ce15e','App\\Notifications\\ContentNotification','App\\Models\\Student',8,'{\"id\":1,\"title\":\"Optical Physics 1st Class\",\"type\":\"content\"}',NULL,'2022-10-03 07:12:59','2022-10-03 07:12:59'),('b131cbc5-8f6d-46af-85ba-99e114a468f7','App\\Notifications\\NoticeNotification','App\\Models\\Student',3,'{\"id\":1,\"title\":\"Android Development Hackathon 2022\",\"type\":\"notice\"}',NULL,'2022-10-03 11:50:13','2022-10-03 11:50:13'),('c150c5b3-2d00-465e-bb7c-8fb0506f4cb7','App\\Notifications\\NoticeNotification','App\\Models\\Student',12,'{\"id\":2,\"title\":\"Winter Vacation Pick On From Sunday\",\"type\":\"notice\"}',NULL,'2022-10-04 07:31:37','2022-10-04 07:31:37'),('c223bf63-bf78-4425-b70d-d7f0ed751ba9','App\\Notifications\\AssignmentNotification','App\\Models\\Student',12,'{\"id\":5,\"title\":\"Rules of voice change\",\"type\":\"assignment\"}','2022-10-04 07:23:16','2022-10-04 07:22:41','2022-10-04 07:23:16'),('cdd8fdc1-b992-4df9-a1d7-833bc22c1728','App\\Notifications\\AssignmentNotification','App\\Models\\Student',14,'{\"id\":3,\"title\":\"Rules of Article\",\"type\":\"assignment\"}','2022-10-04 07:32:47','2022-10-04 07:22:41','2022-10-04 07:32:47'),('d1693c75-da05-4cb0-a5fa-4e0e98eed4f4','App\\Notifications\\NoticeNotification','App\\Models\\Student',2,'{\"id\":1,\"title\":\"Android Development Hackathon 2022\",\"type\":\"notice\"}',NULL,'2022-10-03 11:50:13','2022-10-03 11:50:13'),('d86483c2-2cac-4a32-a274-aa402c0c63d5','App\\Notifications\\AssignmentNotification','App\\Models\\Student',2,'{\"id\":1,\"title\":\"Theory of relativity\",\"type\":\"assignment\"}',NULL,'2022-10-03 11:10:03','2022-10-03 11:10:03'),('edf49484-fd6d-4d28-9024-dab31f141b7a','App\\Notifications\\AssignmentNotification','App\\Models\\Student',7,'{\"id\":2,\"title\":\"Measurement and Height\",\"type\":\"assignment\"}',NULL,'2022-10-03 11:13:04','2022-10-03 11:13:04'),('f3bcc8a3-b372-4657-9f29-ea4438f455bc','App\\Notifications\\AssignmentNotification','App\\Models\\Student',11,'{\"id\":5,\"title\":\"Rules of voice change\",\"type\":\"assignment\"}',NULL,'2022-10-04 07:22:41','2022-10-04 07:22:41'),('fa65ad88-4332-42ac-a773-796203413c68','App\\Notifications\\NoticeNotification','App\\Models\\Student',11,'{\"id\":2,\"title\":\"Winter Vacation Pick On From Sunday\",\"type\":\"notice\"}',NULL,'2022-10-04 07:31:37','2022-10-04 07:31:37');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outside_users`
--

DROP TABLE IF EXISTS `outside_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outside_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `present_province` int(10) unsigned DEFAULT NULL,
  `present_district` int(10) unsigned DEFAULT NULL,
  `present_village` text COLLATE utf8mb4_unicode_ci,
  `present_address` text COLLATE utf8mb4_unicode_ci,
  `permanent_province` int(10) unsigned DEFAULT NULL,
  `permanent_district` int(10) unsigned DEFAULT NULL,
  `permanent_village` text COLLATE utf8mb4_unicode_ci,
  `permanent_address` text COLLATE utf8mb4_unicode_ci,
  `education_level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL COMMENT '1 Male, 2 Female & 3 Other',
  `dob` date NOT NULL,
  `mother_tongue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` int(11) DEFAULT NULL,
  `blood_group` int(11) DEFAULT NULL,
  `nationality` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `national_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` text COLLATE utf8mb4_unicode_ci,
  `signature` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Inactive, 1 Active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `father_occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father_photo` text COLLATE utf8mb4_unicode_ci,
  `mother_photo` text COLLATE utf8mb4_unicode_ci,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `religion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caste` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `outside_users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outside_users`
--

LOCK TABLES `outside_users` WRITE;
/*!40000 ALTER TABLE `outside_users` DISABLE KEYS */;
INSERT INTO `outside_users` VALUES (1,'Jason','Suarez','Cassady Houston',NULL,'rodemy@mailinator.com','+1 (133) 832-2324',4,3,'Excepteur consequatu','Est ea elit ducimus',2,13,'Nam quia consequat','Amet occaecat est e',NULL,'Tempora incidunt',1,'1999-02-06',NULL,2,NULL,NULL,'4568798763153','5468657354468',NULL,NULL,1,1,NULL,'2022-10-03 05:44:53','2022-10-03 05:44:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'Garth','Bernard','Colby Jacobs',NULL,'wygicyb@mailinator.com','+1 (548) 812-6473',4,3,'Quasi dolores enim q','Sit harum alias mol',1,1,'Quis aute duis dolor','Enim voluptas quia d',NULL,'Quia impedit',2,'1989-11-30','English',4,NULL,NULL,'76554633543','43865438','student_1664797541.jpg',NULL,1,1,NULL,'2022-10-03 05:45:41','2022-10-03 05:45:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'Neville','Frye','Medge Grimes',NULL,'corojeja@mailinator.com','+1 (204) 668-8836',4,3,'Eius perspiciatis c','Delectus consequatu',4,4,'Esse natus ut velit','Ducimus voluptate r',NULL,NULL,2,'2014-03-07','Bangla',4,NULL,NULL,'56789688','876856876',NULL,NULL,1,1,NULL,'2022-10-03 05:46:30','2022-10-03 05:46:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'Vivien','Tyler','Holmes Walls',NULL,'semat@mailinator.com','+1 (686) 105-7363',4,5,'Quae nisi quas in pr','Repudiandae veritati',4,5,'Et aliquid qui excep','Explicabo Magnam un',NULL,'Quo deleniti',3,'1970-07-13','English',1,NULL,NULL,'55489789441','124897891','student_1664797681.jpg',NULL,1,1,NULL,'2022-10-03 05:48:01','2022-10-03 05:48:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `outside_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_title_unique` (`title`),
  UNIQUE KEY `pages_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,1,'Requirements','requirements','<h4>What is Lorem Ipsum?</h4>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<h4>Why do we use it?</h4>\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n<p>&nbsp;</p>\r\n<h4>Where does it come from?</h4>\r\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>',NULL,NULL,NULL,1,'2023-08-24 16:05:03','2023-08-25 05:35:21'),(2,1,'Tuition Fees','tuition-fees','<h4>Where does it come from?</h4>\r\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>\r\n<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n<h4>Where can I get some?</h4>\r\n<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n<p>&nbsp;</p>',NULL,NULL,NULL,1,'2023-08-24 16:06:39','2023-08-25 05:35:45');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_details`
--

DROP TABLE IF EXISTS `payroll_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payroll_id` bigint(20) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Deduction, 1 Allowance',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_details_payroll_id_foreign` (`payroll_id`),
  CONSTRAINT `payroll_details_payroll_id_foreign` FOREIGN KEY (`payroll_id`) REFERENCES `payrolls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_details`
--

LOCK TABLES `payroll_details` WRITE;
/*!40000 ALTER TABLE `payroll_details` DISABLE KEYS */;
INSERT INTO `payroll_details` VALUES (1,1,'Eid Bonus',2000.00,1,NULL,NULL,'2023-02-13 12:00:01','2023-02-13 12:00:01'),(2,1,'Lunch',1500.00,0,NULL,NULL,'2023-02-13 12:00:01','2023-02-13 12:00:01'),(3,2,'Eid Bonus',3500.00,1,NULL,NULL,'2023-02-13 12:00:30','2023-02-13 12:00:30'),(4,2,'Lunch',1200.00,0,NULL,NULL,'2023-02-13 12:00:30','2023-02-13 12:00:30'),(5,3,'Bonus',5000.00,1,NULL,NULL,'2023-02-13 12:00:59','2023-02-13 12:00:59'),(6,3,'Snaks',300.00,0,NULL,NULL,'2023-02-13 12:00:59','2023-02-13 12:00:59'),(7,4,'Transport',2500.00,1,NULL,NULL,'2023-02-13 12:01:32','2023-02-13 12:01:32'),(8,4,'Late',1200.00,0,NULL,NULL,'2023-02-13 12:01:32','2023-02-13 12:01:32'),(9,5,'Eid Bonus',2500.00,1,NULL,NULL,'2023-02-13 12:02:07','2023-02-13 12:02:07'),(10,5,'Lunch',1200.00,0,NULL,NULL,'2023-02-13 12:02:07','2023-02-13 12:02:07');
/*!40000 ALTER TABLE `payroll_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payrolls`
--

DROP TABLE IF EXISTS `payrolls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `basic_salary` double(10,2) NOT NULL DEFAULT '0.00',
  `salary_type` int(11) NOT NULL DEFAULT '1' COMMENT '1 Fixed & 2 Hourly',
  `total_earning` double(10,2) NOT NULL,
  `total_allowance` double(10,2) NOT NULL DEFAULT '0.00',
  `bonus` double(10,2) NOT NULL DEFAULT '0.00',
  `gross_salary` double(10,2) NOT NULL,
  `total_deduction` double(10,2) NOT NULL,
  `tax` double(10,2) NOT NULL DEFAULT '0.00',
  `net_salary` double(10,2) NOT NULL,
  `salary_month` date NOT NULL,
  `pay_date` date DEFAULT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 Unpaid, 1 Paid',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payrolls`
--

LOCK TABLES `payrolls` WRITE;
/*!40000 ALTER TABLE `payrolls` DISABLE KEYS */;
INSERT INTO `payrolls` VALUES (1,2,40000.00,1,15484.00,2000.00,0.00,15984.00,1500.00,1099.00,14886.00,'2022-10-01','2023-02-13',3,NULL,1,1,1,'2022-10-03 15:35:22','2023-02-13 12:02:40'),(2,6,40000.00,1,20645.00,3500.00,0.00,22945.00,1200.00,2692.00,20254.00,'2022-10-01',NULL,NULL,NULL,0,1,NULL,'2022-10-03 15:35:34','2023-02-13 12:00:30'),(3,7,38000.00,1,14710.00,5000.00,0.00,19410.00,300.00,1441.00,17969.00,'2022-10-01','2023-02-13',5,NULL,1,1,1,'2022-10-03 15:36:45','2023-02-13 12:02:49'),(4,8,35000.00,1,15806.00,2500.00,0.00,17106.00,1200.00,1211.00,15896.00,'2022-10-01',NULL,NULL,NULL,0,1,1,'2022-10-03 15:37:27','2023-02-13 12:01:32'),(5,3,300.00,2,3000.00,2500.00,0.00,4300.00,1200.00,0.00,4300.00,'2022-10-01','2023-02-13',2,NULL,1,1,1,'2022-10-03 15:44:50','2023-02-13 12:02:24');
/*!40000 ALTER TABLE `payrolls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1506 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1068,'application-view','Application','View','web',NULL,NULL),(1069,'application-create','Application','Admission','web',NULL,NULL),(1070,'application-edit','Application','Action','web',NULL,NULL),(1071,'application-delete','Application','Delete','web',NULL,NULL),(1072,'student-view','Student','View','web',NULL,NULL),(1073,'student-create','Student','Create','web',NULL,NULL),(1074,'student-edit','Student','Edit','web',NULL,NULL),(1075,'student-delete','Student','Delete','web',NULL,NULL),(1076,'student-import','Student','Import','web',NULL,NULL),(1077,'student-password-print','Student','Password Print','web',NULL,NULL),(1078,'student-password-change','Student','Password Change','web',NULL,NULL),(1079,'student-card','Student','ID Card','web',NULL,NULL),(1080,'id-card-setting-view','ID Card','Setting','web',NULL,NULL),(1081,'student-transfer-in-view','Student Transfer In','View','web',NULL,NULL),(1082,'student-transfer-in-create','Student Transfer In','Transfer','web',NULL,NULL),(1083,'student-transfer-in-edit','Student Transfer In','Edit','web',NULL,NULL),(1084,'student-transfer-out-view','Student Transfer Out','View','web',NULL,NULL),(1085,'student-transfer-out-create','Student Transfer Out','Transfer','web',NULL,NULL),(1086,'student-transfer-out-edit','Student Transfer Out','Edit','web',NULL,NULL),(1087,'status-type-view','Status Type','View','web',NULL,NULL),(1088,'status-type-create','Status Type','Create','web',NULL,NULL),(1089,'status-type-edit','Status Type','Edit','web',NULL,NULL),(1090,'status-type-delete','Status Type','Delete','web',NULL,NULL),(1091,'student-attendance-action','Student Attendance','Manage','web',NULL,NULL),(1092,'student-attendance-report','Student Attendance','Report','web',NULL,NULL),(1093,'student-attendance-import','Student Attendance','Import','web',NULL,NULL),(1094,'student-leave-manage-view','Student Leave Manage','View','web',NULL,NULL),(1095,'student-leave-manage-edit','Student Leave Manage','Action','web',NULL,NULL),(1096,'student-leave-manage-delete','Student Leave Manage','Delete','web',NULL,NULL),(1097,'student-note-view','Student Note','View','web',NULL,NULL),(1098,'student-note-create','Student Note','Create','web',NULL,NULL),(1099,'student-note-edit','Student Note','Edit','web',NULL,NULL),(1100,'student-note-delete','Student Note','Delete','web',NULL,NULL),(1101,'student-enroll-single','Student Enroll','Single Enroll','web',NULL,NULL),(1102,'student-enroll-group','Student Enroll','Group Enroll','web',NULL,NULL),(1103,'student-enroll-adddrop','Student Enroll','Course Add Drop','web',NULL,NULL),(1104,'student-enroll-complete','Student Enroll','Course Complete','web',NULL,NULL),(1105,'student-enroll-alumni','Student Enroll','Student Alumni','web',NULL,NULL),(1106,'faculty-view','Faculty','View','web',NULL,NULL),(1107,'faculty-create','Faculty','Create','web',NULL,NULL),(1108,'faculty-edit','Faculty','Edit','web',NULL,NULL),(1109,'faculty-delete','Faculty','Delete','web',NULL,NULL),(1110,'program-view','Program','View','web',NULL,NULL),(1111,'program-create','Program','Create','web',NULL,NULL),(1112,'program-edit','Program','Edit','web',NULL,NULL),(1113,'program-delete','Program','Delete','web',NULL,NULL),(1114,'batch-view','Batch','View','web',NULL,NULL),(1115,'batch-create','Batch','Create','web',NULL,NULL),(1116,'batch-edit','Batch','Edit','web',NULL,NULL),(1117,'batch-delete','Batch','Delete','web',NULL,NULL),(1118,'session-view','Session','View','web',NULL,NULL),(1119,'session-create','Session','Create','web',NULL,NULL),(1120,'session-edit','Session','Edit','web',NULL,NULL),(1121,'session-delete','Session','Delete','web',NULL,NULL),(1122,'semester-view','Semester','View','web',NULL,NULL),(1123,'semester-create','Semester','Create','web',NULL,NULL),(1124,'semester-edit','Semester','Edit','web',NULL,NULL),(1125,'semester-delete','Semester','Delete','web',NULL,NULL),(1126,'section-view','Section','View','web',NULL,NULL),(1127,'section-create','Section','Create','web',NULL,NULL),(1128,'section-edit','Section','Edit','web',NULL,NULL),(1129,'section-delete','Section','Delete','web',NULL,NULL),(1130,'class-room-view','Class Room','View','web',NULL,NULL),(1131,'class-room-create','Class Room','Create','web',NULL,NULL),(1132,'class-room-edit','Class Room','Edit','web',NULL,NULL),(1133,'class-room-delete','Class Room','Delete','web',NULL,NULL),(1134,'subject-view','Course','View','web',NULL,NULL),(1135,'subject-create','Course','Create','web',NULL,NULL),(1136,'subject-edit','Course','Edit','web',NULL,NULL),(1137,'subject-delete','Course','Delete','web',NULL,NULL),(1138,'subject-import','Course','Import','web',NULL,NULL),(1139,'enroll-subject-view','Enroll Course','View','web',NULL,NULL),(1140,'enroll-subject-create','Enroll Course','Create','web',NULL,NULL),(1141,'enroll-subject-edit','Enroll Course','Edit','web',NULL,NULL),(1142,'enroll-subject-delete','Enroll Course','Delete','web',NULL,NULL),(1143,'class-routine-view','Class Routine','View','web',NULL,NULL),(1144,'class-routine-create','Class Routine','Manage','web',NULL,NULL),(1145,'class-routine-print','Class Routine','Print','web',NULL,NULL),(1146,'exam-routine-view','Exam Routine','View','web',NULL,NULL),(1147,'exam-routine-create','Exam Routine','Create','web',NULL,NULL),(1148,'exam-routine-edit','Exam Routine','Edit','web',NULL,NULL),(1149,'exam-routine-delete','Exam Routine','Delete','web',NULL,NULL),(1150,'exam-routine-print','Exam Routine','Print','web',NULL,NULL),(1151,'class-routine-teacher','Teacher Routine','View','web',NULL,NULL),(1152,'routine-setting-class','Routine Setting','Class Routine','web',NULL,NULL),(1153,'routine-setting-exam','Routine Setting','Exam Routine','web',NULL,NULL),(1154,'exam-attendance','Exam','Attendance','web',NULL,NULL),(1155,'exam-marking','Exam','Mark Ledger','web',NULL,NULL),(1156,'exam-result','Exam','Result','web',NULL,NULL),(1157,'exam-import','Exam','Import','web',NULL,NULL),(1158,'subject-marking','Course Final','Mark Ledger','web',NULL,NULL),(1159,'subject-result','Course Final','Result','web',NULL,NULL),(1160,'grade-view','Grade','View','web',NULL,NULL),(1161,'grade-create','Grade','Create','web',NULL,NULL),(1162,'grade-edit','Grade','Edit','web',NULL,NULL),(1163,'grade-delete','Grade','Delete','web',NULL,NULL),(1164,'exam-type-view','Exam Type','View','web',NULL,NULL),(1165,'exam-type-create','Exam Type','Create','web',NULL,NULL),(1166,'exam-type-edit','Exam Type','Edit','web',NULL,NULL),(1167,'exam-type-delete','Exam Type','Delete','web',NULL,NULL),(1168,'admit-card-view','Admit Card','View','web',NULL,NULL),(1169,'admit-card-print','Admit Card','Print','web',NULL,NULL),(1170,'admit-card-download','Admit Card','Download','web',NULL,NULL),(1171,'admit-setting-view','Admit Card','Setting','web',NULL,NULL),(1172,'result-contribution-view','Contribution','Setting','web',NULL,NULL),(1173,'assignment-view','Assignment','View','web',NULL,NULL),(1174,'assignment-create','Assignment','Create','web',NULL,NULL),(1175,'assignment-edit','Assignment','Edit','web',NULL,NULL),(1176,'assignment-delete','Assignment','Delete','web',NULL,NULL),(1177,'assignment-marking','Assignment','Mark Ledger','web',NULL,NULL),(1178,'content-view','Content','View','web',NULL,NULL),(1179,'content-create','Content','Create','web',NULL,NULL),(1180,'content-edit','Content','Edit','web',NULL,NULL),(1181,'content-delete','Content','Delete','web',NULL,NULL),(1182,'content-type-view','Content Type','View','web',NULL,NULL),(1183,'content-type-create','Content Type','Create','web',NULL,NULL),(1184,'content-type-edit','Content Type','Edit','web',NULL,NULL),(1185,'content-type-delete','Content Type','Delete','web',NULL,NULL),(1186,'fees-student-due','Student Fees','Fees Due','web',NULL,NULL),(1187,'fees-student-quick-assign','Student Fees','Quick Assign','web',NULL,NULL),(1188,'fees-student-quick-received','Student Fees','Quick Received','web',NULL,NULL),(1189,'fees-student-report','Student Fees','Report','web',NULL,NULL),(1190,'fees-student-action','Student Fees','Action','web',NULL,NULL),(1191,'fees-student-print','Student Fees','Print','web',NULL,NULL),(1192,'fees-receipt-view','Fees Receipt','Setting','web',NULL,NULL),(1193,'fees-master-view','Fees Master','View','web',NULL,NULL),(1194,'fees-master-create','Fees Master','Manage','web',NULL,NULL),(1195,'fees-category-view','Fees Type','View','web',NULL,NULL),(1196,'fees-category-create','Fees Type','Create','web',NULL,NULL),(1197,'fees-category-edit','Fees Type','Edit','web',NULL,NULL),(1198,'fees-category-delete','Fees Type','Delete','web',NULL,NULL),(1199,'fees-discount-view','Fees Discount','View','web',NULL,NULL),(1200,'fees-discount-create','Fees Discount','Create','web',NULL,NULL),(1201,'fees-discount-edit','Fees Discount','Edit','web',NULL,NULL),(1202,'fees-discount-delete','Fees Discount','Delete','web',NULL,NULL),(1203,'fees-fine-view','Fees Fine','View','web',NULL,NULL),(1204,'fees-fine-create','Fees Fine','Create','web',NULL,NULL),(1205,'fees-fine-edit','Fees Fine','Edit','web',NULL,NULL),(1206,'fees-fine-delete','Fees Fine','Delete','web',NULL,NULL),(1207,'user-view','Staff','View','web',NULL,NULL),(1208,'user-create','Staff','Create','web',NULL,NULL),(1209,'user-edit','Staff','Edit','web',NULL,NULL),(1210,'user-delete','Staff','Delete','web',NULL,NULL),(1211,'user-import','Staff','Import','web',NULL,NULL),(1212,'user-password-change','Staff','Password Change','web',NULL,NULL),(1213,'staff-daily-attendance-action','Staff Daily Attendance','Manage','web',NULL,NULL),(1214,'staff-daily-attendance-report','Staff Daily Attendance','Report','web',NULL,NULL),(1215,'staff-hourly-attendance-action','Staff Hourly Attendance','Manage','web',NULL,NULL),(1216,'staff-hourly-attendance-report','Staff Hourly Attendance','Report','web',NULL,NULL),(1217,'staff-note-view','Staff Note','View','web',NULL,NULL),(1218,'staff-note-create','Staff Note','Create','web',NULL,NULL),(1219,'staff-note-edit','Staff Note','Edit','web',NULL,NULL),(1220,'staff-note-delete','Staff Note','Delete','web',NULL,NULL),(1221,'payroll-view','Payroll','View','web',NULL,NULL),(1222,'payroll-action','Payroll','Action','web',NULL,NULL),(1223,'payroll-report','Payroll','Report','web',NULL,NULL),(1224,'payroll-print','Payroll','Print','web',NULL,NULL),(1225,'pay-slip-setting-view','Pay Slip','Setting','web',NULL,NULL),(1226,'staff-leave-manage-view','Staff Leave Manage','View','web',NULL,NULL),(1227,'staff-leave-manage-edit','Staff Leave Manage','Action','web',NULL,NULL),(1228,'staff-leave-manage-delete','Staff Leave Manage','Delete','web',NULL,NULL),(1229,'staff-leave-view','Staff Apply Leave','View','web',NULL,NULL),(1230,'staff-leave-create','Staff Apply Leave','Create','web',NULL,NULL),(1231,'staff-leave-delete','Staff Apply Leave','Delete','web',NULL,NULL),(1232,'leave-type-view','Leave Type','View','web',NULL,NULL),(1233,'leave-type-create','Leave Type','Create','web',NULL,NULL),(1234,'leave-type-edit','Leave Type','Edit','web',NULL,NULL),(1235,'leave-type-delete','Leave Type','Delete','web',NULL,NULL),(1236,'work-shift-type-view','Work Shift Type','View','web',NULL,NULL),(1237,'work-shift-type-create','Work Shift Type','Create','web',NULL,NULL),(1238,'work-shift-type-edit','Work Shift Type','Edit','web',NULL,NULL),(1239,'work-shift-type-delete','Work Shift Type','Delete','web',NULL,NULL),(1240,'tax-setting-view','Tax Setting','View','web',NULL,NULL),(1241,'tax-setting-create','Tax Setting','Create','web',NULL,NULL),(1242,'tax-setting-edit','Tax Setting','Edit','web',NULL,NULL),(1243,'tax-setting-delete','Tax Setting','Delete','web',NULL,NULL),(1244,'designation-view','Designation','View','web',NULL,NULL),(1245,'designation-create','Designation','Create','web',NULL,NULL),(1246,'designation-edit','Designation','Edit','web',NULL,NULL),(1247,'designation-delete','Designation','Delete','web',NULL,NULL),(1248,'department-view','Department','View','web',NULL,NULL),(1249,'department-create','Department','Create','web',NULL,NULL),(1250,'department-edit','Department','Edit','web',NULL,NULL),(1251,'department-delete','Department','Delete','web',NULL,NULL),(1252,'income-view','Income','View','web',NULL,NULL),(1253,'income-create','Income','Create','web',NULL,NULL),(1254,'income-edit','Income','Edit','web',NULL,NULL),(1255,'income-delete','Income','Delete','web',NULL,NULL),(1256,'income-category-view','Income Category','View','web',NULL,NULL),(1257,'income-category-create','Income Category','Create','web',NULL,NULL),(1258,'income-category-edit','Income Category','Edit','web',NULL,NULL),(1259,'income-category-delete','Income Category','Delete','web',NULL,NULL),(1260,'expense-view','Expense','View','web',NULL,NULL),(1261,'expense-create','Expense','Create','web',NULL,NULL),(1262,'expense-edit','Expense','Edit','web',NULL,NULL),(1263,'expense-delete','Expense','Delete','web',NULL,NULL),(1264,'expense-category-view','Expense Category','View','web',NULL,NULL),(1265,'expense-category-create','Expense Category','Create','web',NULL,NULL),(1266,'expense-category-edit','Expense Category','Edit','web',NULL,NULL),(1267,'expense-category-delete','Expense Category','Delete','web',NULL,NULL),(1268,'outcome-view','Outcome Overview','View','web',NULL,NULL),(1269,'email-notify-view','Send Email','View','web',NULL,NULL),(1270,'email-notify-create','Send Email','Send','web',NULL,NULL),(1271,'email-notify-delete','Send Email','Delete','web',NULL,NULL),(1272,'sms-notify-view','Send SMS','View','web',NULL,NULL),(1273,'sms-notify-create','Send SMS','Send','web',NULL,NULL),(1274,'sms-notify-delete','Send SMS','Delete','web',NULL,NULL),(1275,'event-view','Event','View','web',NULL,NULL),(1276,'event-create','Event','Create','web',NULL,NULL),(1277,'event-edit','Event','Edit','web',NULL,NULL),(1278,'event-delete','Event','Delete','web',NULL,NULL),(1279,'event-calendar','Academic Calendar','View','web',NULL,NULL),(1280,'notice-view','Notice','View','web',NULL,NULL),(1281,'notice-create','Notice','Create','web',NULL,NULL),(1282,'notice-edit','Notice','Edit','web',NULL,NULL),(1283,'notice-delete','Notice','Delete','web',NULL,NULL),(1284,'notice-category-view','Notice Category','View','web',NULL,NULL),(1285,'notice-category-create','Notice Category','Create','web',NULL,NULL),(1286,'notice-category-edit','Notice Category','Edit','web',NULL,NULL),(1287,'notice-category-delete','Notice Category','Delete','web',NULL,NULL),(1288,'book-issue-return-view','Book Issue Return','View','web',NULL,NULL),(1289,'book-issue-return-action','Book Issue Return','Action','web',NULL,NULL),(1290,'book-issue-return-delete','Book Issue Return','Delete','web',NULL,NULL),(1291,'book-issue-return-over','Book Issue Return','Date Over','web',NULL,NULL),(1292,'library-member-view','Library Member','View','web',NULL,NULL),(1293,'library-member-create','Library Member','Create','web',NULL,NULL),(1294,'library-member-edit','Library Member','Edit','web',NULL,NULL),(1295,'library-member-delete','Library Member','Delete','web',NULL,NULL),(1296,'library-member-card','Library Member','Card Print','web',NULL,NULL),(1297,'library-card-setting-view','Library Card','Setting','web',NULL,NULL),(1298,'book-view','Book','View','web',NULL,NULL),(1299,'book-create','Book','Create','web',NULL,NULL),(1300,'book-edit','Book','Edit','web',NULL,NULL),(1301,'book-delete','Book','Delete','web',NULL,NULL),(1302,'book-import','Book','Import','web',NULL,NULL),(1303,'book-print','Book','Token Print','web',NULL,NULL),(1304,'book-request-view','Book Request','View','web',NULL,NULL),(1305,'book-request-create','Book Request','Create','web',NULL,NULL),(1306,'book-request-edit','Book Request','Edit','web',NULL,NULL),(1307,'book-request-delete','Book Request','Delete','web',NULL,NULL),(1308,'book-category-view','Book Category','View','web',NULL,NULL),(1309,'book-category-create','Book Category','Create','web',NULL,NULL),(1310,'book-category-edit','Book Category','Edit','web',NULL,NULL),(1311,'book-category-delete','Book Category','Delete','web',NULL,NULL),(1312,'item-issue-view','Item Issue','View','web',NULL,NULL),(1313,'item-issue-action','Item Issue','Action','web',NULL,NULL),(1314,'item-issue-delete','Item Issue','Delete','web',NULL,NULL),(1315,'item-stock-view','Item Stock','View','web',NULL,NULL),(1316,'item-stock-create','Item Stock','Create','web',NULL,NULL),(1317,'item-stock-edit','Item Stock','Edit','web',NULL,NULL),(1318,'item-stock-delete','Item Stock','Delete','web',NULL,NULL),(1319,'item-view','Item List','View','web',NULL,NULL),(1320,'item-create','Item List','Create','web',NULL,NULL),(1321,'item-edit','Item List','Edit','web',NULL,NULL),(1322,'item-delete','Item List','Delete','web',NULL,NULL),(1323,'item-store-view','Item Store','View','web',NULL,NULL),(1324,'item-store-create','Item Store','Create','web',NULL,NULL),(1325,'item-store-edit','Item Store','Edit','web',NULL,NULL),(1326,'item-store-delete','Item Store','Delete','web',NULL,NULL),(1327,'item-supplier-view','Item Supplier','View','web',NULL,NULL),(1328,'item-supplier-create','Item Supplier','Create','web',NULL,NULL),(1329,'item-supplier-edit','Item Supplier','Edit','web',NULL,NULL),(1330,'item-supplier-delete','Item Supplier','Delete','web',NULL,NULL),(1331,'item-category-view','Item Category','View','web',NULL,NULL),(1332,'item-category-create','Item Category','Create','web',NULL,NULL),(1333,'item-category-edit','Item Category','Edit','web',NULL,NULL),(1334,'item-category-delete','Item Category','Delete','web',NULL,NULL),(1335,'hostel-member-view','Hostel Member','View','web',NULL,NULL),(1336,'hostel-member-create','Hostel Member','Manage','web',NULL,NULL),(1337,'hostel-room-view','Hostel Room','View','web',NULL,NULL),(1338,'hostel-room-create','Hostel Room','Create','web',NULL,NULL),(1339,'hostel-room-edit','Hostel Room','Edit','web',NULL,NULL),(1340,'hostel-room-delete','Hostel Room','Delete','web',NULL,NULL),(1341,'hostel-view','Hostel','View','web',NULL,NULL),(1342,'hostel-create','Hostel','Create','web',NULL,NULL),(1343,'hostel-edit','Hostel','Edit','web',NULL,NULL),(1344,'hostel-delete','Hostel','Delete','web',NULL,NULL),(1345,'room-type-view','Room Type','View','web',NULL,NULL),(1346,'room-type-create','Room Type','Create','web',NULL,NULL),(1347,'room-type-edit','Room Type','Edit','web',NULL,NULL),(1348,'room-type-delete','Room Type','Delete','web',NULL,NULL),(1349,'transport-member-view','Transport Member','View','web',NULL,NULL),(1350,'transport-member-create','Transport Member','Manage','web',NULL,NULL),(1351,'transport-vehicle-view','Transport Vehicle','View','web',NULL,NULL),(1352,'transport-vehicle-create','Transport Vehicle','Create','web',NULL,NULL),(1353,'transport-vehicle-edit','Transport Vehicle','Edit','web',NULL,NULL),(1354,'transport-vehicle-delete','Transport Vehicle','Delete','web',NULL,NULL),(1355,'transport-route-view','Transport Route','View','web',NULL,NULL),(1356,'transport-route-create','Transport Route','Create','web',NULL,NULL),(1357,'transport-route-edit','Transport Route','Edit','web',NULL,NULL),(1358,'transport-route-delete','Transport Route','Delete','web',NULL,NULL),(1359,'visitor-view','Visitor','View','web',NULL,NULL),(1360,'visitor-create','Visitor','Create','web',NULL,NULL),(1361,'visitor-edit','Visitor','Edit','web',NULL,NULL),(1362,'visitor-delete','Visitor','Delete','web',NULL,NULL),(1363,'visitor-print','Visitor','Token Print','web',NULL,NULL),(1364,'visit-purpose-view','Visit Purpose','View','web',NULL,NULL),(1365,'visit-purpose-create','Visit Purpose','Create','web',NULL,NULL),(1366,'visit-purpose-edit','Visit Purpose','Edit','web',NULL,NULL),(1367,'visit-purpose-delete','Visit Purpose','Delete','web',NULL,NULL),(1368,'visitor-token-setting-view','Visitor Token','Setting','web',NULL,NULL),(1369,'phone-log-view','Phone Log','View','web',NULL,NULL),(1370,'phone-log-create','Phone Log','Create','web',NULL,NULL),(1371,'phone-log-edit','Phone Log','Edit','web',NULL,NULL),(1372,'phone-log-delete','Phone Log','Delete','web',NULL,NULL),(1373,'enquiry-view','Enquiry','View','web',NULL,NULL),(1374,'enquiry-create','Enquiry','Create','web',NULL,NULL),(1375,'enquiry-edit','Enquiry','Edit','web',NULL,NULL),(1376,'enquiry-delete','Enquiry','Delete','web',NULL,NULL),(1377,'enquiry-reference-view','Enquiry Reference','View','web',NULL,NULL),(1378,'enquiry-reference-create','Enquiry Reference','Create','web',NULL,NULL),(1379,'enquiry-reference-edit','Enquiry Reference','Edit','web',NULL,NULL),(1380,'enquiry-reference-delete','Enquiry Reference','Delete','web',NULL,NULL),(1381,'enquiry-source-view','Enquiry Source','View','web',NULL,NULL),(1382,'enquiry-source-create','Enquiry Source','Create','web',NULL,NULL),(1383,'enquiry-source-edit','Enquiry Source','Edit','web',NULL,NULL),(1384,'enquiry-source-delete','Enquiry Source','Delete','web',NULL,NULL),(1385,'complain-view','Complain','View','web',NULL,NULL),(1386,'complain-create','Complain','Create','web',NULL,NULL),(1387,'complain-edit','Complain','Edit','web',NULL,NULL),(1388,'complain-delete','Complain','Delete','web',NULL,NULL),(1389,'complain-type-view','Complain Type','View','web',NULL,NULL),(1390,'complain-type-create','Complain Type','Create','web',NULL,NULL),(1391,'complain-type-edit','Complain Type','Edit','web',NULL,NULL),(1392,'complain-type-delete','Complain Type','Delete','web',NULL,NULL),(1393,'complain-source-view','Complain Source','View','web',NULL,NULL),(1394,'complain-source-create','Complain Source','Create','web',NULL,NULL),(1395,'complain-source-edit','Complain Source','Edit','web',NULL,NULL),(1396,'complain-source-delete','Complain Source','Delete','web',NULL,NULL),(1397,'postal-exchange-view','Postal Exchange','View','web',NULL,NULL),(1398,'postal-exchange-create','Postal Exchange','Create','web',NULL,NULL),(1399,'postal-exchange-edit','Postal Exchange','Edit','web',NULL,NULL),(1400,'postal-exchange-delete','Postal Exchange','Delete','web',NULL,NULL),(1401,'postal-type-view','Postal Type','View','web',NULL,NULL),(1402,'postal-type-create','Postal Type','Create','web',NULL,NULL),(1403,'postal-type-edit','Postal Type','Edit','web',NULL,NULL),(1404,'postal-type-delete','Postal Type','Delete','web',NULL,NULL),(1405,'meeting-view','Meeting Schedule','View','web',NULL,NULL),(1406,'meeting-create','Meeting Schedule','Create','web',NULL,NULL),(1407,'meeting-edit','Meeting Schedule','Edit','web',NULL,NULL),(1408,'meeting-delete','Meeting Schedule','Delete','web',NULL,NULL),(1409,'meeting-type-view','Meeting Type','View','web',NULL,NULL),(1410,'meeting-type-create','Meeting Type','Create','web',NULL,NULL),(1411,'meeting-type-edit','Meeting Type','Edit','web',NULL,NULL),(1412,'meeting-type-delete','Meeting Type','Delete','web',NULL,NULL),(1413,'marksheet-view','Marksheet','View','web',NULL,NULL),(1414,'marksheet-print','Marksheet','Print','web',NULL,NULL),(1415,'marksheet-download','Marksheet','Download','web',NULL,NULL),(1416,'marksheet-setting-view','Marksheet','Setting','web',NULL,NULL),(1417,'certificate-view','Certificate','View','web',NULL,NULL),(1418,'certificate-create','Certificate','Genarate','web',NULL,NULL),(1419,'certificate-edit','Certificate','Edit','web',NULL,NULL),(1420,'certificate-print','Certificate','Print','web',NULL,NULL),(1421,'certificate-download','Certificate','Download','web',NULL,NULL),(1422,'certificate-template-view','Certificate Template','View','web',NULL,NULL),(1423,'certificate-template-create','Certificate Template','Create','web',NULL,NULL),(1424,'certificate-template-edit','Certificate Template','Edit','web',NULL,NULL),(1425,'certificate-template-delete','Certificate Template','Delete','web',NULL,NULL),(1426,'report-student','Reports','Student Progress','web',NULL,NULL),(1427,'report-subject','Reports','Course Students','web',NULL,NULL),(1428,'report-fees','Reports','Collected Fees','web',NULL,NULL),(1429,'report-payroll','Reports','Salary Paid','web',NULL,NULL),(1430,'report-leave','Reports','Staff Leaves','web',NULL,NULL),(1431,'report-income','Reports','Total Income','web',NULL,NULL),(1432,'report-expense','Reports','Total Expense','web',NULL,NULL),(1433,'report-library','Reports','Library History','web',NULL,NULL),(1434,'report-hostel','Reports','Hostel Members','web',NULL,NULL),(1435,'report-transport','Reports','Transport Members','web',NULL,NULL),(1436,'topbar-setting-view','Contact Setting','Manage','web',NULL,NULL),(1437,'social-setting-view','Social Setting','Manage','web',NULL,NULL),(1438,'slider-view','Slider','View','web',NULL,NULL),(1439,'slider-create','Slider','Create','web',NULL,NULL),(1440,'slider-edit','Slider','Edit','web',NULL,NULL),(1441,'slider-delete','Slider','Delete','web',NULL,NULL),(1442,'about-us-view','About Us','Manage','web',NULL,NULL),(1443,'feature-view','Feature','View','web',NULL,NULL),(1444,'feature-create','Feature','Create','web',NULL,NULL),(1445,'feature-edit','Feature','Edit','web',NULL,NULL),(1446,'feature-delete','Feature','Delete','web',NULL,NULL),(1447,'course-view','Course','View','web',NULL,NULL),(1448,'course-create','Course','Create','web',NULL,NULL),(1449,'course-edit','Course','Edit','web',NULL,NULL),(1450,'course-delete','Course','Delete','web',NULL,NULL),(1451,'web-event-view','Web Event','View','web',NULL,NULL),(1452,'web-event-create','Web Event','Create','web',NULL,NULL),(1453,'web-event-edit','Web Event','Edit','web',NULL,NULL),(1454,'web-event-delete','Web Event','Delete','web',NULL,NULL),(1455,'news-view','News','View','web',NULL,NULL),(1456,'news-create','News','Create','web',NULL,NULL),(1457,'news-edit','News','Edit','web',NULL,NULL),(1458,'news-delete','News','Delete','web',NULL,NULL),(1459,'gallery-view','Gallery','View','web',NULL,NULL),(1460,'gallery-create','Gallery','Create','web',NULL,NULL),(1461,'gallery-edit','Gallery','Edit','web',NULL,NULL),(1462,'gallery-delete','Gallery','Delete','web',NULL,NULL),(1463,'faq-view','Faq','View','web',NULL,NULL),(1464,'faq-create','Faq','Create','web',NULL,NULL),(1465,'faq-edit','Faq','Edit','web',NULL,NULL),(1466,'faq-delete','Faq','Delete','web',NULL,NULL),(1467,'testimonial-view','Testimonial','View','web',NULL,NULL),(1468,'testimonial-create','Testimonial','Create','web',NULL,NULL),(1469,'testimonial-edit','Testimonial','Edit','web',NULL,NULL),(1470,'testimonial-delete','Testimonial','Delete','web',NULL,NULL),(1471,'page-view','Footer Page','View','web',NULL,NULL),(1472,'page-create','Footer Page','Create','web',NULL,NULL),(1473,'page-edit','Footer Page','Edit','web',NULL,NULL),(1474,'page-delete','Footer Page','Delete','web',NULL,NULL),(1475,'call-to-action-view','Call To Action','Manage','web',NULL,NULL),(1476,'province-view','State','View','web',NULL,NULL),(1477,'province-create','State','Create','web',NULL,NULL),(1478,'province-edit','State','Edit','web',NULL,NULL),(1479,'province-delete','State','Delete','web',NULL,NULL),(1480,'district-view','District/City','View','web',NULL,NULL),(1481,'district-create','District/City','Create','web',NULL,NULL),(1482,'district-edit','District/City','Edit','web',NULL,NULL),(1483,'district-delete','District/City','Delete','web',NULL,NULL),(1484,'language-view','Language','View','web',NULL,NULL),(1485,'language-create','Language','Create','web',NULL,NULL),(1486,'language-edit','Language','Edit','web',NULL,NULL),(1487,'language-delete','Language','Delete','web',NULL,NULL),(1488,'translations-view','Translation','View','web',NULL,NULL),(1489,'translations-create','Translation','Create','web',NULL,NULL),(1490,'translations-delete','Translation','Delete','web',NULL,NULL),(1491,'setting-view','General Setting','Manage','web',NULL,NULL),(1492,'mail-setting-view','Mail Setting','Manage','web',NULL,NULL),(1493,'sms-setting-view','SMS Setting','Manage','web',NULL,NULL),(1494,'application-setting-view','Application Setting','Manage','web',NULL,NULL),(1495,'role-view','Role and Permissions','View','web',NULL,NULL),(1496,'role-create','Role and Permissions','Create','web',NULL,NULL),(1497,'role-edit','Role and Permissions','Edit','web',NULL,NULL),(1498,'role-delete','Role and Permissions','Delete','web',NULL,NULL),(1499,'field-staff','Field Setting','Staff','web',NULL,NULL),(1500,'field-student','Field Setting','Student','web',NULL,NULL),(1501,'field-application','Field Setting','Application','web',NULL,NULL),(1502,'student-panel-view','Student Panel','Manage','web',NULL,NULL),(1503,'profile-view','My Profile','View','web',NULL,NULL),(1504,'profile-edit','My Profile','Edit','web',NULL,NULL),(1505,'profile-account','My Profile','Account','web',NULL,NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone_logs`
--

DROP TABLE IF EXISTS `phone_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phone_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `follow_up_date` date DEFAULT NULL,
  `call_duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `purpose` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `call_type` int(11) NOT NULL COMMENT '1 Income & 2 Outgoing',
  `status` int(11) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_logs`
--

LOCK TABLES `phone_logs` WRITE;
/*!40000 ALTER TABLE `phone_logs` DISABLE KEYS */;
INSERT INTO `phone_logs` VALUES (1,'Quon Sellers','+1 (948) 556-2442','2022-10-01','2022-11-25','2 min',NULL,NULL,'Ratione excepturi qu','Minus maxime Nam mag',1,1,1,NULL,'2022-10-01 12:17:13','2022-10-01 12:17:13'),(2,'Tanya Grimes','+1 (988) 107-4828','2022-10-01','2022-11-13','3:50',NULL,NULL,'Tempore sint est ne','Lorem omnis nostrum',1,1,1,NULL,'2022-10-01 12:18:04','2022-10-01 12:18:04'),(3,'Karyn Castillo','+1 (923) 454-6055','2021-12-18','2022-10-09','5 min',NULL,NULL,'Et eos corrupti qui','Est eius doloremque',1,1,1,NULL,'2022-10-01 12:18:59','2022-10-01 12:18:59'),(4,'Quentin Alford','+1 (628) 618-3668','2022-07-20','2022-11-18','8:50',NULL,NULL,'Velit omnis quas dis','Laboriosam et quide',2,1,1,NULL,'2022-10-01 12:19:34','2022-10-01 12:19:34'),(5,'Sasha Harper','+1 (612) 725-1207','2021-03-12','2022-10-05','6 min',NULL,NULL,'Sint quas ullamco v','Architecto numquam q',2,1,1,NULL,'2022-10-01 12:20:45','2022-10-01 12:20:45'),(6,'Cleo Simpson','+1 (305) 133-4681','2022-05-28',NULL,NULL,NULL,NULL,'Quos non maiores eos','Et obcaecati aut aut',1,1,1,NULL,'2022-10-01 12:23:14','2022-10-01 12:23:14'),(7,'Meredith Baxter','+1 (502) 865-8511','2023-08-25','2024-11-11','Exercitationem tenet','13:27:00',NULL,'Incididunt reiciendi','Ut inventore error m',2,1,1,NULL,'2023-08-25 07:27:35','2023-08-25 07:27:35');
/*!40000 ALTER TABLE `phone_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postal_exchange_types`
--

DROP TABLE IF EXISTS `postal_exchange_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postal_exchange_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postal_exchange_types_title_unique` (`title`),
  UNIQUE KEY `postal_exchange_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postal_exchange_types`
--

LOCK TABLES `postal_exchange_types` WRITE;
/*!40000 ALTER TABLE `postal_exchange_types` DISABLE KEYS */;
INSERT INTO `postal_exchange_types` VALUES (1,'Examination Papers','examination-papers',NULL,1,'2022-10-01 03:58:48','2022-10-01 03:58:48'),(2,'Library Books','library-books',NULL,1,'2022-10-01 03:58:57','2022-10-01 03:58:57'),(3,'Lab Instruments','lab-instruments',NULL,1,'2022-10-01 04:01:27','2022-10-01 04:01:27'),(4,'Office Documents','office-documents',NULL,1,'2022-10-01 04:02:19','2022-10-01 04:02:19'),(5,'Sports Equipment','sports-equipment',NULL,1,'2022-10-01 04:03:56','2022-10-01 04:03:56');
/*!40000 ALTER TABLE `postal_exchange_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postal_exchanges`
--

DROP TABLE IF EXISTS `postal_exchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postal_exchanges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL COMMENT '1 Import & 2 Export',
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `from` text COLLATE utf8mb4_unicode_ci,
  `to` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `date` date DEFAULT NULL,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `postal_exchanges_category_id_foreign` (`category_id`),
  CONSTRAINT `postal_exchanges_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `postal_exchange_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postal_exchanges`
--

LOCK TABLES `postal_exchanges` WRITE;
/*!40000 ALTER TABLE `postal_exchanges` DISABLE KEYS */;
INSERT INTO `postal_exchanges` VALUES (1,1,4,'Sed reprehenderit e','Academic Building','Officiis et laboris','Numquam placeat rat','Ut dignissimos illum','2019-08-03','background-border_1664649226.png',1,1,1,'2022-10-01 12:33:46','2022-10-27 13:32:56'),(2,1,3,'Proident provident','Govt','Commodo qui aut quis','Hic aperiam hic aper','Sit velit nisi asp','2020-01-19','book-covers_1664656202.jpg',1,1,1,'2022-10-01 12:34:05','2022-10-27 13:32:01'),(3,2,2,'Velit sunt modi nihi','Sundarbon','Voluptate est dolori','Et dolor assumenda n','Enim in vel ad liber','2021-01-11',NULL,1,1,1,'2022-10-01 12:34:17','2022-10-27 13:31:10'),(4,2,3,'Quod velit aliqua E','Saif Transport','Aute sint exercitati','Vitae ipsa ipsa co','Enim consectetur pr','2022-06-28',NULL,1,1,1,'2022-10-01 12:35:37','2022-10-27 13:30:58'),(5,1,2,'Sed ut aut accusamus','Habib Vai','Architecto et ex qui','Qui eos dolorum ut','Voluptates quo tempo','2022-03-31','book-cover2_1664656189.jpg',1,1,1,'2022-10-01 12:35:51','2022-10-27 13:30:40'),(6,1,5,'Accusamus mollit fug','Non vel modi volupta','In dolor nulla ut au','Labore officiis nost','Omnis enim qui obcae','2023-08-22',NULL,2,1,1,'2023-08-25 07:35:24','2023-08-25 07:36:22'),(7,2,1,'Veniam incididunt a','Hic ullam mollit bea','Provident dolores a','Excepturi excepteur','Labore alias non cor','2023-06-28',NULL,1,1,NULL,'2023-08-25 07:36:18','2023-08-25 07:36:18'),(8,1,2,'Enim eaque consequun','Eu ad ipsum quod ve','Est cillum nostrum','Placeat placeat pa','Tempora accusamus mo','2023-07-31',NULL,4,1,NULL,'2023-08-25 07:37:18','2023-08-25 07:37:18');
/*!40000 ALTER TABLE `postal_exchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_settings`
--

DROP TABLE IF EXISTS `print_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `print_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `header_left` text COLLATE utf8mb4_unicode_ci,
  `header_center` text COLLATE utf8mb4_unicode_ci,
  `header_right` text COLLATE utf8mb4_unicode_ci,
  `body` text COLLATE utf8mb4_unicode_ci,
  `footer_left` text COLLATE utf8mb4_unicode_ci,
  `footer_center` text COLLATE utf8mb4_unicode_ci,
  `footer_right` text COLLATE utf8mb4_unicode_ci,
  `logo_left` text COLLATE utf8mb4_unicode_ci,
  `logo_right` text COLLATE utf8mb4_unicode_ci,
  `background` text COLLATE utf8mb4_unicode_ci,
  `width` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `height` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `student_photo` tinyint(1) NOT NULL DEFAULT '0',
  `barcode` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `print_settings_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_settings`
--

LOCK TABLES `print_settings` WRITE;
/*!40000 ALTER TABLE `print_settings` DISABLE KEYS */;
INSERT INTO `print_settings` VALUES (1,'class-routine','Our University Class Routine',NULL,NULL,NULL,'<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable.</p>',NULL,NULL,NULL,'campus_365_(1)_1716408515.png','campus_365_(1)_1716408516.png',NULL,'1000px','auto',0,0,1,'2022-09-30 13:44:31','2024-05-22 14:08:36'),(2,'exam-routine','Our University Exam Routine',NULL,NULL,NULL,'<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable.</p>',NULL,NULL,NULL,'campus_365_(1)_1716408537.png','campus_365_(1)_1716408537.png',NULL,'800px','auto',0,0,1,'2022-09-30 13:45:22','2024-05-22 14:08:57'),(3,'admit-card','Final Exam Admit Card',NULL,NULL,NULL,NULL,'Exam Controller',NULL,'Issued By','logo_1664567252.jpg',NULL,NULL,'600px','auto',1,0,1,'2022-09-30 13:47:32','2022-10-01 04:36:39'),(4,'fees-receipt','Our University Fees Receipt',NULL,NULL,NULL,NULL,'Student Signature',NULL,'Receiver Signature','logo_1664567807.jpg','logo_1664567807.jpg',NULL,'800px','auto',0,0,1,'2022-09-30 13:56:47','2022-10-01 04:26:02'),(5,'pay-slip','Our University Salary Pay Slip',NULL,NULL,NULL,NULL,'Accountant',NULL,'Receiver',NULL,'logo_1664568033.jpg',NULL,'800px','auto',0,0,1,'2022-09-30 14:00:33','2022-10-01 04:14:05'),(6,'visitor-token','Visitor Token',NULL,NULL,NULL,NULL,'Authority',NULL,'Issues By',NULL,'logo_1664617034.jpg',NULL,'600px','auto',0,1,1,'2022-10-01 03:37:14','2022-10-01 12:04:49');
/*!40000 ALTER TABLE `print_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_class_room`
--

DROP TABLE IF EXISTS `program_class_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_class_room` (
  `program_id` int(10) unsigned NOT NULL,
  `class_room_id` int(10) unsigned NOT NULL,
  KEY `program_class_room_program_id_foreign` (`program_id`),
  KEY `program_class_room_class_room_id_foreign` (`class_room_id`),
  CONSTRAINT `program_class_room_class_room_id_foreign` FOREIGN KEY (`class_room_id`) REFERENCES `class_rooms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `program_class_room_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_class_room`
--

LOCK TABLES `program_class_room` WRITE;
/*!40000 ALTER TABLE `program_class_room` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_class_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_semester`
--

DROP TABLE IF EXISTS `program_semester`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_semester` (
  `program_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  KEY `program_semester_program_id_foreign` (`program_id`),
  KEY `program_semester_semester_id_foreign` (`semester_id`),
  CONSTRAINT `program_semester_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `program_semester_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_semester`
--

LOCK TABLES `program_semester` WRITE;
/*!40000 ALTER TABLE `program_semester` DISABLE KEYS */;
INSERT INTO `program_semester` VALUES (1,1),(2,1),(1,2),(2,2),(1,3),(2,3),(1,4),(2,4),(1,5),(1,6),(1,7),(1,8),(3,9),(3,10),(3,11),(3,12);
/*!40000 ALTER TABLE `program_semester` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_semester_sections`
--

DROP TABLE IF EXISTS `program_semester_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_semester_sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `program_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `program_semester_sections_program_id_foreign` (`program_id`),
  KEY `program_semester_sections_semester_id_foreign` (`semester_id`),
  KEY `program_semester_sections_section_id_foreign` (`section_id`),
  CONSTRAINT `program_semester_sections_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `program_semester_sections_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `program_semester_sections_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_semester_sections`
--

LOCK TABLES `program_semester_sections` WRITE;
/*!40000 ALTER TABLE `program_semester_sections` DISABLE KEYS */;
INSERT INTO `program_semester_sections` VALUES (1,1,1,1,NULL,NULL),(2,1,1,2,NULL,NULL),(3,1,2,1,NULL,NULL),(4,1,2,2,NULL,NULL),(5,1,3,1,NULL,NULL),(6,1,3,2,NULL,NULL),(7,1,4,1,NULL,NULL),(8,1,4,2,NULL,NULL),(9,1,5,1,NULL,NULL),(10,1,5,2,NULL,NULL),(11,1,6,1,NULL,NULL),(12,1,6,2,NULL,NULL),(13,1,7,1,NULL,NULL),(14,1,7,2,NULL,NULL),(15,1,8,1,NULL,NULL),(16,1,8,2,NULL,NULL),(17,2,1,1,NULL,NULL),(18,2,1,2,NULL,NULL),(19,2,2,1,NULL,NULL),(20,2,2,2,NULL,NULL),(21,2,3,1,NULL,NULL),(22,2,3,2,NULL,NULL),(23,2,4,1,NULL,NULL),(24,2,4,2,NULL,NULL),(25,3,9,1,NULL,NULL),(26,3,9,2,NULL,NULL),(27,3,9,3,NULL,NULL),(28,3,10,1,NULL,NULL),(29,3,10,2,NULL,NULL),(30,3,10,3,NULL,NULL),(31,3,11,1,NULL,NULL),(32,3,11,2,NULL,NULL),(33,3,11,3,NULL,NULL),(34,3,12,1,NULL,NULL),(35,3,12,2,NULL,NULL),(36,3,12,3,NULL,NULL);
/*!40000 ALTER TABLE `program_semester_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_session`
--

DROP TABLE IF EXISTS `program_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_session` (
  `program_id` int(10) unsigned NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  KEY `program_session_program_id_foreign` (`program_id`),
  KEY `program_session_session_id_foreign` (`session_id`),
  CONSTRAINT `program_session_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `program_session_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_session`
--

LOCK TABLES `program_session` WRITE;
/*!40000 ALTER TABLE `program_session` DISABLE KEYS */;
INSERT INTO `program_session` VALUES (1,1),(1,2),(2,1),(2,2),(3,4),(3,3);
/*!40000 ALTER TABLE `program_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_subject`
--

DROP TABLE IF EXISTS `program_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_subject` (
  `program_id` int(10) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  KEY `program_subject_program_id_foreign` (`program_id`),
  KEY `program_subject_subject_id_foreign` (`subject_id`),
  CONSTRAINT `program_subject_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `program_subject_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_subject`
--

LOCK TABLES `program_subject` WRITE;
/*!40000 ALTER TABLE `program_subject` DISABLE KEYS */;
INSERT INTO `program_subject` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(1,22),(1,23),(1,24),(1,25),(1,26),(1,27),(1,28),(1,29),(1,30),(1,31),(1,32),(1,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,39),(1,40),(1,41),(1,42),(1,43),(1,44),(1,45),(1,46),(1,47),(1,48),(1,49),(1,50),(1,51),(1,52),(1,53),(1,54),(1,55),(1,56),(1,57),(1,58),(1,59),(1,60),(1,61),(1,62),(1,63),(1,64),(1,65),(1,66),(1,67),(1,68),(1,69),(1,70),(1,71),(1,72),(1,73),(1,74),(1,75),(1,76),(1,77),(1,78),(1,79),(1,80),(1,81),(1,82),(1,83),(1,84),(1,85),(1,86),(2,87),(2,88),(2,89),(2,90),(2,91),(2,92),(2,93),(2,94),(2,95),(2,96),(2,97),(2,98),(2,99),(3,100),(3,101),(3,102),(3,103),(3,104),(3,105),(3,106),(3,107),(3,108),(3,109),(3,110),(3,111),(3,112),(3,113),(3,114),(3,115),(3,116),(3,117),(3,118),(3,119);
/*!40000 ALTER TABLE `program_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shortcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `programs_title_unique` (`title`),
  UNIQUE KEY `programs_slug_unique` (`slug`),
  KEY `programs_faculty_id_foreign` (`faculty_id`),
  CONSTRAINT `programs_faculty_id_foreign` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (1,1,'Bachelor of Business Administration','bachelor-of-business-administration','BBA',0,1,'2025-04-03 03:07:46','2025-04-03 03:07:46'),(2,1,'Masters of Business Administration','masters-of-business-administration','MBA',0,1,'2025-04-03 03:08:36','2025-04-03 03:08:36'),(3,1,'Weekend Masters of Business Administration','weekend-masters-of-business-administration','WMBA',0,1,'2025-04-03 03:09:02','2025-04-03 03:09:02');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provinces`
--

DROP TABLE IF EXISTS `provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provinces` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provinces_title_unique` (`title`),
  UNIQUE KEY `provinces_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provinces`
--

LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;
INSERT INTO `provinces` VALUES (1,'Dhaka','dhaka',NULL,1,'2022-09-30 14:16:55','2022-09-30 14:16:55'),(2,'Sylhet','sylhet',NULL,1,'2022-09-30 14:17:02','2022-09-30 14:17:02'),(3,'Khulna','khulna',NULL,1,'2022-09-30 14:17:07','2022-09-30 14:17:07'),(4,'Rangpur','rangpur',NULL,1,'2022-09-30 14:17:12','2022-09-30 14:17:12');
/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result_contributions`
--

DROP TABLE IF EXISTS `result_contributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `result_contributions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attendances` decimal(5,2) NOT NULL DEFAULT '0.00',
  `assignments` decimal(5,2) NOT NULL DEFAULT '0.00',
  `activities` decimal(5,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result_contributions`
--

LOCK TABLES `result_contributions` WRITE;
/*!40000 ALTER TABLE `result_contributions` DISABLE KEYS */;
INSERT INTO `result_contributions` VALUES (1,10.00,10.00,10.00,1,NULL,'2023-02-13 11:50:36');
/*!40000 ALTER TABLE `result_contributions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1068,1),(1069,1),(1070,1),(1071,1),(1072,1),(1073,1),(1074,1),(1075,1),(1076,1),(1077,1),(1078,1),(1079,1),(1080,1),(1081,1),(1082,1),(1083,1),(1084,1),(1085,1),(1086,1),(1087,1),(1088,1),(1089,1),(1090,1),(1091,1),(1092,1),(1093,1),(1094,1),(1095,1),(1096,1),(1097,1),(1098,1),(1099,1),(1100,1),(1101,1),(1102,1),(1103,1),(1104,1),(1105,1),(1106,1),(1107,1),(1108,1),(1109,1),(1110,1),(1111,1),(1112,1),(1113,1),(1114,1),(1115,1),(1116,1),(1117,1),(1118,1),(1119,1),(1120,1),(1121,1),(1122,1),(1123,1),(1124,1),(1125,1),(1126,1),(1127,1),(1128,1),(1129,1),(1130,1),(1131,1),(1132,1),(1133,1),(1134,1),(1135,1),(1136,1),(1137,1),(1138,1),(1139,1),(1140,1),(1141,1),(1142,1),(1143,1),(1144,1),(1145,1),(1146,1),(1147,1),(1148,1),(1149,1),(1150,1),(1151,1),(1152,1),(1153,1),(1154,1),(1155,1),(1156,1),(1157,1),(1158,1),(1159,1),(1160,1),(1161,1),(1162,1),(1163,1),(1164,1),(1165,1),(1166,1),(1167,1),(1168,1),(1169,1),(1170,1),(1171,1),(1172,1),(1173,1),(1174,1),(1175,1),(1176,1),(1177,1),(1178,1),(1179,1),(1180,1),(1181,1),(1182,1),(1183,1),(1184,1),(1185,1),(1186,1),(1187,1),(1188,1),(1189,1),(1190,1),(1191,1),(1192,1),(1193,1),(1194,1),(1195,1),(1196,1),(1197,1),(1198,1),(1199,1),(1200,1),(1201,1),(1202,1),(1203,1),(1204,1),(1205,1),(1206,1),(1207,1),(1208,1),(1209,1),(1210,1),(1211,1),(1212,1),(1213,1),(1214,1),(1215,1),(1216,1),(1217,1),(1218,1),(1219,1),(1220,1),(1221,1),(1222,1),(1223,1),(1224,1),(1225,1),(1226,1),(1227,1),(1228,1),(1229,1),(1230,1),(1231,1),(1232,1),(1233,1),(1234,1),(1235,1),(1236,1),(1237,1),(1238,1),(1239,1),(1240,1),(1241,1),(1242,1),(1243,1),(1244,1),(1245,1),(1246,1),(1247,1),(1248,1),(1249,1),(1250,1),(1251,1),(1252,1),(1253,1),(1254,1),(1255,1),(1256,1),(1257,1),(1258,1),(1259,1),(1260,1),(1261,1),(1262,1),(1263,1),(1264,1),(1265,1),(1266,1),(1267,1),(1268,1),(1269,1),(1270,1),(1271,1),(1272,1),(1273,1),(1274,1),(1275,1),(1276,1),(1277,1),(1278,1),(1279,1),(1280,1),(1281,1),(1282,1),(1283,1),(1284,1),(1285,1),(1286,1),(1287,1),(1288,1),(1289,1),(1290,1),(1291,1),(1292,1),(1293,1),(1294,1),(1295,1),(1296,1),(1297,1),(1298,1),(1299,1),(1300,1),(1301,1),(1302,1),(1303,1),(1304,1),(1305,1),(1306,1),(1307,1),(1308,1),(1309,1),(1310,1),(1311,1),(1312,1),(1313,1),(1314,1),(1315,1),(1316,1),(1317,1),(1318,1),(1319,1),(1320,1),(1321,1),(1322,1),(1323,1),(1324,1),(1325,1),(1326,1),(1327,1),(1328,1),(1329,1),(1330,1),(1331,1),(1332,1),(1333,1),(1334,1),(1335,1),(1336,1),(1337,1),(1338,1),(1339,1),(1340,1),(1341,1),(1342,1),(1343,1),(1344,1),(1345,1),(1346,1),(1347,1),(1348,1),(1349,1),(1350,1),(1351,1),(1352,1),(1353,1),(1354,1),(1355,1),(1356,1),(1357,1),(1358,1),(1359,1),(1360,1),(1361,1),(1362,1),(1363,1),(1364,1),(1365,1),(1366,1),(1367,1),(1368,1),(1369,1),(1370,1),(1371,1),(1372,1),(1373,1),(1374,1),(1375,1),(1376,1),(1377,1),(1378,1),(1379,1),(1380,1),(1381,1),(1382,1),(1383,1),(1384,1),(1385,1),(1386,1),(1387,1),(1388,1),(1389,1),(1390,1),(1391,1),(1392,1),(1393,1),(1394,1),(1395,1),(1396,1),(1397,1),(1398,1),(1399,1),(1400,1),(1401,1),(1402,1),(1403,1),(1404,1),(1405,1),(1406,1),(1407,1),(1408,1),(1409,1),(1410,1),(1411,1),(1412,1),(1413,1),(1414,1),(1415,1),(1416,1),(1417,1),(1418,1),(1419,1),(1420,1),(1421,1),(1422,1),(1423,1),(1424,1),(1425,1),(1426,1),(1427,1),(1428,1),(1429,1),(1430,1),(1431,1),(1432,1),(1433,1),(1434,1),(1435,1),(1436,1),(1437,1),(1438,1),(1439,1),(1440,1),(1441,1),(1442,1),(1443,1),(1444,1),(1445,1),(1446,1),(1447,1),(1448,1),(1449,1),(1450,1),(1451,1),(1452,1),(1453,1),(1454,1),(1455,1),(1456,1),(1457,1),(1458,1),(1459,1),(1460,1),(1461,1),(1462,1),(1463,1),(1464,1),(1465,1),(1466,1),(1467,1),(1468,1),(1469,1),(1470,1),(1471,1),(1472,1),(1473,1),(1474,1),(1475,1),(1476,1),(1477,1),(1478,1),(1479,1),(1480,1),(1481,1),(1482,1),(1483,1),(1484,1),(1485,1),(1486,1),(1487,1),(1488,1),(1489,1),(1490,1),(1491,1),(1492,1),(1493,1),(1494,1),(1495,1),(1496,1),(1497,1),(1498,1),(1499,1),(1500,1),(1501,1),(1502,1),(1503,1),(1504,1),(1505,1),(1068,2),(1069,2),(1070,2),(1071,2),(1072,2),(1073,2),(1074,2),(1075,2),(1076,2),(1077,2),(1078,2),(1079,2),(1080,2),(1081,2),(1082,2),(1083,2),(1084,2),(1085,2),(1086,2),(1087,2),(1088,2),(1089,2),(1090,2),(1097,2),(1098,2),(1099,2),(1100,2),(1101,2),(1102,2),(1103,2),(1104,2),(1105,2),(1143,2),(1144,2),(1145,2),(1146,2),(1147,2),(1148,2),(1149,2),(1150,2),(1151,2),(1152,2),(1153,2),(1164,2),(1165,2),(1166,2),(1167,2),(1168,2),(1169,2),(1170,2),(1171,2),(1172,2),(1192,2),(1207,2),(1208,2),(1209,2),(1210,2),(1211,2),(1212,2),(1217,2),(1218,2),(1219,2),(1220,2),(1229,2),(1230,2),(1231,2),(1256,2),(1257,2),(1258,2),(1259,2),(1264,2),(1265,2),(1266,2),(1267,2),(1268,2),(1269,2),(1270,2),(1271,2),(1272,2),(1273,2),(1274,2),(1275,2),(1276,2),(1277,2),(1278,2),(1279,2),(1284,2),(1285,2),(1286,2),(1287,2),(1297,2),(1413,2),(1414,2),(1415,2),(1416,2),(1417,2),(1418,2),(1419,2),(1420,2),(1421,2),(1422,2),(1423,2),(1424,2),(1425,2),(1426,2),(1427,2),(1428,2),(1429,2),(1430,2),(1431,2),(1432,2),(1433,2),(1434,2),(1435,2),(1476,2),(1477,2),(1478,2),(1479,2),(1480,2),(1481,2),(1482,2),(1483,2),(1503,2),(1504,2),(1505,2),(1072,3),(1186,3),(1187,3),(1188,3),(1189,3),(1190,3),(1191,3),(1193,3),(1194,3),(1195,3),(1196,3),(1197,3),(1199,3),(1200,3),(1201,3),(1203,3),(1204,3),(1205,3),(1207,3),(1213,3),(1214,3),(1215,3),(1216,3),(1221,3),(1222,3),(1223,3),(1224,3),(1229,3),(1230,3),(1252,3),(1253,3),(1254,3),(1260,3),(1261,3),(1262,3),(1503,3),(1504,3),(1505,3),(1072,4),(1207,4),(1288,4),(1289,4),(1290,4),(1291,4),(1292,4),(1293,4),(1294,4),(1295,4),(1296,4),(1298,4),(1299,4),(1300,4),(1301,4),(1302,4),(1303,4),(1304,4),(1305,4),(1306,4),(1307,4),(1308,4),(1309,4),(1310,4),(1503,4),(1504,4),(1505,4),(1312,5),(1313,5),(1314,5),(1315,5),(1316,5),(1317,5),(1319,5),(1320,5),(1321,5),(1359,5),(1360,5),(1361,5),(1363,5),(1364,5),(1365,5),(1366,5),(1369,5),(1370,5),(1371,5),(1373,5),(1374,5),(1375,5),(1377,5),(1378,5),(1379,5),(1381,5),(1382,5),(1383,5),(1385,5),(1386,5),(1387,5),(1389,5),(1390,5),(1391,5),(1393,5),(1394,5),(1395,5),(1397,5),(1398,5),(1399,5),(1401,5),(1402,5),(1403,5),(1405,5),(1406,5),(1407,5),(1409,5),(1410,5),(1411,5),(1503,5),(1504,5),(1505,5),(1072,6),(1091,6),(1092,6),(1093,6),(1094,6),(1095,6),(1097,6),(1098,6),(1099,6),(1101,6),(1102,6),(1103,6),(1104,6),(1143,6),(1144,6),(1145,6),(1146,6),(1147,6),(1148,6),(1149,6),(1150,6),(1151,6),(1154,6),(1155,6),(1156,6),(1157,6),(1158,6),(1159,6),(1168,6),(1169,6),(1170,6),(1173,6),(1174,6),(1175,6),(1177,6),(1178,6),(1179,6),(1180,6),(1503,6),(1504,6),(1505,6);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`),
  UNIQUE KEY `roles_name_unique` (`name`),
  UNIQUE KEY `roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Admin','super-admin','web','2022-09-30 12:00:46','2022-09-30 12:00:46'),(2,'Admin','admin','web',NULL,NULL),(3,'Accountant','accountant','web',NULL,NULL),(4,'Librarian','librarian','web',NULL,NULL),(5,'Receptionist','receptionist','web',NULL,NULL),(6,'Teacher','teacher','web',NULL,NULL),(7,'Office Staff','office-staff','web',NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s_m_s_notifies`
--

DROP TABLE IF EXISTS `s_m_s_notifies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_m_s_notifies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `semester_id` int(10) unsigned DEFAULT NULL,
  `section_id` int(10) unsigned DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `receive_count` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_m_s_notifies`
--

LOCK TABLES `s_m_s_notifies` WRITE;
/*!40000 ALTER TABLE `s_m_s_notifies` DISABLE KEYS */;
INSERT INTO `s_m_s_notifies` VALUES (3,0,0,0,0,0,'This depends on when you enrol. Your fees are due 30 days from your starting date. For more information, please see Fees due dates.',8,1,1,NULL,'2022-10-03 12:28:07','2022-10-03 12:28:07');
/*!40000 ALTER TABLE `s_m_s_notifies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s_m_s_settings`
--

DROP TABLE IF EXISTS `s_m_s_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_m_s_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nexmo_key` text COLLATE utf8mb4_unicode_ci,
  `nexmo_secret` text COLLATE utf8mb4_unicode_ci,
  `nexmo_sender_name` text COLLATE utf8mb4_unicode_ci,
  `twilio_sid` text COLLATE utf8mb4_unicode_ci,
  `twilio_auth_token` text COLLATE utf8mb4_unicode_ci,
  `twilio_number` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1 Twilio, 2 Nexmo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_m_s_settings`
--

LOCK TABLES `s_m_s_settings` WRITE;
/*!40000 ALTER TABLE `s_m_s_settings` DISABLE KEYS */;
INSERT INTO `s_m_s_settings` VALUES (1,'test','test','ABC','43345435','213213','+14154461617',1,'2022-09-30 12:00:47','2022-09-30 12:00:47');
/*!40000 ALTER TABLE `s_m_s_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_settings`
--

DROP TABLE IF EXISTS `schedule_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` int(11) NOT NULL,
  `time` time NOT NULL,
  `email` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 Inactive, 1 Active',
  `sms` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 Inactive, 1 Active',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `schedule_settings_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_settings`
--

LOCK TABLES `schedule_settings` WRITE;
/*!40000 ALTER TABLE `schedule_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seat` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,'Section A',NULL,1,'2025-04-03 03:42:23','2025-04-03 03:42:23'),(2,'Section B',NULL,1,'2025-04-03 03:42:36','2025-04-03 03:42:36'),(3,'Section C',NULL,1,'2025-04-03 03:42:48','2025-04-03 03:42:48'),(4,'Section D',NULL,1,'2025-04-03 03:43:01','2025-04-03 03:43:01');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semesters`
--

DROP TABLE IF EXISTS `semesters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semesters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `semesters_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semesters`
--

LOCK TABLES `semesters` WRITE;
/*!40000 ALTER TABLE `semesters` DISABLE KEYS */;
INSERT INTO `semesters` VALUES (1,'1st Semester','1',1,'2025-04-03 03:33:22','2025-04-03 03:33:22'),(2,'2nd Semester','1',1,'2025-04-03 03:33:37','2025-04-03 03:33:37'),(3,'3rd Semester','2',1,'2025-04-03 03:35:09','2025-04-03 03:35:09'),(4,'4th Semester','2',1,'2025-04-03 03:35:34','2025-04-03 03:35:34'),(5,'5th Semester','3',1,'2025-04-03 03:37:43','2025-04-03 03:37:43'),(6,'6th Semester','3',1,'2025-04-03 03:38:03','2025-04-03 03:38:03'),(7,'7th Semester','4',1,'2025-04-03 03:38:15','2025-04-03 03:38:15'),(8,'8th Semester','4',1,'2025-04-03 03:38:28','2025-04-03 03:38:28'),(9,'1st Trimester','1',1,'2025-04-03 03:40:06','2025-04-03 03:41:40'),(10,'2nd Trimester','1',1,'2025-04-03 03:40:42','2025-04-03 03:40:42'),(11,'3rd Trimester','1',1,'2025-04-03 03:40:55','2025-04-03 03:40:55'),(12,'4th Trimester','1',1,'2025-04-03 03:41:23','2025-04-03 03:41:23');
/*!40000 ALTER TABLE `semesters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `current` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,'2023-2024','2023-07-01','2024-06-30',0,1,'2025-04-03 03:44:07','2025-04-28 11:32:21'),(2,'2024-2025','2024-07-01','2025-06-30',1,1,'2025-04-03 03:44:23','2025-04-28 11:32:21'),(3,'Summer-2025','2024-07-01','2025-06-30',0,1,'2025-04-03 03:44:23','2025-04-28 11:32:21'),(4,'Fall-2024','2024-07-01','2025-06-30',0,1,'2025-04-03 03:44:23','2025-04-28 11:32:21');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academy_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `logo_path` text COLLATE utf8mb4_unicode_ci,
  `favicon_path` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `week_start` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_zone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decimal_place` int(11) NOT NULL DEFAULT '2',
  `copyright_text` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Campus365 Digital Space for Univrersities',NULL,'Campus365 Digital Space for Univrersities',NULL,NULL,'campus_365_(1)_1716407954.png','favicon_1666015465.png',NULL,NULL,NULL,NULL,NULL,'d-m-Y','h:i A',NULL,'Asia/Dhaka','BDT','tk',2,'<p>2024 - Campus365 Digital Space for Univrersities</p>',1,'2022-09-30 12:00:47','2024-05-22 14:00:26');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sliders`
--

DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sliders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_title` text COLLATE utf8mb4_unicode_ci,
  `button_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sliders_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sliders`
--

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
INSERT INTO `sliders` VALUES (1,1,'Education is the best key success in life','Donec vitae libero non enim placerat eleifend aliquam erat volutpat. Curabitur diam ex, dapibus purus sapien, cursus sed nisl tristique, commodo gravida lectus non.','Discover More','https://www.campus365.pro/','slider_bg_01_1692915046.png',1,'2023-08-24 16:10:47','2023-08-24 16:10:47'),(2,1,'Welcome to the largest campus of education','Donec vitae libero non enim placerat eleifend aliquam erat volutpat. Curabitur diam ex, dapibus purus sapien, cursus sed nisl tristique, commodo gravida lectus non.','Discover More','https://www.campus365.pro/','slider_img03_1692915113.png',1,'2023-08-24 16:11:53','2023-08-24 16:11:53');
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_settings`
--

DROP TABLE IF EXISTS `social_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pinterest` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tiktok` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skype` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_settings`
--

LOCK TABLES `social_settings` WRITE;
/*!40000 ALTER TABLE `social_settings` DISABLE KEYS */;
INSERT INTO `social_settings` VALUES (1,'https://www.facebook.com/campus365.pro/','https://twitter.com/campus365.pro','https://www.linkedin.com/company/campus365-pro/',NULL,'https://www.pinterest.com/campus365.pro/','https://www.youtube.com/@campus365pro',NULL,NULL,NULL,NULL,1,'2023-08-24 15:50:31','2023-08-24 15:53:47');
/*!40000 ALTER TABLE `social_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_attendances`
--

DROP TABLE IF EXISTS `staff_attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_attendances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `date` date NOT NULL,
  `attendance` int(11) NOT NULL DEFAULT '0' COMMENT '1 Present, 2 Absent, 3 Leave, 4 Holiday',
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_attendances_user_id_foreign` (`user_id`),
  CONSTRAINT `staff_attendances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_attendances`
--

LOCK TABLES `staff_attendances` WRITE;
/*!40000 ALTER TABLE `staff_attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_hourly_attendances`
--

DROP TABLE IF EXISTS `staff_hourly_attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_hourly_attendances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `date` date NOT NULL,
  `attendance` int(11) NOT NULL DEFAULT '0' COMMENT '1 Present, 2 Absent, 3 Leave, 4 Holiday',
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_hourly_attendances_user_id_foreign` (`user_id`),
  KEY `staff_hourly_attendances_subject_id_foreign` (`subject_id`),
  CONSTRAINT `staff_hourly_attendances_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `staff_hourly_attendances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_hourly_attendances`
--

LOCK TABLES `staff_hourly_attendances` WRITE;
/*!40000 ALTER TABLE `staff_hourly_attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_hourly_attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status_type_student`
--

DROP TABLE IF EXISTS `status_type_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status_type_student` (
  `status_type_id` int(10) unsigned NOT NULL,
  `student_id` bigint(20) unsigned NOT NULL,
  KEY `status_type_student_status_type_id_foreign` (`status_type_id`),
  KEY `status_type_student_student_id_foreign` (`student_id`),
  CONSTRAINT `status_type_student_status_type_id_foreign` FOREIGN KEY (`status_type_id`) REFERENCES `status_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `status_type_student_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_type_student`
--

LOCK TABLES `status_type_student` WRITE;
/*!40000 ALTER TABLE `status_type_student` DISABLE KEYS */;
INSERT INTO `status_type_student` VALUES (2,1),(1,407);
/*!40000 ALTER TABLE `status_type_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status_types`
--

DROP TABLE IF EXISTS `status_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `status_types_title_unique` (`title`),
  UNIQUE KEY `status_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_types`
--

LOCK TABLES `status_types` WRITE;
/*!40000 ALTER TABLE `status_types` DISABLE KEYS */;
INSERT INTO `status_types` VALUES (1,'New Admission','new-admission',NULL,1,NULL,NULL),(2,'Continue','continue',NULL,1,NULL,NULL),(3,'Pass Out','pass-out',NULL,1,NULL,NULL),(4,'Drop Out','drop-out',NULL,1,NULL,NULL),(5,'Transfer In','transfer-in',NULL,1,NULL,NULL),(6,'Transfer Out','transfer-out',NULL,1,NULL,NULL),(7,'Disabled','disabled',NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `status_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_assignments`
--

DROP TABLE IF EXISTS `student_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_assignments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_enroll_id` bigint(20) unsigned NOT NULL,
  `assignment_id` bigint(20) unsigned NOT NULL,
  `marks` decimal(5,2) DEFAULT NULL,
  `attendance` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_assignments_student_enroll_id_foreign` (`student_enroll_id`),
  KEY `student_assignments_assignment_id_foreign` (`assignment_id`),
  CONSTRAINT `student_assignments_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_assignments_student_enroll_id_foreign` FOREIGN KEY (`student_enroll_id`) REFERENCES `student_enrolls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_assignments`
--

LOCK TABLES `student_assignments` WRITE;
/*!40000 ALTER TABLE `student_assignments` DISABLE KEYS */;
INSERT INTO `student_assignments` VALUES (1,471,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(2,466,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(3,450,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(4,400,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(5,361,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(6,331,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(7,321,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(8,314,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(9,257,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(10,179,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(11,153,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(12,132,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(13,116,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(14,17,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50'),(15,2,1,NULL,NULL,NULL,NULL,3,NULL,'2025-04-12 12:27:50','2025-04-12 12:27:50');
/*!40000 ALTER TABLE `student_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_attendances`
--

DROP TABLE IF EXISTS `student_attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_attendances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_enroll_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  `time` time DEFAULT NULL,
  `attendance` int(11) NOT NULL DEFAULT '0' COMMENT '1 Present, 2 Absent, 3 Leave, 4 Holiday',
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_attendances_student_enroll_id_foreign` (`student_enroll_id`),
  KEY `student_attendances_subject_id_foreign` (`subject_id`),
  CONSTRAINT `student_attendances_student_enroll_id_foreign` FOREIGN KEY (`student_enroll_id`) REFERENCES `student_enrolls` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_attendances_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_attendances`
--

LOCK TABLES `student_attendances` WRITE;
/*!40000 ALTER TABLE `student_attendances` DISABLE KEYS */;
INSERT INTO `student_attendances` VALUES (1,471,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(2,2,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(3,450,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(4,361,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(5,116,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(6,17,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(7,257,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(8,132,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(9,179,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(10,331,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(11,400,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(12,466,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(13,321,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(14,314,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(15,153,9,'2025-04-17',NULL,1,'',1,NULL,'2025-04-17 12:38:10','2025-04-17 12:38:10'),(16,471,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(17,2,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(18,450,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(19,361,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(20,116,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(21,17,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(22,257,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(23,132,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(24,179,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(25,331,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(26,400,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(27,466,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(28,321,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(29,314,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(30,153,9,'2025-04-10',NULL,1,'',1,NULL,'2025-04-17 12:38:33','2025-04-17 12:38:33'),(31,2,5,'2025-04-27',NULL,2,'',3,NULL,'2025-04-27 12:56:31','2025-04-27 12:56:31'),(32,361,5,'2025-04-27',NULL,1,'',3,NULL,'2025-04-27 12:56:31','2025-04-27 12:56:31'),(33,179,5,'2025-04-27',NULL,2,'',3,NULL,'2025-04-27 12:56:31','2025-04-27 12:56:31'),(34,400,5,'2025-04-27',NULL,1,'',3,NULL,'2025-04-27 12:56:31','2025-04-27 12:56:31'),(35,321,5,'2025-04-27',NULL,2,'',3,NULL,'2025-04-27 12:56:31','2025-04-27 12:56:31'),(36,314,5,'2025-04-27',NULL,1,'',3,NULL,'2025-04-27 12:56:31','2025-04-27 12:56:31'),(37,153,5,'2025-04-27',NULL,2,'',3,NULL,'2025-04-27 12:56:31','2025-04-27 12:56:31'),(38,2,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-27 13:04:01','2025-04-27 13:04:01'),(39,361,8,'2025-04-27',NULL,2,'',3,NULL,'2025-04-27 13:04:01','2025-04-27 13:04:01'),(40,179,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-27 13:04:01','2025-04-27 13:04:01'),(41,400,8,'2025-04-27',NULL,2,'',3,NULL,'2025-04-27 13:04:01','2025-04-27 13:04:01'),(42,321,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-27 13:04:01','2025-04-27 13:04:01'),(43,314,8,'2025-04-27',NULL,2,'',3,NULL,'2025-04-27 13:04:01','2025-04-27 13:04:01'),(44,153,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-27 13:04:01','2025-04-27 13:04:01'),(45,2,9,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:09:23','2025-04-28 11:09:23'),(46,361,9,'2025-04-28',NULL,2,'',3,NULL,'2025-04-28 11:09:23','2025-04-28 11:09:23'),(47,179,9,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:09:23','2025-04-28 11:09:23'),(48,400,9,'2025-04-28',NULL,2,'',3,NULL,'2025-04-28 11:09:23','2025-04-28 11:09:23'),(49,321,9,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:09:23','2025-04-28 11:09:23'),(50,314,9,'2025-04-28',NULL,2,'',3,NULL,'2025-04-28 11:09:23','2025-04-28 11:09:23'),(51,153,9,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:09:23','2025-04-28 11:09:23'),(52,471,8,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:57:38','2025-04-28 11:57:38'),(53,450,8,'2025-04-28',NULL,2,'',3,NULL,'2025-04-28 11:57:38','2025-04-28 11:57:38'),(54,116,8,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:57:38','2025-04-28 11:57:38'),(55,17,8,'2025-04-28',NULL,2,'',3,NULL,'2025-04-28 11:57:38','2025-04-28 11:57:38'),(56,257,8,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:57:38','2025-04-28 11:57:38'),(57,132,8,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:57:38','2025-04-28 11:57:38'),(58,331,8,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:57:38','2025-04-28 11:57:38'),(59,466,8,'2025-04-28',NULL,1,'',3,NULL,'2025-04-28 11:57:39','2025-04-28 11:57:39'),(60,471,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-28 11:58:54','2025-04-28 11:58:54'),(61,450,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-28 11:58:54','2025-04-28 11:58:54'),(62,116,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-28 11:58:54','2025-04-28 11:58:54'),(63,17,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-28 11:58:54','2025-04-28 11:58:54'),(64,257,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-28 11:58:54','2025-04-28 11:58:54'),(65,132,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-28 11:58:54','2025-04-28 11:58:54'),(66,331,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-28 11:58:54','2025-04-28 11:58:54'),(67,466,8,'2025-04-27',NULL,1,'',3,NULL,'2025-04-28 11:58:54','2025-04-28 11:58:54'),(68,471,8,'2025-04-20',NULL,1,'',3,NULL,'2025-04-28 12:01:14','2025-04-28 12:01:14'),(69,450,8,'2025-04-20',NULL,1,'',3,NULL,'2025-04-28 12:01:14','2025-04-28 12:01:14'),(70,116,8,'2025-04-20',NULL,2,'',3,NULL,'2025-04-28 12:01:14','2025-04-28 12:01:14'),(71,17,8,'2025-04-20',NULL,2,'',3,NULL,'2025-04-28 12:01:14','2025-04-28 12:01:14'),(72,257,8,'2025-04-20',NULL,1,'',3,NULL,'2025-04-28 12:01:14','2025-04-28 12:01:14'),(73,132,8,'2025-04-20',NULL,1,'',3,NULL,'2025-04-28 12:01:14','2025-04-28 12:01:14'),(74,331,8,'2025-04-20',NULL,1,'',3,NULL,'2025-04-28 12:01:14','2025-04-28 12:01:14'),(75,466,8,'2025-04-20',NULL,2,'',3,NULL,'2025-04-28 12:01:14','2025-04-28 12:01:14'),(76,471,8,'2025-03-23',NULL,1,'',3,NULL,'2025-04-28 12:01:41','2025-04-28 12:01:41'),(77,450,8,'2025-03-23',NULL,1,'',3,NULL,'2025-04-28 12:01:41','2025-04-28 12:01:41'),(78,116,8,'2025-03-23',NULL,1,'',3,NULL,'2025-04-28 12:01:41','2025-04-28 12:01:41'),(79,17,8,'2025-03-23',NULL,2,'',3,NULL,'2025-04-28 12:01:41','2025-04-28 12:01:41'),(80,257,8,'2025-03-23',NULL,1,'',3,NULL,'2025-04-28 12:01:41','2025-04-28 12:01:41'),(81,132,8,'2025-03-23',NULL,2,'',3,NULL,'2025-04-28 12:01:41','2025-04-28 12:01:41'),(82,331,8,'2025-03-23',NULL,1,'',3,NULL,'2025-04-28 12:01:41','2025-04-28 12:01:41'),(83,466,8,'2025-03-23',NULL,1,'',3,NULL,'2025-04-28 12:01:41','2025-04-28 12:01:41'),(84,471,8,'2025-03-30',NULL,1,'',3,NULL,'2025-04-28 12:02:01','2025-04-28 12:02:01'),(85,450,8,'2025-03-30',NULL,1,'',3,NULL,'2025-04-28 12:02:01','2025-04-28 12:02:01'),(86,116,8,'2025-03-30',NULL,2,'',3,NULL,'2025-04-28 12:02:01','2025-04-28 12:02:01'),(87,17,8,'2025-03-30',NULL,2,'',3,NULL,'2025-04-28 12:02:01','2025-04-28 12:02:01'),(88,257,8,'2025-03-30',NULL,1,'',3,NULL,'2025-04-28 12:02:01','2025-04-28 12:02:01'),(89,132,8,'2025-03-30',NULL,2,'',3,NULL,'2025-04-28 12:02:01','2025-04-28 12:02:01'),(90,331,8,'2025-03-30',NULL,1,'',3,NULL,'2025-04-28 12:02:01','2025-04-28 12:02:01'),(91,466,8,'2025-03-30',NULL,1,'',3,NULL,'2025-04-28 12:02:01','2025-04-28 12:02:01'),(92,471,8,'2025-03-16',NULL,2,'',3,NULL,'2025-04-28 12:19:57','2025-04-28 12:19:57'),(93,450,8,'2025-03-16',NULL,2,'',3,NULL,'2025-04-28 12:19:57','2025-04-28 12:19:57'),(94,116,8,'2025-03-16',NULL,2,'',3,NULL,'2025-04-28 12:19:57','2025-04-28 12:19:57'),(95,17,8,'2025-03-16',NULL,2,'',3,NULL,'2025-04-28 12:19:57','2025-04-28 12:19:57'),(96,257,8,'2025-03-16',NULL,2,'',3,NULL,'2025-04-28 12:19:57','2025-04-28 12:19:57'),(97,132,8,'2025-03-16',NULL,2,'',3,NULL,'2025-04-28 12:19:57','2025-04-28 12:19:57'),(98,331,8,'2025-03-16',NULL,2,'',3,NULL,'2025-04-28 12:19:57','2025-04-28 12:19:57'),(99,466,8,'2025-03-16',NULL,2,'',3,NULL,'2025-04-28 12:19:57','2025-04-28 12:19:57');
/*!40000 ALTER TABLE `student_attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_enroll_subject`
--

DROP TABLE IF EXISTS `student_enroll_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_enroll_subject` (
  `student_enroll_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  KEY `student_enroll_subject_student_enroll_id_foreign` (`student_enroll_id`),
  KEY `student_enroll_subject_subject_id_foreign` (`subject_id`),
  CONSTRAINT `student_enroll_subject_student_enroll_id_foreign` FOREIGN KEY (`student_enroll_id`) REFERENCES `student_enrolls` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_enroll_subject_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_enroll_subject`
--

LOCK TABLES `student_enroll_subject` WRITE;
/*!40000 ALTER TABLE `student_enroll_subject` DISABLE KEYS */;
INSERT INTO `student_enroll_subject` VALUES (1,100),(1,101),(1,102),(1,103),(1,104),(2,1),(2,2),(2,3),(2,8),(2,9),(6,100),(6,101),(6,102),(6,103),(6,104),(7,87),(7,88),(7,89),(7,90),(7,91),(11,87),(11,88),(11,89),(11,90),(11,91),(16,100),(16,101),(16,102),(16,103),(16,104),(17,1),(17,2),(17,3),(17,8),(17,9),(24,87),(24,88),(24,89),(24,90),(24,91),(25,100),(25,101),(25,102),(25,103),(25,104),(32,87),(32,88),(32,89),(32,90),(32,91),(36,87),(36,88),(36,89),(36,90),(36,91),(42,100),(42,101),(42,102),(42,103),(42,104),(43,87),(43,88),(43,89),(43,90),(43,91),(44,87),(44,88),(44,89),(44,90),(44,91),(47,100),(47,101),(47,102),(47,103),(47,104),(53,1),(53,2),(53,3),(53,8),(53,9),(60,1),(60,2),(60,3),(60,8),(60,9),(71,1),(71,2),(71,3),(71,8),(71,9),(72,87),(72,88),(72,89),(72,90),(72,91),(78,87),(78,88),(78,89),(78,90),(78,91),(85,87),(85,88),(85,89),(85,90),(85,91),(93,100),(93,101),(93,102),(93,103),(93,104),(105,100),(105,101),(105,102),(105,103),(105,104),(107,87),(107,88),(107,89),(107,90),(107,91),(114,87),(114,88),(114,89),(114,90),(114,91),(116,1),(116,2),(116,3),(116,8),(116,9),(122,100),(122,101),(122,102),(122,103),(122,104),(124,100),(124,101),(124,102),(124,103),(124,104),(132,1),(132,2),(132,3),(132,8),(132,9),(135,100),(135,101),(135,102),(135,103),(135,104),(148,1),(148,2),(148,3),(148,8),(148,9),(150,1),(150,2),(150,3),(150,8),(150,9),(153,1),(153,2),(153,3),(153,8),(153,9),(158,87),(158,88),(158,89),(158,90),(158,91),(159,100),(159,101),(159,102),(159,103),(159,104),(160,100),(160,101),(160,102),(160,103),(160,104),(167,87),(167,88),(167,89),(167,90),(167,91),(177,87),(177,88),(177,89),(177,90),(177,91),(179,1),(179,2),(179,3),(179,8),(179,9),(180,1),(180,2),(180,3),(180,8),(180,9),(185,87),(185,88),(185,89),(185,90),(185,91),(194,87),(194,88),(194,89),(194,90),(194,91),(199,100),(199,101),(199,102),(199,103),(199,104),(205,87),(205,88),(205,89),(205,90),(205,91),(206,100),(206,101),(206,102),(206,103),(206,104),(214,87),(214,88),(214,89),(214,90),(214,91),(221,100),(221,101),(221,102),(221,103),(221,104),(229,87),(229,88),(229,89),(229,90),(229,91),(232,1),(232,2),(232,3),(232,8),(232,9),(240,1),(240,2),(240,3),(240,8),(240,9),(255,1),(255,2),(255,3),(255,8),(255,9),(256,100),(256,101),(256,102),(256,103),(256,104),(257,1),(257,2),(257,3),(257,8),(257,9),(259,87),(259,88),(259,89),(259,90),(259,91),(262,87),(262,88),(262,89),(262,90),(262,91),(263,1),(263,2),(263,3),(263,8),(263,9),(270,100),(270,101),(270,102),(270,103),(270,104),(276,87),(276,88),(276,89),(276,90),(276,91),(283,87),(283,88),(283,89),(283,90),(283,91),(287,1),(287,2),(287,3),(287,8),(287,9),(293,100),(293,101),(293,102),(293,103),(293,104),(295,1),(295,2),(295,3),(295,8),(295,9),(298,100),(298,101),(298,102),(298,103),(298,104),(304,87),(304,88),(304,89),(304,90),(304,91),(314,1),(314,2),(314,3),(314,8),(314,9),(318,87),(318,88),(318,89),(318,90),(318,91),(319,100),(319,101),(319,102),(319,103),(319,104),(321,1),(321,2),(321,3),(321,8),(321,9),(325,100),(325,101),(325,102),(325,103),(325,104),(327,87),(327,88),(327,89),(327,90),(327,91),(329,87),(329,88),(329,89),(329,90),(329,91),(331,1),(331,2),(331,3),(331,8),(331,9),(334,87),(334,88),(334,89),(334,90),(334,91),(336,100),(336,101),(336,102),(336,103),(336,104),(340,100),(340,101),(340,102),(340,103),(340,104),(349,1),(349,2),(349,3),(349,8),(349,9),(352,100),(352,101),(352,102),(352,103),(352,104),(356,87),(356,88),(356,89),(356,90),(356,91),(357,87),(357,88),(357,89),(357,90),(357,91),(361,1),(361,2),(361,3),(361,8),(361,9),(362,100),(362,101),(362,102),(362,103),(362,104),(382,1),(382,2),(382,3),(382,8),(382,9),(389,87),(389,88),(389,89),(389,90),(389,91),(400,1),(400,2),(400,3),(400,8),(400,9),(404,87),(404,88),(404,89),(404,90),(404,91),(410,100),(410,101),(410,102),(410,103),(410,104),(413,87),(413,88),(413,89),(413,90),(413,91),(424,1),(424,2),(424,3),(424,8),(424,9),(425,87),(425,88),(425,89),(425,90),(425,91),(433,87),(433,88),(433,89),(433,90),(433,91),(435,87),(435,88),(435,89),(435,90),(435,91),(437,100),(437,101),(437,102),(437,103),(437,104),(449,100),(449,101),(449,102),(449,103),(449,104),(450,1),(450,2),(450,3),(450,8),(450,9),(463,87),(463,88),(463,89),(463,90),(463,91),(466,1),(466,2),(466,3),(466,8),(466,9),(469,87),(469,88),(469,89),(469,90),(469,91),(471,1),(471,2),(471,3),(471,8),(471,9),(478,87),(478,88),(478,89),(478,90),(478,91),(480,1),(480,2),(480,3),(480,8),(480,9),(488,1),(488,2),(488,3),(488,8),(488,9),(498,100),(498,101),(498,102),(498,103),(498,104);
/*!40000 ALTER TABLE `student_enroll_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_enrolls`
--

DROP TABLE IF EXISTS `student_enrolls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_enrolls` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  `section_id` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_enrolls_student_id_foreign` (`student_id`),
  KEY `student_enrolls_program_id_foreign` (`program_id`),
  KEY `student_enrolls_session_id_foreign` (`session_id`),
  KEY `student_enrolls_semester_id_foreign` (`semester_id`),
  KEY `student_enrolls_section_id_foreign` (`section_id`),
  CONSTRAINT `student_enrolls_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_enrolls_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_enrolls_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_enrolls_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_enrolls_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=501 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_enrolls`
--

LOCK TABLES `student_enrolls` WRITE;
/*!40000 ALTER TABLE `student_enrolls` DISABLE KEYS */;
INSERT INTO `student_enrolls` VALUES (1,1,3,3,9,2,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(2,2,1,2,1,1,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(3,3,2,1,4,1,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(4,4,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(5,5,1,2,6,1,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(6,6,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(7,7,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(8,8,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(9,9,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00'),(10,10,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01'),(11,11,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01'),(12,12,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01'),(13,13,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01'),(14,14,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01'),(15,15,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01'),(16,16,3,3,9,2,1,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01'),(17,17,1,2,1,2,1,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01'),(18,18,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(19,19,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(20,20,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(21,21,1,2,7,1,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(22,22,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(23,23,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(24,24,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(25,25,3,3,9,2,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(26,26,3,4,11,2,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(27,27,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02'),(28,28,1,1,8,2,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(29,29,2,1,4,1,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(30,30,1,2,3,2,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(31,31,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(32,32,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(33,33,1,1,7,1,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(34,34,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(35,35,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(36,36,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03'),(37,37,3,4,11,2,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(38,38,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(39,39,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(40,40,3,4,11,2,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(41,41,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(42,42,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(43,43,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(44,44,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(45,45,3,4,12,3,1,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04'),(46,46,1,2,6,1,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(47,47,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(48,48,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(49,49,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(50,50,2,2,2,2,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(51,51,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(52,52,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(53,53,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(54,54,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(55,55,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05'),(56,56,1,2,2,2,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(57,57,3,4,11,1,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(58,58,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(59,59,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(60,60,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(61,61,1,2,4,2,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(62,62,1,2,3,2,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(63,63,3,4,9,3,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(64,64,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06'),(65,65,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(66,66,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(67,67,1,2,2,1,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(68,68,3,4,11,3,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(69,69,1,2,3,2,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(70,70,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(71,71,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(72,72,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(73,73,2,2,2,1,1,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07'),(74,74,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(75,75,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(76,76,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(77,77,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(78,78,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(79,79,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(80,80,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(81,81,1,1,6,2,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(82,82,3,3,11,1,1,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08'),(83,83,1,1,6,1,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(84,84,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(85,85,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(86,86,1,2,8,1,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(87,87,1,1,8,2,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(88,88,1,1,5,1,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(89,89,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(90,90,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(91,91,1,2,2,2,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(92,92,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09'),(93,93,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(94,94,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(95,95,1,1,8,1,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(96,96,1,1,5,1,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(97,97,1,2,3,1,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(98,98,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(99,99,3,3,11,2,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(100,100,3,4,12,3,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(101,101,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10'),(102,102,1,2,5,1,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(103,103,3,3,9,3,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(104,104,3,4,11,3,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(105,105,3,4,9,2,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(106,106,2,2,2,2,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(107,107,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(108,108,1,2,8,1,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(109,109,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(110,110,3,4,11,2,1,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11'),(111,111,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(112,112,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(113,113,1,1,5,2,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(114,114,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(115,115,3,3,11,2,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(116,116,1,2,1,2,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(117,117,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(118,118,1,1,6,2,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(119,119,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12'),(120,120,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(121,121,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(122,122,3,4,9,2,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(123,123,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(124,124,3,3,9,1,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(125,125,1,2,2,1,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(126,126,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(127,127,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(128,128,1,2,2,2,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(129,129,1,1,8,1,1,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13'),(130,130,1,2,3,2,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(131,131,1,2,8,1,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(132,132,1,2,1,2,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(133,133,1,1,7,1,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(134,134,1,2,3,1,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(135,135,3,3,9,2,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(136,136,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(137,137,2,2,3,1,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(138,138,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14'),(139,139,1,1,4,1,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(140,140,1,1,5,2,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(141,141,1,1,8,1,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(142,142,1,1,2,2,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(143,143,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(144,144,1,1,4,1,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(145,145,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(146,146,1,1,5,1,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(147,147,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15'),(148,148,1,1,1,2,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(149,149,1,2,5,1,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(150,150,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(151,151,1,2,7,2,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(152,152,3,4,11,1,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(153,153,1,2,1,1,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(154,154,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(155,155,1,1,7,2,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(156,156,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16'),(157,157,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(158,158,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(159,159,3,3,9,1,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(160,160,3,3,9,2,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(161,161,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(162,162,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(163,163,3,3,11,1,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(164,164,2,1,4,1,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(165,165,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17'),(166,166,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(167,167,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(168,168,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(169,169,1,2,8,2,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(170,170,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(171,171,3,3,12,1,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(172,172,3,4,12,3,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(173,173,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(174,174,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(175,175,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18'),(176,176,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(177,177,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(178,178,3,3,9,3,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(179,179,1,2,1,1,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(180,180,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(181,181,3,4,11,2,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(182,182,3,4,12,1,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(183,183,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(184,184,1,1,5,1,1,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19'),(185,185,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(186,186,1,2,3,1,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(187,187,3,3,12,3,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(188,188,3,4,10,3,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(189,189,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(190,190,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(191,191,1,2,6,2,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(192,192,2,1,4,1,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(193,193,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20'),(194,194,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(195,195,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(196,196,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(197,197,1,1,4,1,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(198,198,3,4,11,1,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(199,199,3,4,9,2,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(200,200,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(201,201,3,4,10,3,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(202,202,1,1,4,2,1,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21'),(203,203,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(204,204,2,2,2,1,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(205,205,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(206,206,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(207,207,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(208,208,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(209,209,2,2,2,1,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(210,210,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(211,211,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22'),(212,212,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(213,213,1,1,2,2,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(214,214,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(215,215,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(216,216,3,4,12,3,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(217,217,2,2,2,1,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(218,218,3,3,11,1,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(219,219,1,2,6,1,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(220,220,1,2,3,2,1,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23'),(221,221,3,4,9,2,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(222,222,3,4,12,3,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(223,223,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(224,224,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(225,225,1,2,4,1,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(226,226,1,1,5,1,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(227,227,1,1,3,2,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(228,228,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(229,229,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(230,230,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24'),(231,231,1,2,8,2,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(232,232,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(233,233,1,2,5,1,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(234,234,3,4,11,1,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(235,235,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(236,236,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(237,237,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(238,238,1,2,3,2,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(239,239,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25'),(240,240,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(241,241,3,4,11,1,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(242,242,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(243,243,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(244,244,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(245,245,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(246,246,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(247,247,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(248,248,1,2,8,2,1,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26'),(249,249,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(250,250,2,2,3,1,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(251,251,2,2,3,1,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(252,252,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(253,253,1,1,8,2,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(254,254,1,2,4,2,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(255,255,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(256,256,3,3,9,2,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(257,257,1,2,1,2,1,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27'),(258,258,3,3,11,1,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(259,259,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(260,260,1,2,7,1,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(261,261,1,1,8,1,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(262,262,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(263,263,1,1,1,2,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(264,264,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(265,265,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(266,266,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(267,267,1,2,4,1,1,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28'),(268,268,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(269,269,3,3,9,3,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(270,270,3,3,9,1,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(271,271,2,1,4,2,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(272,272,2,2,2,1,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(273,273,1,2,7,1,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(274,274,1,1,5,2,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(275,275,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(276,276,2,1,1,2,1,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29'),(277,277,1,2,5,1,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(278,278,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(279,279,1,1,5,2,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(280,280,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(281,281,3,3,12,1,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(282,282,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(283,283,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(284,284,3,3,12,1,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(285,285,2,2,2,1,1,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30'),(286,286,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(287,287,1,1,1,2,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(288,288,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(289,289,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(290,290,1,2,5,2,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(291,291,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(292,292,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(293,293,3,3,9,1,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(294,294,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31'),(295,295,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(296,296,1,2,6,2,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(297,297,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(298,298,3,4,9,2,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(299,299,1,2,3,2,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(300,300,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(301,301,3,4,11,1,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(302,302,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(303,303,3,4,11,3,1,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32'),(304,304,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(305,305,3,4,9,3,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(306,306,3,4,10,3,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(307,307,3,4,11,1,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(308,308,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(309,309,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(310,310,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(311,311,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(312,312,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(313,313,2,2,3,1,1,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33'),(314,314,1,2,1,1,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(315,315,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(316,316,3,4,12,1,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(317,317,1,1,2,2,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(318,318,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(319,319,3,3,9,1,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(320,320,3,3,12,2,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(321,321,1,2,1,1,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(322,322,3,4,10,3,1,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34'),(323,323,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(324,324,1,1,2,2,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(325,325,3,3,9,2,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(326,326,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(327,327,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(328,328,2,1,4,1,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(329,329,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(330,330,3,3,12,3,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(331,331,1,2,1,2,1,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35'),(332,332,1,1,3,2,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(333,333,3,3,12,3,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(334,334,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(335,335,1,1,3,2,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(336,336,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(337,337,1,1,2,2,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(338,338,1,1,3,2,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(339,339,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(340,340,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36'),(341,341,2,1,4,2,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(342,342,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(343,343,1,2,5,1,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(344,344,1,1,6,1,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(345,345,1,1,8,1,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(346,346,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(347,347,2,1,4,1,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(348,348,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(349,349,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37'),(350,350,1,2,6,2,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(351,351,3,3,11,2,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(352,352,3,4,9,2,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(353,353,1,2,8,2,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(354,354,1,1,8,2,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(355,355,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(356,356,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(357,357,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(358,358,1,2,2,1,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(359,359,1,2,4,1,1,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38'),(360,360,1,2,8,2,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(361,361,1,2,1,1,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(362,362,3,3,9,1,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(363,363,2,2,4,1,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(364,364,1,1,8,1,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(365,365,1,1,3,1,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(366,366,1,2,2,2,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(367,367,1,1,8,1,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(368,368,1,1,7,2,1,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39'),(369,369,3,4,11,3,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(370,370,3,4,9,3,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(371,371,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(372,372,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(373,373,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(374,374,2,2,2,1,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(375,375,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(376,376,1,2,7,2,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(377,377,1,1,4,2,1,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40'),(378,378,1,1,6,2,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(379,379,1,1,4,2,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(380,380,1,1,3,2,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(381,381,3,4,12,3,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(382,382,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(383,383,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(384,384,1,1,8,1,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(385,385,2,2,2,2,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(386,386,1,1,4,2,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(387,387,3,4,12,1,1,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41'),(388,388,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(389,389,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(390,390,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(391,391,1,1,7,1,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(392,392,2,2,2,1,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(393,393,2,2,3,1,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(394,394,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(395,395,1,2,5,2,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(396,396,3,3,12,1,1,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42'),(397,397,1,2,2,1,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(398,398,3,4,10,2,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(399,399,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(400,400,1,2,1,1,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(401,401,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(402,402,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(403,403,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(404,404,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(405,405,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43'),(406,406,3,3,9,3,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(407,407,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(408,408,1,2,8,1,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(409,409,2,1,3,2,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(410,410,3,3,9,1,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(411,411,3,3,9,3,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(412,412,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(413,413,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(414,414,1,1,5,1,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(415,415,3,3,11,2,1,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44'),(416,416,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(417,417,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(418,418,3,4,9,3,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(419,419,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(420,420,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(421,421,3,3,12,3,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(422,422,1,1,5,2,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(423,423,1,2,4,2,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(424,424,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45'),(425,425,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(426,426,3,4,11,2,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(427,427,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(428,428,3,3,11,3,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(429,429,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(430,430,2,2,2,2,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(431,431,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(432,432,2,2,2,2,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(433,433,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46'),(434,434,3,4,11,3,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(435,435,2,1,1,1,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(436,436,1,2,5,1,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(437,437,3,3,9,1,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(438,438,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(439,439,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(440,440,3,3,10,3,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(441,441,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(442,442,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47'),(443,443,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(444,444,1,2,2,1,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(445,445,3,4,10,1,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(446,446,1,2,7,2,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(447,447,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(448,448,3,4,12,2,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(449,449,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(450,450,1,2,1,2,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(451,451,1,1,4,1,1,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48'),(452,452,3,3,12,3,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(453,453,1,1,5,2,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(454,454,2,1,4,2,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(455,455,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(456,456,1,1,7,1,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(457,457,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(458,458,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(459,459,1,1,3,2,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(460,460,3,3,11,1,1,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49'),(461,461,1,2,5,1,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(462,462,2,1,2,1,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(463,463,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(464,464,1,2,8,1,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(465,465,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(466,466,1,2,1,2,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(467,467,1,2,5,2,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(468,468,2,1,3,1,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(469,469,2,2,1,1,1,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50'),(470,470,3,3,10,1,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(471,471,1,2,1,2,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(472,472,3,3,10,2,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(473,473,2,1,4,2,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(474,474,2,1,4,1,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(475,475,3,3,11,2,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(476,476,3,4,9,3,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(477,477,1,1,6,2,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(478,478,2,2,1,2,1,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51'),(479,479,1,1,6,2,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(480,480,1,1,1,1,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(481,481,1,1,2,1,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(482,482,1,1,6,1,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(483,483,1,2,2,2,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(484,484,1,2,4,2,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(485,485,3,4,12,1,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(486,486,3,3,11,1,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(487,487,3,4,12,1,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(488,488,1,1,1,2,1,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52'),(489,489,3,4,10,3,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(490,490,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(491,491,3,3,9,3,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(492,492,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(493,493,1,2,8,1,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(494,494,1,1,2,2,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(495,495,3,4,11,3,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(496,496,3,4,12,3,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(497,497,2,2,4,2,1,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53'),(498,498,3,4,9,1,1,NULL,NULL,'2025-04-11 12:40:54','2025-04-11 12:40:54'),(499,499,2,1,2,2,1,NULL,NULL,'2025-04-11 12:40:54','2025-04-11 12:40:54'),(500,500,2,2,3,2,1,NULL,NULL,'2025-04-11 12:40:54','2025-04-11 12:40:54');
/*!40000 ALTER TABLE `student_enrolls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_leaves`
--

DROP TABLE IF EXISTS `student_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_leaves` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `review_by` bigint(20) unsigned DEFAULT NULL,
  `apply_date` date NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 Pending, 1 Approved and 2 Rejected',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_leaves_student_id_foreign` (`student_id`),
  CONSTRAINT `student_leaves_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_leaves`
--

LOCK TABLES `student_leaves` WRITE;
/*!40000 ALTER TABLE `student_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_relatives`
--

DROP TABLE IF EXISTS `student_relatives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_relatives` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `relation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `photo` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `student_relatives_student_id_foreign` (`student_id`),
  CONSTRAINT `student_relatives_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_relatives`
--

LOCK TABLES `student_relatives` WRITE;
/*!40000 ALTER TABLE `student_relatives` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_relatives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_transfers`
--

DROP TABLE IF EXISTS `student_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_transfers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `transfer_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `university_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 Transfer In, 1 Transfer Out',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_transfers_student_id_foreign` (`student_id`),
  CONSTRAINT `student_transfers_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_transfers`
--

LOCK TABLES `student_transfers` WRITE;
/*!40000 ALTER TABLE `student_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_id` int(10) unsigned DEFAULT NULL,
  `program_id` int(10) unsigned DEFAULT NULL,
  `admission_date` date DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_text` longtext COLLATE utf8mb4_unicode_ci,
  `present_province` int(10) unsigned DEFAULT NULL,
  `present_district` int(10) unsigned DEFAULT NULL,
  `present_village` text COLLATE utf8mb4_unicode_ci,
  `present_address` text COLLATE utf8mb4_unicode_ci,
  `permanent_province` int(10) unsigned DEFAULT NULL,
  `permanent_district` int(10) unsigned DEFAULT NULL,
  `permanent_village` text COLLATE utf8mb4_unicode_ci,
  `permanent_address` text COLLATE utf8mb4_unicode_ci,
  `gender` int(11) NOT NULL COMMENT '1 Male, 2 Female & 3 Other',
  `dob` date NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_tongue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` int(11) DEFAULT NULL,
  `blood_group` int(11) DEFAULT NULL,
  `nationality` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `national_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_name` text COLLATE utf8mb4_unicode_ci,
  `school_exam_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_graduation_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_graduation_point` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collage_name` text COLLATE utf8mb4_unicode_ci,
  `collage_exam_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collage_graduation_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collage_graduation_point` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` text COLLATE utf8mb4_unicode_ci,
  `signature` text COLLATE utf8mb4_unicode_ci,
  `login` tinyint(1) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Inactive, 1 Active, 2 Passed Out, 3 Transfer Out',
  `is_transfer` int(11) DEFAULT '0' COMMENT '0 Not Transfer, 1 Transfer In & 2 Transfer Out',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `father_occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father_photo` text COLLATE utf8mb4_unicode_ci,
  `mother_photo` text COLLATE utf8mb4_unicode_ci,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `religion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caste` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_graduation_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collage_graduation_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `students_student_id_unique` (`student_id`),
  UNIQUE KEY `students_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=501 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'S59340','REG5631',6,3,NULL,'Lemuel','Greenholt',NULL,NULL,'kutch.emmanuelle@example.com',NULL,'$2y$10$QdJFnT/.TbgLPa1TAoWQp.sJDK0een0JtRWbIK8Te9VYlX.OCpama','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1988-03-17','754.581.3136',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'S13915','REG4050',4,1,NULL,'Nicolas','Waters',NULL,NULL,'hyost@example.org',NULL,'$2y$10$efO7o.1W0AM46GiCHJ8EVeKCHfeM5QyOHChP7cWeOgMPy37vB1gOC','eyJpdiI6Ijl2S1pKdEpaZStEM2NMOFRXU1ROVGc9PSIsInZhbHVlIjoiNlZub0RYcjNGa0NPLzk2cU1sT29jZz09IiwibWFjIjoiYzMyYWUzOWUyOTZlOTVhN2E4ZGQ4YTI4Y2Y4ZTg4MWY4NTRmZjhiODcwNzc5MzBjODZiYzEzMWM0ZWI4N2I1YSIsInRhZyI6IiJ9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2015-02-17','564.896.8011',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-28 11:17:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'S23641','REG9877',1,2,NULL,'Mathias','Deckow',NULL,NULL,'walsh.idell@example.com',NULL,'$2y$10$tlYOZpucDY6lzMcY1z6JOuD6wuY7iJy/ulk1QUpoF07D3E/eVLZZ2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1973-05-23','1-475-308-6750',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'S97540','REG2628',5,3,NULL,'Natalia','Labadie',NULL,NULL,'benton.feeney@example.org',NULL,'$2y$10$R5ULarZqjKY3FHxi9GKlTuNdOSgudnvRWUSuJi5IyhfRvA2nVBNui','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1992-10-07','(903) 392-0074',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'S44984','REG4506',3,1,NULL,'Talon','Bartoletti',NULL,NULL,'calista.keebler@example.com',NULL,'$2y$10$sVo7wrEo7Uk5cKYAQpqr.uGIWUt56./57KHSqpiFSw/JpHQP0Px72','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2009-11-11','(321) 292-3106',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'S15274','REG3655',6,3,NULL,'Kaley','Swaniawski',NULL,NULL,'april39@example.net',NULL,'$2y$10$Qd7qP3EP56A6l.ojfLbVJuSK83QTIpcNTL4w1q7auQ45cJjE2/yRG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1971-09-29','781-523-2453',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'S34290','REG6974',1,2,NULL,'Nora','Botsford',NULL,NULL,'kyleigh.gerlach@example.com',NULL,'$2y$10$zVFdPo/7OIRY7iqXL/Uawu4pntjPJlGHbG7omAdGq94zJLEqXHwU.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1991-07-25','+18784813282',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'S58926','REG9519',6,3,NULL,'Iliana','Rosenbaum',NULL,NULL,'fausto76@example.net',NULL,'$2y$10$ueh/SLH9e/uRr9L5gvCmb.M90V4E/vYvTEQXCBvRFN3Xzt0cb3fiq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1988-04-01','+19732098607',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'S02647','REG0656',2,2,NULL,'Orion','Stoltenberg',NULL,NULL,'alvera85@example.net',NULL,'$2y$10$c7z2zKA2De/FrksxN4BHHONXf.SwqZ/OA5PCzadn7WY58uabVdqru','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1970-05-03','(531) 263-2697',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:00','2025-04-11 12:40:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,'S54120','REG2120',2,2,NULL,'Favian','Bednar',NULL,NULL,'ylabadie@example.com',NULL,'$2y$10$UtQh1C3tyqwYwKGkq2FYVOrCAX2FEsGqnLT7O4O17ZOZur2AIbaJC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2003-01-15','828-929-9486',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'S90340','REG5431',1,2,NULL,'Lesly','Kuhn',NULL,NULL,'xstanton@example.com',NULL,'$2y$10$4XvLvkFONM6FCgj5ngTFXOHMO8dDtFpGMoEPHVjt93wNvR1mpEM5S','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2007-09-05','678-719-9210',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'S30330','REG0014',5,3,NULL,'Austen','Kemmer',NULL,NULL,'yquigley@example.org',NULL,'$2y$10$CPTIYi/dFRrsu6eFMOiVFO3dwt/bO6lbM4kt2ZU7iC4FWWXKZs9ie','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2002-03-24','1-785-546-4213',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'S18246','REG7042',5,3,NULL,'Aylin','King',NULL,NULL,'eldridge.welch@example.org',NULL,'$2y$10$2D5piHCaKpb2aqd4kED.be7WPyqhD7Oc1Q0EGpd01/Bywc4oHsaYm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1985-09-02','515-444-9937',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'S21350','REG1722',5,3,NULL,'Lavern','Graham',NULL,NULL,'zoie.kshlerin@example.org',NULL,'$2y$10$/0y236VLLICpxQ0jYpkxiO4ZIx1Jzw2WxW.JPjCnfOeFefBmasl1K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2017-10-14','(325) 613-2322',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'S87563','REG4943',5,3,NULL,'Nicholaus','Leannon',NULL,NULL,'simonis.bobbie@example.com',NULL,'$2y$10$TEUc7aHsqspdgx2oqxrX0u6jFq1sOPso8JPLBUuOm/z1kCutnzbO.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2018-05-23','+1.940.433.3519',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'S82468','REG1527',5,3,NULL,'Else','Muller',NULL,NULL,'hill.dusty@example.org',NULL,'$2y$10$O5LCRpTqJ92o2cjNkykZCOlZ5Abngd3HzzHCirr4fNUUFBCyRrJwK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1984-06-07','586.453.3560',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,'S41243','REG7921',4,1,NULL,'Alec','Kuhn',NULL,NULL,'myrtle74@example.net',NULL,'$2y$10$N7TAT3qkpcBq85.fqATCS.QH9ZKi/V6VB8TnY9fzAO6NGPTkkmQEa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2019-10-06','+1.408.616.5154',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,'S55076','REG4016',2,2,NULL,'Rory','Becker',NULL,NULL,'willa33@example.org',NULL,'$2y$10$izbU3Ej3hIBAU/CAxszTwOyezWHIcffsuR0uxa4xjU7Tt1.N/p9PO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2002-04-15','+1 (601) 273-1472',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:01','2025-04-11 12:40:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'S18334','REG0547',5,3,NULL,'Isadore','Cummerata',NULL,NULL,'jesse.morar@example.com',NULL,'$2y$10$5gNhimnRvQJectAG8Wkm..Fc.U6U.xd7l/vBxbpXW7hH6Dt0A1PiS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2024-09-16','+1-857-939-9166',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'S20974','REG2130',5,3,NULL,'Kaitlyn','Corwin',NULL,NULL,'anastasia59@example.com',NULL,'$2y$10$uJF4oxP47IA3ALcPOZ2AQO.zB6mG4ErTDsIGPEtUwFMk40ACxFnk.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1981-07-19','(321) 878-2105',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'S65222','REG0786',3,1,NULL,'Jacky','Beahan',NULL,NULL,'guiseppe03@example.net',NULL,'$2y$10$QHNuvBHWv3Mdz0edRvXPU..ewC3T/kuHKlaQp8UHIyXcWaSpxbyKS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2015-08-11','681.352.5339',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,'S95928','REG8049',6,3,NULL,'Adele','Trantow',NULL,NULL,'cebert@example.net',NULL,'$2y$10$llrRFFZzr/Fpd4kxuLLOOOQEkoBeu23v19KzkEBhY8Y9HAiuuvkmm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1997-06-08','(820) 267-4377',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,'S58584','REG5566',5,3,NULL,'Eva','Purdy',NULL,NULL,'bettie.pacocha@example.net',NULL,'$2y$10$4wcL5l/yXQWiK22mAjRwge7H52ZDwshAD3NG6yfrh2GRxatkJaS/u','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1982-03-14','+17867148480',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'S93221','REG1440',2,2,NULL,'Audrey','O\'Conner',NULL,NULL,'mazie15@example.com',NULL,'$2y$10$29LwY5j3MECmACAPKCBXU.9gf7Eoh.7XatS24dCEan4nLDqAGGbau','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1984-04-18','1-757-919-9591',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'S80060','REG1075',6,3,NULL,'Claud','Wyman',NULL,NULL,'fparker@example.net',NULL,'$2y$10$scO4fR2HkeZkL.//4z0R.uN77fT6wZv4GDUXYnH48ZxysHubalsHK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1994-06-03','+1-571-824-9603',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'S99072','REG4360',5,3,NULL,'Brooklyn','Haley',NULL,NULL,'lynch.wade@example.com',NULL,'$2y$10$YGdCkExqZ1aCWt1JEEmhPuwZo6HDmI3J9vD/JpStX2jla6UT7bIni','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1971-07-03','786-712-3679',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,'S65038','REG8225',6,3,NULL,'Leonard','Ziemann',NULL,NULL,'polly68@example.com',NULL,'$2y$10$2WUYKSimzPjnvvykCUp9AeRQKwywSQKv.BisjX8/fM1G3FmK3Z80u','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2005-04-08','1-617-819-9772',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:02','2025-04-11 12:40:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'S81833','REG5218',3,1,NULL,'Karine','Bartell',NULL,NULL,'macy.jast@example.com',NULL,'$2y$10$61wXxSWAtXDdlsc9XmuHgO6UMEE9HLnRwKtkPRclgEQlUe5wbWyjK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2019-06-14','1-801-610-8501',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,'S76246','REG3675',1,2,NULL,'Alene','Corkery',NULL,NULL,'lafayette64@example.org',NULL,'$2y$10$dFc/FPrajU2shz9gYWNrZOl23Js5EvKNioTu/eWP2w.sEQtVUYroW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2020-05-23','+1-205-869-7473',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'S09818','REG1362',3,1,NULL,'Phoebe','Mertz',NULL,NULL,'jcole@example.org',NULL,'$2y$10$p6Yl07XSPDwUyEz6j5neUeDoMahz50/MFmNMv7H1BgjvJHrgUXUBC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1988-05-29','689.316.5090',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,'S48625','REG5937',6,3,NULL,'Emilia','Collier',NULL,NULL,'xjaskolski@example.org',NULL,'$2y$10$Klvw27MWkW0HVfytZPyeaOEN5mxQT2WkVb29FD/ODjJ9hPQO9FjVS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1986-04-09','+1.650.539.0802',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,'S47325','REG6031',1,2,NULL,'Kathryn','Weimann',NULL,NULL,'adriel53@example.com',NULL,'$2y$10$Aeu0VqxdqYG/6V.Kphr7Zug7kPxq1kQeumFaZOhvq47jQJB97rCiy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2024-07-21','(256) 318-7404',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,'S80291','REG9002',4,1,NULL,'Sheldon','Armstrong',NULL,NULL,'durward61@example.com',NULL,'$2y$10$Y5tg/X9LlT0Lr0rDupIG8udTs1JbYSjcBrqocQP1gj9delymyU/Cm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1998-03-26','(631) 938-9488',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(34,'S20613','REG7023',2,2,NULL,'Bart','Funk',NULL,NULL,'robel.devan@example.com',NULL,'$2y$10$X.X4aBXAeQK9gxzgmKOsXuYlufcaNMOLjmNDMY2qv6iQD5jJxZjJS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1972-05-17','551-490-0399',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,'S58416','REG8410',1,2,NULL,'Hellen','Larkin',NULL,NULL,'abby74@example.com',NULL,'$2y$10$KZo1b3cBC7OiL2UHICn2u.F7yitBlvOYl4eu0BJfGS9rDiT81BUsK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1999-05-27','1-984-962-0931',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(36,'S24132','REG1797',2,2,NULL,'Emmy','Gutkowski',NULL,NULL,'ondricka.sydnie@example.net',NULL,'$2y$10$mTU6DGKwwOrO6l35QpcYPeUWb6ZHgCawcDrQZfPuNqdA8zY7PR.S2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1984-07-09','1-815-553-5308',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:03','2025-04-11 12:40:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,'S94141','REG7459',5,3,NULL,'Coy','Graham',NULL,NULL,'rkertzmann@example.org',NULL,'$2y$10$WZsdlcOBF0tysKwNkFGCZ.PX/6OsbBVXxC2yLOc9WdFOJan0jKQBq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2024-03-01','423.379.3017',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,'S24937','REG5635',6,3,NULL,'Tina','Connelly',NULL,NULL,'stokes.jaida@example.net',NULL,'$2y$10$vTDaKr36jUOrFLfXfYZE1uFIRTqBudrwuA6FMTYUzpLsRpZrgfU.W','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2017-01-09','+1-940-406-2976',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,'S15633','REG9545',6,3,NULL,'Eugenia','Stanton',NULL,NULL,'bergstrom.karlee@example.com',NULL,'$2y$10$3XRYHAkSGaKtAC2nJriYIOHXt3UVULX2KgW7dkONoY3C4ffz0.pLu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2014-08-26','+1-862-800-7688',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(40,'S10170','REG5818',5,3,NULL,'Estell','Ferry',NULL,NULL,'crooks.vida@example.net',NULL,'$2y$10$5x5KCga.WPzi8cK5cnQIqex33.a0q.N6y3Ly5GIjd6nmff.HRrHnS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1997-08-20','+1.929.880.2653',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(41,'S43312','REG5679',2,2,NULL,'Adolfo','Hudson',NULL,NULL,'rwehner@example.net',NULL,'$2y$10$/klvpZqRSxGlQbK354iuyuoEAN3BUmFNHaGGmaCNdO2M1LMmMwNHi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2013-05-29','845-425-1364',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(42,'S61099','REG7032',6,3,NULL,'Arlene','Stamm',NULL,NULL,'maymie.kulas@example.org',NULL,'$2y$10$OeQ62H07LqqKfVEGngPesOvmnO8IovMtN48d.jDiqlaZomUCshymG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1974-09-18','331.316.7306',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(43,'S45947','REG0583',1,2,NULL,'Leanna','Leffler',NULL,NULL,'gbarrows@example.org',NULL,'$2y$10$YFoUZA33ij9PFsqSOgfTtua7FN6eE5HjKEulcWtzagG9NwfEOyds6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1980-06-15','256-984-9510',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(44,'S33797','REG0229',1,2,NULL,'Nettie','Nolan',NULL,NULL,'brandt25@example.net',NULL,'$2y$10$4oX/YvQ.LyHOR13pDARm2OUz6rpN1Bem6bVsZWvjikk7adw8q74.y','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1982-07-09','+1 (831) 578-1604',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(45,'S91615','REG7665',6,3,NULL,'Dock','Bosco',NULL,NULL,'metz.jon@example.com',NULL,'$2y$10$5IxCgABDBhHwqq2KJ9EtmuM2Ytxk7Ti.05VsnNGJQIVdGJ8yWpex6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1994-03-13','+1.251.962.5863',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:04','2025-04-11 12:40:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(46,'S27716','REG3200',4,1,NULL,'Neha','Ondricka',NULL,NULL,'mcrona@example.net',NULL,'$2y$10$YaOY2FXLsmnVkFMC9Yaa5e5Fu74/2FBeS4YgZAnRAjv30pmKAD09a','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1981-03-31','+1-747-382-0578',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,'S94200','REG0094',5,3,NULL,'Cheyanne','Ortiz',NULL,NULL,'otto53@example.com',NULL,'$2y$10$QKdV0nO5I4S7eHEUiyrCU.C6Lb8/f8KXgnDQuj32AP1Lb6skCHHRa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2003-08-03','+1-479-461-5531',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(48,'S13957','REG2414',2,2,NULL,'Opal','Weber',NULL,NULL,'blake63@example.net',NULL,'$2y$10$wMdOCZ9f.RGvpyA8U1a73uNlq/9KPAt0aphJzydVnDTXPI2PirKPm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1997-07-12','571.347.3058',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(49,'S52439','REG0172',2,2,NULL,'Hollie','Dibbert',NULL,NULL,'xpollich@example.com',NULL,'$2y$10$.Lyh7DSIovVOzbMNhh6MC..8PDYYt/SuERnv9Z93fOZ.Jy40pnWnq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2002-03-11','+18288079127',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(50,'S53162','REG9229',1,2,NULL,'Courtney','Koss',NULL,NULL,'myah.hoppe@example.net',NULL,'$2y$10$1htbGAeixHxW4DuPy/yzjeY/JMFj4/DvFjLn0/smc062EeiMemvzm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1984-01-10','385-853-3593',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(51,'S59625','REG1295',1,2,NULL,'Toni','Walsh',NULL,NULL,'kaleb24@example.org',NULL,'$2y$10$SmdN0dWGew1zKxQjWQxXy.hpaqoVpI5ex3CtEs6pL.LHq.wQbMX7i','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1974-05-27','(580) 355-0283',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(52,'S08677','REG8683',6,3,NULL,'Flossie','Kshlerin',NULL,NULL,'scronin@example.com',NULL,'$2y$10$j1aSl50iWle/YQFKalel3uq8bbryXPbhHIRsJSov21ROU4zn5ascu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1972-10-24','+1 (352) 849-7777',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(53,'S50408','REG2483',4,1,NULL,'Abigayle','Luettgen',NULL,NULL,'ufranecki@example.org',NULL,'$2y$10$kFKlq1EXv0Id.U6aA66Yketj0iu6BDPsrHrcMFFONlkUv0rvuPOcC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1979-05-29','1-938-803-5347',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(54,'S77337','REG8050',5,3,NULL,'Elmo','O\'Reilly',NULL,NULL,'reynolds.rachelle@example.com',NULL,'$2y$10$qFXA9Cm/JnovwRuqIt9D3OqWiK0erJXvA9KmKvcDNqmuPmYZlWT3.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2022-09-15','(651) 822-6769',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(55,'S82892','REG0291',2,2,NULL,'Marjolaine','Rippin',NULL,NULL,'marcelino69@example.org',NULL,'$2y$10$ICYvcfU6/ns.Q.pi8p93sOx/IoOntws8REzInqKppqJXqTSZcbL7.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1982-10-18','(352) 225-5663',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:05','2025-04-11 12:40:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(56,'S51762','REG5082',3,1,NULL,'Cordia','Boehm',NULL,NULL,'donnelly.joelle@example.net',NULL,'$2y$10$jaJVZ9MB94TWenozsrTfYOpcj7muQYLeuUD9fRaVE/f.U6GpoDJcq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1987-01-31','458-478-2677',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(57,'S56960','REG5648',6,3,NULL,'Gerson','Bernier',NULL,NULL,'isteuber@example.org',NULL,'$2y$10$jP1acnB5y62.YEiSSY1sgOCDHQSRMHR9O.2yNhWfS9oCpGOndBiCi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2010-01-19','1-401-329-2126',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(58,'S27929','REG0554',5,3,NULL,'Lilyan','Nitzsche',NULL,NULL,'wiley25@example.net',NULL,'$2y$10$2Mlku8U4PR55fHuMSURLReQQJAwBseoPfrxgajWlfIA45PJyXvRHm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1987-09-21','929.316.4465',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(59,'S13896','REG6512',5,3,NULL,'Felipa','Pollich',NULL,NULL,'fjacobs@example.com',NULL,'$2y$10$MOyXaXT8vgkXPBBJc.7k0.Udw1O.JCtXcLtoMtlMAwirs4vWBDZ5W','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2011-01-21','+1-270-624-7318',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(60,'S96117','REG3750',4,1,NULL,'Effie','Hegmann',NULL,NULL,'lemke.nathan@example.org',NULL,'$2y$10$tDh6S8JpDbCLnWOBwFdsVuU53vNAn1XDkCtKEP8zTKOza0K7FUy0q','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1976-02-13','+1-928-614-1463',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(61,'S73652','REG1396',3,1,NULL,'Coty','Reilly',NULL,NULL,'felicita55@example.net',NULL,'$2y$10$YzEKZQoxbNkc3udI76zz5OdrvyQ42e1BCSE5XIJqKvWpgaS6dacb.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2017-02-23','210.232.2614',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(62,'S80899','REG1502',4,1,NULL,'Petra','Russel',NULL,NULL,'hilpert.pattie@example.net',NULL,'$2y$10$A./NzKwHDYetZdsv5q3tFuKqft4SCONQ8eZ4WyYufxLQeeAM3uBw2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2002-08-22','206-257-1580',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(63,'S31396','REG7094',6,3,NULL,'Manley','Hintz',NULL,NULL,'fabiola39@example.org',NULL,'$2y$10$WJV45GHgzzPqwU2zI9Gkqu7i7Ge8/ASEwp5GszIl5.BSguGNhmD4C','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2007-06-30','(775) 495-4116',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(64,'S97082','REG9538',1,2,NULL,'Tyrese','Bosco',NULL,NULL,'uriel97@example.org',NULL,'$2y$10$qA7h9wbP4/dNcWjCUMHkO.VRS9z3a.3NwoKPwT.uJzfik3aA1DVwu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2000-09-30','+1-650-432-7595',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:06','2025-04-11 12:40:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65,'S26206','REG7224',4,1,NULL,'Ellsworth','Langworth',NULL,NULL,'stehr.camila@example.com',NULL,'$2y$10$5SKQ7LDI/1E0Dav7xwpvlOIOtzn0GJm0Oz/qR1fnXLanxPUYdindm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2008-10-30','+15629511977',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(66,'S58752','REG3105',1,2,NULL,'Joana','Johnson',NULL,NULL,'westley.spinka@example.com',NULL,'$2y$10$Z0.vHZwSK.xP7QrsWQe.b.lkfC8FIZ7L1jKtURoCoNnM/ZF.J7qz6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2019-09-25','(909) 677-7376',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(67,'S58927','REG0230',4,1,NULL,'Felton','Gutkowski',NULL,NULL,'oward@example.org',NULL,'$2y$10$ad5iX0/8mOZ4uSSh3TJkYOoyCmAPpMRPk1c0SEJUx.LW.2ryPwVxC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1987-02-16','+1 (620) 409-6157',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(68,'S58855','REG0171',5,3,NULL,'Heloise','Ziemann',NULL,NULL,'thompson.crystal@example.com',NULL,'$2y$10$gnlnCymHkxggKIfvOmyO0Omx9FLCEevjEeCU7b7dUk80wejAxkW9W','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1971-08-26','(612) 957-6043',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(69,'S17987','REG5142',3,1,NULL,'Donnell','Mohr',NULL,NULL,'derek96@example.com',NULL,'$2y$10$ltyFf2aigmMIr6HnlzDzYeVsPuDn7SnYfm3xBSGaUw2NoE2.6ratS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2011-05-11','+1-914-309-0547',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(70,'S75528','REG9616',6,3,NULL,'Ahmad','Jones',NULL,NULL,'lindgren.norene@example.com',NULL,'$2y$10$ecmVQWbxNh2tRVZYJxlknebSMjHKUG8Wu/ops2/6qvk8fZRC4pRca','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1987-07-23','+1.937.448.9201',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(71,'S67494','REG2528',3,1,NULL,'Shaylee','Gaylord',NULL,NULL,'baltenwerth@example.com',NULL,'$2y$10$kyjf892j5ZU71q./sivo4eVFpUNoWZ.e.4pjVLX2G7NMV.hACuIbe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2011-07-02','1-938-759-8545',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(72,'S47365','REG9767',1,2,NULL,'Haskell','Spencer',NULL,NULL,'dillon14@example.org',NULL,'$2y$10$a/wqPnjlKC59KDgNPrav.eCPDjOOXdaVKWn.8I/ClOZw4oTC8vCsm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1987-04-03','1-401-916-4789',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(73,'S19168','REG8413',1,2,NULL,'Matteo','Pacocha',NULL,NULL,'keegan01@example.net',NULL,'$2y$10$YxKu9iS48.79iy5JKC1qHuimDhn/.DTTrziv7aiAOErkUazwb9xF2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2020-02-13','+1-347-463-5158',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:07','2025-04-11 12:40:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(74,'S63372','REG3506',2,2,NULL,'Kira','Kulas',NULL,NULL,'ava.pfannerstill@example.net',NULL,'$2y$10$eb6hboSgNt7chP7G8xBrLOWdeJHL1eD514VOccUXVhhtwCibukFAi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1972-09-24','+1-279-873-4992',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(75,'S83526','REG0849',6,3,NULL,'Tiana','Lockman',NULL,NULL,'kathryne.dubuque@example.org',NULL,'$2y$10$8Yz4hDAbLOkHzv5BJGfsheL657VXClKaYJ5Py2a.pYStudGd.IHy6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1990-03-04','(904) 701-5656',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(76,'S79321','REG1900',5,3,NULL,'Lorenza','Watsica',NULL,NULL,'nick79@example.org',NULL,'$2y$10$DC4LWxjnzTKrMh2lL2oyQ.63em885.gShQOcldQI/t.Bg420svMUq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1974-07-12','+1 (430) 647-2507',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(77,'S60613','REG8186',1,2,NULL,'Maritza','Ritchie',NULL,NULL,'xledner@example.net',NULL,'$2y$10$8nmQ2PcSbWTbEH4bXnxCxOfRS9W.2lb/T5oB0YbUt4DMXchOzj71e','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1988-02-11','+1-248-474-5854',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(78,'S09147','REG6374',2,2,NULL,'Ilene','Halvorson',NULL,NULL,'louisa53@example.net',NULL,'$2y$10$d/oGnG.Mzwt9LXVkpuk12OW0jtyS8cC868DMnWuZw.nhHqZ94sqsK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2006-07-30','347-375-1020',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(79,'S15404','REG8714',6,3,NULL,'Regan','Kuhic',NULL,NULL,'harber.lesley@example.net',NULL,'$2y$10$AaTj4npemvLuFkKISsgJjO8RqVgstWv390AtNGPilpGZ8vHWzgAru','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2008-06-07','+1-941-971-5026',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(80,'S75314','REG6325',2,2,NULL,'Osvaldo','Howell',NULL,NULL,'pcruickshank@example.net',NULL,'$2y$10$0wkFvetJIgBILo1/Ru.CAOrKIN/tPdoIXgy3QqEdNOdj7/XUbd.Hy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1992-02-02','1-330-882-7753',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(81,'S91175','REG5068',4,1,NULL,'Monte','Luettgen',NULL,NULL,'xhoeger@example.com',NULL,'$2y$10$7Ul8uSKeq.E.PcqN6MJma.GAxCxI4JvzGqQGX0fLthxiTovdsty8W','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2023-05-28','+1-623-662-1304',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(82,'S47753','REG8162',5,3,NULL,'Pietro','Christiansen',NULL,NULL,'maddison.king@example.com',NULL,'$2y$10$hiLHFBVwYk0Qh./t7zBgzeMNz/dAQLp0NzQTppttqRHw.tU0gRc5W','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1976-12-19','(941) 764-8471',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:08','2025-04-11 12:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(83,'S41180','REG3831',4,1,NULL,'Kareem','Kassulke',NULL,NULL,'rschowalter@example.org',NULL,'$2y$10$nB1cD/odcc01FZxrrDLdTeIRVCenLguNvARRU22M1Ewix7THW7YIa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1986-03-11','(562) 232-6271',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(84,'S58651','REG3779',2,2,NULL,'Laurine','Casper',NULL,NULL,'zbergstrom@example.net',NULL,'$2y$10$OWeBWmEYXaB9QyE0/EAgMOEWkSd.9.qvlZ4vkhCHnV9xmFm5po/6O','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2024-09-10','+12234826131',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(85,'S93315','REG3651',1,2,NULL,'Retha','Cronin',NULL,NULL,'ocruickshank@example.net',NULL,'$2y$10$nb5F7uNhx.S4wRQTY6MHhO6IX8Ec0W2PaHkjpOrlU9p0yvQmXqqFi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1999-10-14','1-551-706-3217',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(86,'S03426','REG9823',3,1,NULL,'Erick','Fahey',NULL,NULL,'zstroman@example.com',NULL,'$2y$10$XCMMFaLsGkWQMxrfmWuYzOgjsHv8l/AvBCqczofeZmtIZ4/9TlPXC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2005-01-03','475-303-2986',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(87,'S36266','REG7835',3,1,NULL,'Luella','Kunde',NULL,NULL,'cristian.crist@example.com',NULL,'$2y$10$PHF7ZVLlPSlH19VJ4jPBNuTEBLUq2xlbDV2IbnwN6eotRpkUp0Uc6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2006-01-21','+1.936.599.2494',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(88,'S22412','REG4445',4,1,NULL,'Isabell','Oberbrunner',NULL,NULL,'darlene.blanda@example.net',NULL,'$2y$10$7oKz0/gs3bYEqhL1t0bSU.Q07SEYhAnLha3I9sKiOwAinYQ2vQBw.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2014-03-31','364-747-4540',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(89,'S08716','REG6725',5,3,NULL,'Juliana','Durgan',NULL,NULL,'francis.botsford@example.org',NULL,'$2y$10$T.g2zijt4lY1YnIcrPLa5O6yBuUJzGqZNkQCkVpFZ3IxPdYA04xj.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1995-06-07','928-893-5686',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(90,'S92429','REG0884',5,3,NULL,'Filomena','Prosacco',NULL,NULL,'paucek.jennifer@example.org',NULL,'$2y$10$Q7IgInv5.5q8asFJ1ml41.ReXyf07TJWgnHTMem4JpCVp7MS/6XJy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2020-07-09','1-779-788-5735',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(91,'S14105','REG8501',3,1,NULL,'Marcel','Schinner',NULL,NULL,'feeney.mathilde@example.net',NULL,'$2y$10$uxzfNtFadmVNTH9bm8EtrepopCXkALNLPnejf1.czR8MFWlaic67O','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2016-01-05','814-674-7955',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(92,'S64437','REG7593',1,2,NULL,'Brooke','Heidenreich',NULL,NULL,'karson.miller@example.org',NULL,'$2y$10$/ZuzPht.rk1IdypuePp3YuEc4uCrqw1CkuticgpOaCiQfkA2i2Q.m','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1988-09-02','(650) 700-5470',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:09','2025-04-11 12:40:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(93,'S75240','REG2277',5,3,NULL,'Shaylee','Hessel',NULL,NULL,'else.schaden@example.org',NULL,'$2y$10$c.RfQY9xiu424R7j7KHo3uRh9rxW1iavgkAhw670XeSAS6XM8J1w2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2009-06-19','(423) 248-2431',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(94,'S85037','REG0542',5,3,NULL,'Coy','Stroman',NULL,NULL,'zulauf.maximo@example.org',NULL,'$2y$10$LbttNwygBKB4wegoc/ChS.IPxFevqg5H/Ss9kKhbCt09LuEsYhiSO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2008-08-19','+1.682.887.8596',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(95,'S78376','REG7320',4,1,NULL,'David','Nicolas',NULL,NULL,'claudie.witting@example.org',NULL,'$2y$10$0tMi33kGg3.kDnBrq/hFJ.SZ3enR4XXnHEeKW8C5s5ZN0y1UPjFvW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2001-03-29','1-475-366-7970',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(96,'S33519','REG1673',3,1,NULL,'Reese','Wisoky',NULL,NULL,'jacey68@example.org',NULL,'$2y$10$dR2hgPRMHyHTHbqtk8mcsO8maexFp70Rtr/muhPAoXcWSpR1dlNa6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1989-12-26','341-357-6055',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(97,'S33533','REG2656',3,1,NULL,'Darion','Hauck',NULL,NULL,'aortiz@example.net',NULL,'$2y$10$6WxK6zZ9t6mIDlIAnF/vy.SixCsqdL7ZjEjMxlBk/5PU2n01nJDGW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1971-06-14','+1 (445) 581-4879',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(98,'S05532','REG6529',2,2,NULL,'Ernie','Toy',NULL,NULL,'dejon50@example.org',NULL,'$2y$10$sBhnWTReCjtUNN4iuUvckuBunQnqSyD9kOhuvXvpvJSexVHP9hYUu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1972-11-20','440-650-8589',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(99,'S66953','REG3393',6,3,NULL,'Hardy','Kuhic',NULL,NULL,'fbogisich@example.com',NULL,'$2y$10$GCIuSGdxU3Hp./vcfjK50.x3XaQW4Z08kLYyuxbaEeaClcAMYKopW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1973-09-20','+1-952-353-7824',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(100,'S31992','REG9081',6,3,NULL,'Jabari','Ondricka',NULL,NULL,'koch.jaylon@example.org',NULL,'$2y$10$.c.jCPmS8A3YqU9iwi9VGOxAxBVaYN/6rO77v9rQEBOXPCafKtAmW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2007-01-27','+1-574-296-5022',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(101,'S59431','REG9760',6,3,NULL,'Terrell','Collier',NULL,NULL,'mante.barrett@example.net',NULL,'$2y$10$60wQv/iEc0qQvbTTgPc0.e4u071TZ9c8VdPOhG4z2IO05E6lc9UDG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2013-06-21','856.268.1184',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:10','2025-04-11 12:40:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(102,'S69610','REG4535',4,1,NULL,'Dee','Zboncak',NULL,NULL,'hessel.jairo@example.com',NULL,'$2y$10$QNylAaKKeGSrDsuVdJEnluuVG7VnBddf0krNKCG82MlcsstStkDyu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2013-05-06','743-944-6337',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(103,'S42193','REG2377',6,3,NULL,'Weston','Cormier',NULL,NULL,'marilie05@example.net',NULL,'$2y$10$PVzigfxc3G7hxXgzRnJ7l.oNYIg.p9YoS3yncHu2DCZW76l9f/c3i','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1978-05-27','1-816-308-4021',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(104,'S58369','REG2235',6,3,NULL,'Kendrick','Hyatt',NULL,NULL,'ian.hodkiewicz@example.com',NULL,'$2y$10$dFzBU1E41PKghYE1o63xzOpckoJmkW4Ro8J9zRHlDMQsIvEaDPOUe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2017-09-20','253.476.4080',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(105,'S01541','REG8108',6,3,NULL,'Aliza','Abernathy',NULL,NULL,'qroob@example.org',NULL,'$2y$10$7ffNHTULE.FmID8m0VfJNens.xE5anRBVF.jJ5dljBB0/yKlnYCmS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2008-10-18','+1-208-465-4434',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(106,'S21051','REG2678',2,2,NULL,'Alvis','Kuphal',NULL,NULL,'rutherford.neal@example.org',NULL,'$2y$10$CK3HouPzxivHXSHG3ymnw.KdqJYOYjFwQ4N4ofNN34NKPB5ELmnnC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1977-12-14','+1-662-751-4004',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(107,'S42376','REG8835',1,2,NULL,'Leopoldo','Kuvalis',NULL,NULL,'dicki.leopold@example.org',NULL,'$2y$10$zOdO6wbl3oA/jK2HyrCdv.XFcIuRgd4jgJN0dQSnVmBVyVJBMGMRG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1999-02-12','+1-650-690-5239',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(108,'S52475','REG7495',4,1,NULL,'Hester','Kulas',NULL,NULL,'vlubowitz@example.net',NULL,'$2y$10$6tV66gGxvOdkP/0LGo.vlu17yYcL8kzk/yAepzRIas2QhhFqAoJ0.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1993-10-04','470-264-4807',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(109,'S13634','REG7887',5,3,NULL,'Ole','Hoeger',NULL,NULL,'arch.cremin@example.net',NULL,'$2y$10$5J/6tkM1a1qqhqcmeDu08.laLggSvqXI25WxU1c6PZlCauVNWw4bC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2011-11-24','570-285-8872',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(110,'S54502','REG9626',6,3,NULL,'Agnes','Nader',NULL,NULL,'bprohaska@example.com',NULL,'$2y$10$P8T5bFerBXLMPlS/cUlPjuK/vAeizjzwbrGQIKnfTLh5RoCwLRNnG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1993-01-26','(406) 891-8590',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:11','2025-04-11 12:40:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(111,'S91138','REG3703',6,3,NULL,'Sallie','Okuneva',NULL,NULL,'martine08@example.com',NULL,'$2y$10$80KP.k/Fca3c2CSOJosZo.XpkDnT.g3cnYUVc2yMZ0nbEiGA1Ske2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2012-07-03','+19523686413',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(112,'S04570','REG4283',5,3,NULL,'Maria','Bayer',NULL,NULL,'serena.bosco@example.org',NULL,'$2y$10$Y8dTJIFqffoS5zuKlfw2ROGb9l3Fax4rLO.8rnOyYlWnZJiw2APtS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2004-01-24','+1-734-376-9314',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(113,'S19777','REG1987',4,1,NULL,'Georgianna','Lowe',NULL,NULL,'destini.bauch@example.net',NULL,'$2y$10$EGiqiBFNbAit1kzcq3AbtOjqu2C5QMbtRAqN9HSlndoT30x31Pb9K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2007-12-03','(678) 703-4196',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(114,'S11072','REG5822',2,2,NULL,'Andreane','Boehm',NULL,NULL,'alexzander64@example.net',NULL,'$2y$10$bhnCxwJwY5cMe2p/mu1pFevMiX2KLZc275uNJkYAoKMwPZ2hE1H6q','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2013-10-09','1-959-813-2440',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(115,'S25727','REG8433',5,3,NULL,'Yessenia','Stanton',NULL,NULL,'kihn.paxton@example.net',NULL,'$2y$10$qxPudt5jlnJ3LEzZ1yLc3eJje5fq4LZNoCo.JOW9Nt1zi09pInOHy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2000-08-12','458.299.3113',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(116,'S40587','REG5765',4,1,NULL,'Faye','Daugherty',NULL,NULL,'jkuphal@example.net',NULL,'$2y$10$c.DJ8WCQv8E1pgg4bKlv0uczHwK6GkKWj8JXd4Wk4vTUlwkPHrzeq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1977-11-14','1-254-280-3247',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(117,'S86241','REG3367',2,2,NULL,'Rylee','Dietrich',NULL,NULL,'schneider.lyla@example.com',NULL,'$2y$10$f/pIiGokyaOfvSROR7ckZeSHdTr7gow3e1jK5BBtaaR0aXU3RLaV.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1991-01-12','+18286127386',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(118,'S22173','REG2058',4,1,NULL,'Trever','Haag',NULL,NULL,'hillard.medhurst@example.org',NULL,'$2y$10$MC6x8tbnvA/CdWIsuqekVOcY3lzYltwLpcqaC0XMa6C6WavUG8M02','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2004-10-09','541-944-6405',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(119,'S54353','REG0610',2,2,NULL,'Victor','Yost',NULL,NULL,'eyost@example.com',NULL,'$2y$10$RAikKsebszxcbsmM.5zxzODqKT/hY3qu0Tb8gWFcsbbPFySqttiN2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1972-02-04','716-653-9109',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:12','2025-04-11 12:40:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(120,'S42951','REG1151',6,3,NULL,'Mervin','Towne',NULL,NULL,'marks.jovanny@example.com',NULL,'$2y$10$uifrizSzY2QT9jbyAjs8AOxML00MkoPyFxDo39B9uGiXUrhcGfC.K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2000-09-02','+13053982391',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(121,'S89098','REG1017',5,3,NULL,'Paolo','Gaylord',NULL,NULL,'breitenberg.hailie@example.net',NULL,'$2y$10$IvBBv4973sxaM2xUUC7p1OTCX2sgUFBkoi9LpTL.jp.KiZ9INIVwG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1982-05-18','1-501-360-7255',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(122,'S65279','REG8541',5,3,NULL,'Lafayette','Hickle',NULL,NULL,'murazik.asha@example.net',NULL,'$2y$10$erL2uunZi/.FL8uQRX5HaOZJEhjsi2RSUpfWanXEtQ6.vTu/yxS42','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2009-05-15','+1-408-876-0314',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(123,'S23295','REG3903',5,3,NULL,'Wayne','Frami',NULL,NULL,'lenore.bernhard@example.org',NULL,'$2y$10$vW.FeFv4wQA0y813zrXFz.njw6plhgMKHoyBmecIo/rAwRKtQ0t6K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1971-04-06','+1 (863) 377-2365',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(124,'S55757','REG7998',6,3,NULL,'Pink','Haag',NULL,NULL,'lamar67@example.com',NULL,'$2y$10$Jr6cgU9FF3Wu94CA1ZcxIeQ6og3f.2pjHSfW0Z7TZu7ioyQXTfEgW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2013-06-16','+1 (938) 298-9735',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(125,'S76005','REG2748',3,1,NULL,'Maude','Feest',NULL,NULL,'bo.upton@example.net',NULL,'$2y$10$ROxrZMFQKoAzsohAK1rbfOSr7r5Kc/LsBrtWvtprVzuvxQ3JYEmzi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2005-09-19','901-357-7373',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(126,'S71944','REG6673',6,3,NULL,'Waino','Conroy',NULL,NULL,'sporer.mossie@example.org',NULL,'$2y$10$cNGYPRdPSFThkxondbou0.Se.Ch1thh6r/DYWPvw9K3Ejyn2xpnRu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2006-04-02','+1-352-583-4948',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(127,'S94495','REG8223',5,3,NULL,'Elmore','Jaskolski',NULL,NULL,'murphy.alek@example.org',NULL,'$2y$10$qx9E2OyHZONNDkvEf8zw/uO78H41CD0OnvJel1D/88IO/80ZKA4Mq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-11-28','(669) 936-1018',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(128,'S57880','REG3673',3,1,NULL,'Domenick','Dach',NULL,NULL,'dicki.isabel@example.org',NULL,'$2y$10$KQ1eF3IhNdYU2JvqrXrj/OthyZ9dxdUYWCiCRGfry6kR40ovT6JnS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2017-12-11','218-246-5176',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(129,'S62886','REG5436',4,1,NULL,'Jerald','Weissnat',NULL,NULL,'cletus.bauch@example.com',NULL,'$2y$10$p2gbfG1leQT4kVahZvnE.OfTaneANheKRpLRBXXktVlX7e4eqpEUq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2003-03-24','+1-814-381-7791',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:13','2025-04-11 12:40:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(130,'S41552','REG6080',4,1,NULL,'Elna','Veum',NULL,NULL,'gnader@example.org',NULL,'$2y$10$2dh8oDKgIqKm62WkoqsJbexquHKkbxGzfWcXvnz8R6nns/5l66RrO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1971-02-17','434-496-5945',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(131,'S18857','REG0477',3,1,NULL,'Napoleon','Harvey',NULL,NULL,'sjaskolski@example.com',NULL,'$2y$10$cEGYdiIwV4UOfCAN8iRd9.fBLO3B6PC4NXs7x2JpS.sPYxmV8WU2G','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2010-04-04','(669) 447-0766',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(132,'S55915','REG8440',3,1,NULL,'Mitchel','Lemke',NULL,NULL,'kuhlman.ernestine@example.com',NULL,'$2y$10$1hkSswyWZtN/NNlZQL63.u0cTAMDaSk6fL8EkTs0PdRvckSID8ZJa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1980-12-06','+1-534-727-2679',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(133,'S41468','REG0233',4,1,NULL,'Jaren','Tremblay',NULL,NULL,'mrohan@example.org',NULL,'$2y$10$zFyZxBKPfihysiPlksTCN.C6Hv.RmLp/vdzdvuM4Ycb9aCA9sL5BG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1995-02-18','(513) 315-6026',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(134,'S12245','REG0391',3,1,NULL,'Mary','McKenzie',NULL,NULL,'angelica14@example.net',NULL,'$2y$10$ZhkKd9C46i8FPDRc2v.EAuyDDYtFlJahu2fFtX8jFxtX2p7F58Kzu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1999-03-23','863.740.2715',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(135,'S95525','REG4028',5,3,NULL,'Sigmund','Hill',NULL,NULL,'rkessler@example.org',NULL,'$2y$10$ljLaoFaMXVGF0IjlHJwep.bdcwn84ypzUjASHl6WIw8e1z8Hn9Miq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1985-09-24','(641) 987-7510',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(136,'S94152','REG3181',2,2,NULL,'Enid','Skiles',NULL,NULL,'ericka58@example.com',NULL,'$2y$10$adD1GUUAvLxJuaa4kadPqOtniWg4ZzhMlCZsNxAFwYw46wjOS5ZnC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2017-09-23','+1.321.988.2132',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(137,'S94374','REG4090',2,2,NULL,'Sydnie','Howe',NULL,NULL,'ayden72@example.org',NULL,'$2y$10$m61pqmSJEtdP.LgRDGPwJuT7FHio.pDZYnqgMKVyIC/TxOsrO/q5.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1975-01-29','712.447.3985',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(138,'S34320','REG5124',2,2,NULL,'Eugenia','Lind',NULL,NULL,'skyla.turcotte@example.org',NULL,'$2y$10$rshychhfH0ecBXaS5ihMDuLQ9bRd9/1uC9GQ0QuYbTbyxay5GXXKq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2008-04-03','+1-331-643-3200',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:14','2025-04-11 12:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(139,'S58449','REG4190',3,1,NULL,'Mohamed','Fritsch',NULL,NULL,'mariano.crooks@example.org',NULL,'$2y$10$Vkj9Ll.TRNs3BrUnNbiu9emcm4y01i7jXsNAoptMC7N5xbtConOi6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2012-12-13','(678) 395-2213',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(140,'S36466','REG9724',3,1,NULL,'Rene','O\'Reilly',NULL,NULL,'boyer.flossie@example.com',NULL,'$2y$10$VbR6h39HjKFx2/.DRiNFyOisidVtoQpfl4mBooKtYgHlo/umBgUPm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1983-06-04','+1 (347) 343-4150',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(141,'S10584','REG7207',4,1,NULL,'Lindsay','Prosacco',NULL,NULL,'rogahn.wendy@example.org',NULL,'$2y$10$eqdYYKtwhsp5/4JZyw/hROfbDufeNbUuzN/CtZSwyYDUgz98OrXzG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1976-08-23','+1 (929) 715-3743',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(142,'S59905','REG2110',4,1,NULL,'Lucius','Murazik',NULL,NULL,'dlebsack@example.org',NULL,'$2y$10$PN23JDHZw6rGX4yTC4YRXOMwvz2Z4Zahnan2w/n94n4LwThhdeoza','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1981-01-24','(801) 728-9154',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(143,'S82265','REG9471',6,3,NULL,'Prince','Carter',NULL,NULL,'botsford.stanton@example.net',NULL,'$2y$10$nOruadgbwESVHfJk4dW/fuFnygMl7iZlLBsfdCWmoKPTsen3bjkl2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1970-12-20','(703) 463-7509',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(144,'S84542','REG1498',4,1,NULL,'Nikolas','Ritchie',NULL,NULL,'paula27@example.net',NULL,'$2y$10$dKSvcD.0vUsk.uRE2.zSSucFfPpzZnXDyuB7.IBiPISVw20sgx19e','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2019-03-27','+1-757-626-1623',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(145,'S58318','REG0684',2,2,NULL,'Michael','Collins',NULL,NULL,'myah28@example.com',NULL,'$2y$10$s1IRn6.WHv.ObuzpCkSE8Oj06SxOglbn9zKMzWmnt.JFQ8kRVE2CC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1980-06-03','+1 (860) 265-3402',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(146,'S05089','REG4570',4,1,NULL,'Hector','Rempel',NULL,NULL,'crist.ed@example.com',NULL,'$2y$10$YoUIHYDbRz8r2ofH2ANaWO4V1chEYwgOx8AJn1fHBi0DOFSzMbGfu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1980-11-05','(947) 404-0401',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(147,'S67387','REG2908',5,3,NULL,'Roxanne','Champlin',NULL,NULL,'dcollier@example.com',NULL,'$2y$10$j/xXj9XG2lA5Dk5F1MHcAOlYp0sw8RcQ1.NE86kVHjsAFxJsdVOgW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2009-02-27','1-970-561-5401',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:15','2025-04-11 12:40:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(148,'S47450','REG3098',4,1,NULL,'Tito','Reichert',NULL,NULL,'ziemann.willis@example.org',NULL,'$2y$10$oZ7f6puU4mItzB/m3K1IJOeIQ1FgGYBBgyu1kYtoAnvLi2E776kim','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1989-07-04','1-212-696-0942',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(149,'S28217','REG2102',3,1,NULL,'Marguerite','Moore',NULL,NULL,'feest.jodie@example.org',NULL,'$2y$10$lijgvtftrPdF8VlBmrfhCewLwAI1w7Yj7Ezx9S4A4NQgEdMg3FbPK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2004-10-02','972-410-4321',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(150,'S70266','REG3954',3,1,NULL,'Devonte','Ortiz',NULL,NULL,'von.ardith@example.net',NULL,'$2y$10$b6aBxZkkNexlh4WA5vd/3uFvuTB9lbUmVpSeBaXhBPWaFQ3XovU9S','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2012-09-21','334.528.9341',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(151,'S72667','REG2857',3,1,NULL,'Hillard','Auer',NULL,NULL,'dylan34@example.com',NULL,'$2y$10$ZWrUqfh5M5mbNM3/JlD40OTyqf3gzw.HrxX7AnEM88WNRN1FJLI6O','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2016-04-06','901-852-0811',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(152,'S26343','REG6795',5,3,NULL,'Meta','Torp',NULL,NULL,'german.stehr@example.org',NULL,'$2y$10$Z.P2q5mIBbFVkqh3a4pvrurh5WcXQ7yE1PmALarfNMrFSoEsdntJm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1984-05-28','325.792.9012',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(153,'S99829','REG2608',3,1,NULL,'Hailee','Miller',NULL,NULL,'jazlyn.bayer@example.com',NULL,'$2y$10$gE9oLcbQpKS5xb9CIJK8Cual0xN3LUOVHzxDfWbwutXxDyxBXxEg6','eyJpdiI6InZPTWovUTVwSlZZRElQSWlKYThmTHc9PSIsInZhbHVlIjoiTlV4K1B1WE1GdklzcWFSQ1VCcHVhUT09IiwibWFjIjoiZDU4YjdmYjRmMTdhZjA1ZWRlYThlN2VhNTBiMGY2NjY1OWE0YzUyNWRlMWI0ZjE0YzdkM2EyZTRiN2EyZDA5NiIsInRhZyI6IiJ9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2002-10-31','980-709-2102',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,'91IcIuofdLsQ3kokW4vneGvMCNJz4Mk17jsIL453jobZHVqglD2TrfOAMPDq',NULL,NULL,'2025-04-11 12:40:16','2025-04-28 11:14:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(154,'S91215','REG7403',1,2,NULL,'Branson','Cartwright',NULL,NULL,'vstracke@example.com',NULL,'$2y$10$HUBhNoT2IDDLiCOfrBj7A..7Qe13tTL.vAplOccyRIVzwEgQ.J6ZK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1988-10-31','(234) 356-5241',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(155,'S58912','REG9675',3,1,NULL,'Lonnie','Kihn',NULL,NULL,'francisca47@example.org',NULL,'$2y$10$V0Gir2tBm7IQSfARDsfLqurKIFn/AA6A15VFNhIXX2oLIV1kU97pC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2022-02-04','+1.520.995.8791',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(156,'S19000','REG4914',2,2,NULL,'Marjolaine','Goyette',NULL,NULL,'brock.lind@example.org',NULL,'$2y$10$O6TJxuDF0nVmZKKn9galI.rboU1/SULEhU/6I9bbg6trg5BVt.tAG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1982-05-27','+16507175270',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:16','2025-04-11 12:40:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(157,'S29647','REG8407',2,2,NULL,'Estella','West',NULL,NULL,'hlemke@example.com',NULL,'$2y$10$dIIecn6lYHJNfg44vTgHJ.grBuq8ZE7h9HdKj/l7X2w6UeQEiPL1m','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2015-12-07','229-239-9679',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(158,'S33404','REG0766',1,2,NULL,'Yoshiko','Reinger',NULL,NULL,'willard01@example.com',NULL,'$2y$10$LcRmC9y1jXS6gbHcI/bCx.B1qkGL7PsDD0gaCNf9KzMkwhVZhgxxG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2023-08-16','+14848403161',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(159,'S26780','REG8034',6,3,NULL,'Jameson','Erdman',NULL,NULL,'olson.chasity@example.net',NULL,'$2y$10$vJrYlWKUvhQi0VzV/JwBH.yLd0qDU0cQuX/hARWa0.N3vz0hMfS0a','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1978-01-26','1-616-399-0497',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(160,'S25847','REG0805',6,3,NULL,'Aron','Koss',NULL,NULL,'danny75@example.net',NULL,'$2y$10$chgZpY8U1kBhthSKA86zl.Y/FSiOYusZ219YCwLxlpS6nriJc5mWG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1994-04-07','+1-320-659-3212',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(161,'S74430','REG5879',1,2,NULL,'Adelle','Reichert',NULL,NULL,'hansen.jan@example.org',NULL,'$2y$10$gbP/L1u2RIshOr0NxgvxgOoPjPQdf1vgEcSHDL6tBrr/R/EUqY80m','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1970-02-05','1-575-601-4466',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(162,'S78049','REG2757',2,2,NULL,'Beryl','Pollich',NULL,NULL,'braden57@example.net',NULL,'$2y$10$PKblYb872.OkgbIopvuzc.1L/MZ8wtaWfHBGDeQrrtNCPK3JWMIm2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1995-12-28','724-581-1105',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(163,'S29604','REG8794',6,3,NULL,'Austyn','Kshlerin',NULL,NULL,'skovacek@example.net',NULL,'$2y$10$tas8gzXpwiGxcMKzf3rcl.PeW/PEmYSGtkZ8sW7C5yKKH.0hPtgJ.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1971-07-21','1-339-905-2590',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(164,'S72287','REG3556',1,2,NULL,'Edythe','Heaney',NULL,NULL,'blake36@example.org',NULL,'$2y$10$.yup9hVaJpVGYXIpGwBBheewFV9AixkKw7Jt.wp/ZYwbgfe0j.mTS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2002-10-22','+1-986-910-2172',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(165,'S76096','REG7053',2,2,NULL,'William','Dickinson',NULL,NULL,'toy.madisen@example.net',NULL,'$2y$10$CXhqFQj3RYqWx4qHXpesVOYleo9v/B78dOVrNr9/6ooC6uyCvw7bK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1970-11-12','510.840.6235',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(166,'S38629','REG9878',1,2,NULL,'Pearl','Pacocha',NULL,NULL,'vbeier@example.org',NULL,'$2y$10$KRBG2HkYM4ETYIpbLXioIO0.QLvg5.ArJaWoCLd5w5.PT2JE25Rqe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2007-12-17','(520) 525-0992',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:17','2025-04-11 12:40:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(167,'S79585','REG0349',1,2,NULL,'Cora','Ratke',NULL,NULL,'santa29@example.net',NULL,'$2y$10$VbFbVZ4ckvP5CDaGoJiIw.98DxTL2TeUoIixkn1PGx5w7COHgozte','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1987-12-31','585.641.1668',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(168,'S32978','REG3789',6,3,NULL,'Levi','Hahn',NULL,NULL,'allen87@example.net',NULL,'$2y$10$vcBjnVydc/J9nOru5Pn7je43ESiqF6nyGjD4qlbxb..09P1aZ1QBK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1983-06-15','+1 (603) 820-9583',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(169,'S56988','REG2918',4,1,NULL,'Oleta','Powlowski',NULL,NULL,'hammes.harley@example.org',NULL,'$2y$10$JqB0pDEisIbHhCrueXiGFeg6mJdroDnU2ByfC1uvMbpRQ//UajERG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2006-05-22','(281) 979-1913',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(170,'S16255','REG0182',5,3,NULL,'Zaria','Little',NULL,NULL,'kaufderhar@example.net',NULL,'$2y$10$m4tQRwRgrijL/7.puT3j1eBwLgjUgvpOhEFS.1rCrTQgXxO8pZf1e','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2002-07-31','(907) 575-5313',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(171,'S36345','REG4067',6,3,NULL,'Jada','Borer',NULL,NULL,'kemmer.brando@example.net',NULL,'$2y$10$RvOdKACyvF5d52Y2k1.yBO9Ykyewmns6IdfNm8V763Yq6yt9jncUa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1994-05-27','1-539-532-5571',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(172,'S34123','REG7812',5,3,NULL,'Randall','Macejkovic',NULL,NULL,'hayes.otis@example.org',NULL,'$2y$10$UBPFX8IoMT2vOgYmbwhQue/YkC36ALXZ4iQD88xLT4U8D67AGwm.2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1976-09-22','+1.423.352.2908',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(173,'S30633','REG7517',2,2,NULL,'Josianne','Mante',NULL,NULL,'pwhite@example.net',NULL,'$2y$10$ywumFMe24UJXhtIEak/ULORvy7zfpw0tNyooKyD3utT7Pkf6d/Uci','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1991-02-09','+17573752964',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(174,'S43366','REG0832',5,3,NULL,'Zachary','Smith',NULL,NULL,'jhayes@example.com',NULL,'$2y$10$Csbys8ElJx5T3g6w1LAS0.gQOdBCz//kUqvvQXN/YpXIlhvTgXfUO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1992-03-11','678.230.0489',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(175,'S24936','REG9169',1,2,NULL,'Elouise','Hegmann',NULL,NULL,'kelvin78@example.com',NULL,'$2y$10$wegUoi1ei8zXiwC14JKXDOKZYJ03NUDlBLf.7AJI8k4CbrdOm4e6C','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2022-04-13','854.725.1594',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:18','2025-04-11 12:40:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(176,'S84719','REG3600',2,2,NULL,'Owen','Windler',NULL,NULL,'luettgen.orion@example.net',NULL,'$2y$10$CaO0DnAoIGNF.dXEyUfBnuVMXLfpnK8AQdk1Co9AmuCZ8L0FviiP2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2004-01-16','661-964-8783',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(177,'S52696','REG8385',1,2,NULL,'Ariane','Moore',NULL,NULL,'okuneva.aileen@example.com',NULL,'$2y$10$.ls5ozkbYRQhlGTMIwNALOuJNrx205el/dkAp1jqYzECd97H3ZrTG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1986-02-15','1-970-686-7019',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(178,'S03273','REG2178',6,3,NULL,'Joana','Wisozk',NULL,NULL,'kozey.elijah@example.net',NULL,'$2y$10$O.XFE6Tg8RNqahHeB98IMOfLpFap1c48yywBR3aUbHq6sIQWB3Q/K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2020-06-16','985-928-0537',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(179,'S56108','REG9127',3,1,NULL,'Vincenza','Waters',NULL,NULL,'cameron93@example.net',NULL,'$2y$10$YYfLAtKHYE4/suoXCPUiFOA.SsYYn2b92kebx8Cwm3Gi0NZdzqt9O','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2019-01-07','769-759-0724',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(180,'S88129','REG9788',3,1,NULL,'Gustave','Nienow',NULL,NULL,'pshields@example.net',NULL,'$2y$10$bQkKYyxm/UQ33SmpShCzieRpB3SBXv66HKK/H8NghFOa5IW73Cyhe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2024-02-25','+13606954181',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(181,'S68622','REG2980',6,3,NULL,'Oma','Beier',NULL,NULL,'rosanna04@example.com',NULL,'$2y$10$OvjTyMX04ZZGroe3kweh5uhu8KKFmd2gleFkX6Lcoqp1l2901PIAm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1991-01-28','352-673-0553',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(182,'S76529','REG7019',6,3,NULL,'Anabelle','Ernser',NULL,NULL,'arlie.vonrueden@example.com',NULL,'$2y$10$3erFbNivxUiwJW6PAgi2k.yQKvpsupewg15f6M7Op5iG/XZzJgJXC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1973-10-07','417.806.0515',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(183,'S45838','REG6928',6,3,NULL,'Kaden','Cummings',NULL,NULL,'cummings.lavinia@example.com',NULL,'$2y$10$/62s5sPXxDuruI1NkvnhmOU32fsgXUQqat2s7xq06JThbNZi71JWC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2000-02-07','831.528.8112',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(184,'S50746','REG6954',3,1,NULL,'Deanna','Prohaska',NULL,NULL,'krista57@example.com',NULL,'$2y$10$wqQlan20ZXjICJyIXPbhjOqmpQGd97GDmO83VNVKHRh3s/dFnfMPa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1977-02-06','986-768-2251',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:19','2025-04-11 12:40:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(185,'S80926','REG6830',2,2,NULL,'Lorine','Kertzmann',NULL,NULL,'mortimer.koss@example.com',NULL,'$2y$10$efTVVzCnr.Bk.106w3QKf.5oV/oH1FBJYVziMsHMZYYmapBLUIkzK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1984-10-25','702.606.2871',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(186,'S47956','REG9075',4,1,NULL,'Gabe','McClure',NULL,NULL,'schumm.claude@example.com',NULL,'$2y$10$nQUcgG/OfGDua2Ro7ffOYO7jXyt9sHakqxGtbe4KtuGzWH4mODg.2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1998-02-18','430-671-7554',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(187,'S89652','REG1054',5,3,NULL,'Santina','Lehner',NULL,NULL,'zhackett@example.org',NULL,'$2y$10$5Eis3jP5iXrs1xgZLULv9.0xDXV7jfZN440xa/3XYDPryUhWuosxi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1993-11-19','743.646.6110',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(188,'S66264','REG0663',5,3,NULL,'Monty','Wilkinson',NULL,NULL,'kristofer86@example.com',NULL,'$2y$10$SwPT6RN1qa909MrqjnQ5aO9dIPGpxsKVvZ.WHzcZyQtzkTOziiCOW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1974-06-09','1-251-546-7387',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(189,'S55921','REG7837',2,2,NULL,'Lincoln','Beahan',NULL,NULL,'zcarroll@example.com',NULL,'$2y$10$em.vHmST5KejhP0RP3Tfv.fJ3m.uwgTsPadKVbtD0X3i5umY9Thxu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2021-10-22','+1 (504) 697-7506',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(190,'S42427','REG5257',3,1,NULL,'Yasmeen','Borer',NULL,NULL,'torp.sydni@example.com',NULL,'$2y$10$BfIhqLb.11NYvAq6r09kR.UYDL66u1pckQ01.Gx3exDNgPO7AByL2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1979-03-31','+1 (424) 222-1688',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(191,'S18797','REG3847',3,1,NULL,'Reva','Sipes',NULL,NULL,'pcummerata@example.com',NULL,'$2y$10$kYL5pZjPSYbOjrD7i4bVweKYDB/6pW9/grLezlGwnRBsqMmtbztCS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2003-01-20','+1-540-844-7713',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(192,'S86956','REG5736',1,2,NULL,'Gayle','Denesik',NULL,NULL,'rosetta.breitenberg@example.org',NULL,'$2y$10$Ax/4o0LJuq4TXy4LtvgnHevzmEQ8hWIIW4Se4.qTnVIqntKRX0moq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1979-05-21','+1-904-455-8274',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(193,'S31691','REG5042',6,3,NULL,'Russell','Champlin',NULL,NULL,'ottilie.davis@example.com',NULL,'$2y$10$.kx4dYmCRHGnjN323iD0xehsziCD0dWeVswO/6MvBeLWGldPgu.vG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1984-11-23','+19547130476',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:20','2025-04-11 12:40:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(194,'S19213','REG8644',2,2,NULL,'Aleen','Mayer',NULL,NULL,'schiller.haven@example.com',NULL,'$2y$10$hnRYEcNa.Bsa7wqGroXuEOGPw99xH.2Kz28OGpOH9eTg5lZMTEe92','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1981-08-16','+1 (272) 594-3010',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(195,'S27093','REG3038',1,2,NULL,'Tressa','Zboncak',NULL,NULL,'spinka.jess@example.org',NULL,'$2y$10$HnMhV5cDyLjkdZnIL6KQM.WBm.hlUKGQtH/n7GVG2ezSeGbpg17/K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2022-06-15','1-607-777-9422',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(196,'S42036','REG3443',2,2,NULL,'Jessica','Hammes',NULL,NULL,'mervin.quigley@example.net',NULL,'$2y$10$FF4nUh8vmoirVZN8NHZfXOEzIe5U.DiHtEeWv2qeKJtiH1VVVcNr2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2020-02-19','1-680-621-9212',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(197,'S24809','REG7476',3,1,NULL,'America','Brekke',NULL,NULL,'ashton99@example.com',NULL,'$2y$10$Om/G5zDkAW.8Ju.l4wIWWu97iRHkLyIsctcdzSSt8nfyNcGyMOjDO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1989-02-22','1-225-273-4557',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(198,'S83494','REG5964',6,3,NULL,'Isaias','Hickle',NULL,NULL,'umiller@example.com',NULL,'$2y$10$bUcMhcHcyaKQupkeDeIxCuI9TAP9JFXBtPWansMj1hBCUlTRFAHqW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2000-05-30','843.992.6089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(199,'S34572','REG9339',5,3,NULL,'Bernice','Romaguera',NULL,NULL,'bernier.gabrielle@example.com',NULL,'$2y$10$2hzil8qHfse508zGeQnXzeRueGZL/DDg5ioyJJlWzMRz3AWSRO.8.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1999-03-25','(781) 865-3561',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(200,'S44563','REG7497',2,2,NULL,'Daphnee','Cremin',NULL,NULL,'teresa68@example.com',NULL,'$2y$10$NqmMl6UcBe4c8mK/C5jkC.TUhlnDr3ruQJ35CgwXeSH3wEgZ.K1M6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2018-02-17','(838) 869-9720',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(201,'S32830','REG6104',6,3,NULL,'Arthur','Monahan',NULL,NULL,'gutmann.bruce@example.net',NULL,'$2y$10$g9bi2nKy8SWxTXa5/f02qe0NPiEZGFHdS.KyMrQ9yUGLK1uqEbyvq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2017-03-02','+1-585-772-3750',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(202,'S27605','REG0745',4,1,NULL,'Anissa','Wilderman',NULL,NULL,'coby.ohara@example.net',NULL,'$2y$10$0dFfr1po5EKr6vK4MHubIevveRR381cm3Keyca7av4qXL4.lssx7K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1989-12-27','+1 (435) 825-9367',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:21','2025-04-11 12:40:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(203,'S08201','REG6896',6,3,NULL,'Christa','Swift',NULL,NULL,'effertz.dejuan@example.com',NULL,'$2y$10$bsLBnSp/uEThVxwPG0wpTOibEuacL5/dZpmOsVDyD1fdAvzv3evRm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2005-10-09','(270) 319-0637',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(204,'S79481','REG4085',1,2,NULL,'Edythe','Hane',NULL,NULL,'wyman.conroy@example.org',NULL,'$2y$10$sQ2IwHt/gJywIUxnjT1n2uew6oVWT/4yhPqBifMlYP/5pRG4108xq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1976-12-12','+1-718-958-7107',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(205,'S66184','REG3858',2,2,NULL,'Genesis','Hayes',NULL,NULL,'fhickle@example.com',NULL,'$2y$10$9MduVswAMTruunwWhCF2quGG88l2ukTi5J.ISO5t69a.QE.lku8oG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1972-04-15','209.628.0220',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(206,'S14027','REG7482',5,3,NULL,'Wilhelm','Waters',NULL,NULL,'dariana24@example.net',NULL,'$2y$10$qNIQ.SbU3dxWMvC9MCnDFeDmraa/oczUVmQu5uM8z6UVIMaaBCqU2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2019-09-23','443-834-2556',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(207,'S48952','REG1929',6,3,NULL,'Lucile','Steuber',NULL,NULL,'coy.homenick@example.net',NULL,'$2y$10$X9AKt1qkHXy1PyjDTFWsvenzOsmyU9nZeqCDXKmf0VUWpizTqf/xq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1998-05-17','+1-575-448-9042',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(208,'S08776','REG3036',5,3,NULL,'Nathanael','Block',NULL,NULL,'rachelle.price@example.net',NULL,'$2y$10$0.k9I1KhyD2dNYbSOwOh.efASKPUpc6A1.4Tn.Iycop5yKem8Sek6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1971-06-20','1-205-673-6213',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(209,'S81986','REG5754',2,2,NULL,'Margarete','Thiel',NULL,NULL,'carlos.tillman@example.org',NULL,'$2y$10$r/uwVjstIOFOF.rU5vht0eFSw51q1HNkIh4URyw.OgXGnN3214vee','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1981-07-12','845.867.2325',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(210,'S26705','REG6220',2,2,NULL,'Jodie','Brakus',NULL,NULL,'awillms@example.net',NULL,'$2y$10$FOmmnTnexmkIPKQ4Wp8hbOjq/ax2DRU.hlKkBp9kzXmVtAHre0C4i','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1982-02-20','740.889.7927',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(211,'S64530','REG6411',1,2,NULL,'Joshua','Barrows',NULL,NULL,'dallin74@example.org',NULL,'$2y$10$qIWhuJG5xERB.kzPc95hWuu2RITHfBXdJuUIWHae4z/d3e/JAkWB6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1983-05-07','209.524.5336',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:22','2025-04-11 12:40:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(212,'S39060','REG3964',6,3,NULL,'Letitia','Douglas',NULL,NULL,'kyost@example.net',NULL,'$2y$10$FQDNRiu08V1zqKdhLsGy.e.w3oGIhzoR5lZgXDvwrVRmOeRgReGt.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1977-05-02','952-922-7390',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(213,'S00618','REG6268',3,1,NULL,'Sasha','Schmitt',NULL,NULL,'clarabelle32@example.net',NULL,'$2y$10$w0E4AWyqvS7ZPZA2wH01we83jG4P6uD8y2fB6Lpyiof9UNN9qUZPe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2000-07-18','+1 (574) 299-1927',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(214,'S38409','REG7664',2,2,NULL,'Deborah','Dicki',NULL,NULL,'kiera83@example.org',NULL,'$2y$10$rNmBkOcYKSN/kpgqPDvyxe5vAWREczyYbuZMMIRmAmRotx6FftoGO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2024-03-03','+1-734-989-6445',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(215,'S34690','REG3860',2,2,NULL,'Francis','Barrows',NULL,NULL,'alvena48@example.org',NULL,'$2y$10$RcLQLq/jpKWFYAXh/3hjzOHjrSKNi8KFrXjF8WctpYsDPJEGrTPwu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1996-05-27','1-551-432-3779',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(216,'S45953','REG5444',5,3,NULL,'Edythe','Prosacco',NULL,NULL,'kerluke.herman@example.net',NULL,'$2y$10$OZyHv1YUTWDJln7V/3PsnuOAGJaX6HvBvnP4dfWFY.w51XUmjj486','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2006-09-17','+18018536547',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(217,'S07305','REG3793',2,2,NULL,'Janae','Haag',NULL,NULL,'akoelpin@example.net',NULL,'$2y$10$TjZ8K9xZqA.7Cg.daF.qUe5PALTw40mP73IAcIVDtFyoYFOG8SSI2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1971-07-03','947-576-4455',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(218,'S27788','REG2929',6,3,NULL,'Turner','Hand',NULL,NULL,'ghomenick@example.org',NULL,'$2y$10$Q/exoTQdG1L4AtE.brm9J.qjqUbuRl3VChJnkSuZ3tHS/F4XTXV8e','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2019-10-30','(458) 558-0017',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(219,'S01370','REG7243',4,1,NULL,'Al','Waelchi',NULL,NULL,'marvin.noble@example.net',NULL,'$2y$10$auzzhU6hP8e4fcBupvGIae.z8eue9byn3UWTU15Hf3og3jIyYwYwK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1998-01-04','351.428.0809',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(220,'S67108','REG6262',3,1,NULL,'Ericka','Dickens',NULL,NULL,'grant.renee@example.net',NULL,'$2y$10$it6sI/RzZKv484gGftJvLuuflFpeL3r8k8cIOBnBtJpfMqtmYJuoS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2013-10-15','413.816.6851',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:23','2025-04-11 12:40:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(221,'S69235','REG2370',5,3,NULL,'Ron','Von',NULL,NULL,'helena68@example.net',NULL,'$2y$10$vU5lnMpEP47uPEuiGahbFea2MNs8pA6MWDYGl8KLZvCZfbWnDvZai','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1995-12-04','+1-831-683-7365',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(222,'S79209','REG0756',5,3,NULL,'Trace','Paucek',NULL,NULL,'jordon60@example.com',NULL,'$2y$10$Hmfqn7u1aeUa4CU.8iR7VeOVwXEX14IVEXEML5c.XGwr5aJALT.7i','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1974-11-20','+12405311154',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(223,'S81952','REG4615',1,2,NULL,'Augustine','Koss',NULL,NULL,'eden35@example.com',NULL,'$2y$10$x8TYmb.u4yZ8k/tCQyBL8eDjUl/ZT/QxDFGMUXoynfJY01icfmMdq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1978-07-16','(563) 559-6156',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(224,'S42010','REG9464',1,2,NULL,'Carley','Gutmann',NULL,NULL,'myra69@example.org',NULL,'$2y$10$ijVtT37.6wB5CJpYnnQLUOC3EWU34sOevI4kxb8ZZ.T1dT.qeuhVW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1981-06-14','(719) 643-5306',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(225,'S42593','REG8873',4,1,NULL,'Lessie','Schamberger',NULL,NULL,'gorczany.sonya@example.org',NULL,'$2y$10$nbtzDRGyWgLTDOcMy/YTQOnJ79f6Iui45d1YntfNh5cnCuHhUgeQW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-01-23','+1-563-562-4511',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(226,'S72184','REG6285',3,1,NULL,'Linwood','Brekke',NULL,NULL,'lea79@example.net',NULL,'$2y$10$VfKeVSKxvsIYioRqDH1z7e0JzSoU8B9QpA/M6vXKawAnlkcP.WnPy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2004-05-22','1-978-623-9875',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(227,'S11286','REG7606',4,1,NULL,'Eleanore','Morissette',NULL,NULL,'marquardt.molly@example.org',NULL,'$2y$10$lvWy7SDuyxbe.Ww.zx5Bp./1yJe27C3/MT5Ja5sCFApptCA7VfTNW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1984-03-07','+1-657-717-6661',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(228,'S99761','REG7408',1,2,NULL,'Blair','Nicolas',NULL,NULL,'huels.cedrick@example.net',NULL,'$2y$10$CltwVVo7YGPQOS0CgLQrTO.Tk5jI.hHo5bAlEnOv.u3wxNhxiRewW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1991-07-28','+16232395567',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(229,'S80763','REG7354',2,2,NULL,'Bennett','Kemmer',NULL,NULL,'dstreich@example.org',NULL,'$2y$10$WrKfZljYhuvM6iIWgFVMwuMzy4kRxADajENdQSHUKroIMDOb2Z.qe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1992-05-05','810-873-8819',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(230,'S71307','REG6346',6,3,NULL,'Rafaela','Christiansen',NULL,NULL,'tlakin@example.com',NULL,'$2y$10$H4cO6CL13x9PyJbRwa8wJ.ow3dRnWZ4ISFsll/LfA61uyQ8/MfQYK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1986-12-22','+1-832-386-4560',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:24','2025-04-11 12:40:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(231,'S56832','REG5938',4,1,NULL,'Peggie','Fay',NULL,NULL,'abernathy.skylar@example.org',NULL,'$2y$10$3K9SKc1IR4XdhK.dXY4TsuMmiMQn0/ovM02HrUuZqg9cvxwCt4wrG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2023-08-23','+1.617.751.1822',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(232,'S41778','REG1259',4,1,NULL,'Dorothea','Schneider',NULL,NULL,'tkeeling@example.org',NULL,'$2y$10$FT3b8pKV4hHfGVdTGRJ9eepJSzhCJDYkhARc2cLDuK/mp9go3oEdC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1976-12-07','+1.678.572.4027',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(233,'S77395','REG0331',4,1,NULL,'Dedric','Murphy',NULL,NULL,'ynikolaus@example.com',NULL,'$2y$10$FzgEIytb6oFlPzQbBG9WPurszVRarvc1B7an5lmKsPBn.30bcwD.C','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2012-09-07','+1 (743) 456-8238',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(234,'S62470','REG7075',5,3,NULL,'Ansel','Emard',NULL,NULL,'matilde14@example.com',NULL,'$2y$10$6nzp4L/y9KDs3pPHlKzU7eR/SzYOWmsU1rz9wRg6ZBaEiLY/uhSp6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2018-10-13','539-718-2034',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(235,'S17278','REG0385',2,2,NULL,'Dolores','Pollich',NULL,NULL,'dickens.deontae@example.net',NULL,'$2y$10$Lcq.HoxT66j5W24VVLN8KuPF5fKvqIRQuhGP6wZQhmpcih8NdUwaO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2005-11-14','+1-425-614-9277',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(236,'S16143','REG3295',5,3,NULL,'Al','Kozey',NULL,NULL,'kertzmann.adrianna@example.org',NULL,'$2y$10$JzrYvgB3OANAUybUa3QWn.MRkoKsI2H/UFLb6Vm66CkHIU20NGpmS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2012-11-23','1-317-608-2717',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(237,'S16945','REG9130',5,3,NULL,'Sydnie','Kuhlman',NULL,NULL,'wjast@example.org',NULL,'$2y$10$ezuVEQQ7FBX40MjVgzEOz.GgOtLCLg1O01sXPT9doCH//v9rRl8pC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2015-02-11','+1.440.698.8749',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(238,'S62478','REG8869',3,1,NULL,'Monserrat','Roob',NULL,NULL,'dkris@example.org',NULL,'$2y$10$cHuDLoUR7o9BSZEFcdcCVu1TnI9wS6iiKL9.G2w/6LiHz2jU/MGBm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2014-03-14','410.960.3071',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(239,'S62176','REG6269',2,2,NULL,'Janiya','Mueller',NULL,NULL,'ernestine66@example.org',NULL,'$2y$10$lee9H4/55.nuKQHcsK3UGOf46vPFX8csAX7zAt8FLLNvr2GF31dxW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1975-08-18','+1-631-625-9478',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:25','2025-04-11 12:40:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(240,'S39074','REG8954',4,1,NULL,'Deonte','Olson',NULL,NULL,'meaghan85@example.com',NULL,'$2y$10$iesHRqF4ZB5s1E3kWwzLG.EQRapo/WrFH7vSv1PdeR2J.tLKZsnG6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1980-07-15','+1 (407) 450-4543',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(241,'S37772','REG8455',6,3,NULL,'Rahsaan','Mante',NULL,NULL,'mwiza@example.com',NULL,'$2y$10$GplCVDPnW2U26va2i11JDuKgAL0QE8GNesel7UMUKdPqQZ970ftvC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1996-10-27','1-281-977-0640',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(242,'S43507','REG2520',2,2,NULL,'Camren','Kirlin',NULL,NULL,'winston.beahan@example.com',NULL,'$2y$10$TeqNWtTWX95qZsFTxS4gRO6tJlTTAzeJ6HZFFs6kKNWgmNFFrbV1K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1971-07-30','+1.206.710.9745',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(243,'S53709','REG4812',2,2,NULL,'Kolby','Veum',NULL,NULL,'stefanie.volkman@example.org',NULL,'$2y$10$BKbJQ3wugcrdQVf9mL9ltuPBBumjAom.VLJkCDiYivqgUSOmlf9ji','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2002-01-31','(661) 761-5400',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(244,'S91177','REG4790',5,3,NULL,'Jamil','Nikolaus',NULL,NULL,'ondricka.keenan@example.com',NULL,'$2y$10$Wx8qlfG.s/QhaQjuwHQB7eBLJf6hpmzmkN1gpq97asValg6dAm6Sa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1996-04-16','+1-747-740-7027',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(245,'S66431','REG3480',6,3,NULL,'Eleazar','Towne',NULL,NULL,'frederic.stracke@example.com',NULL,'$2y$10$8OqEqvwdhno7LFjwVBzL4O8CA7vD2WiUX5y7qH9DgHahWr.RnBU2m','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2023-05-26','1-503-204-6425',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(246,'S14953','REG5196',5,3,NULL,'Hoyt','Runolfsson',NULL,NULL,'ibreitenberg@example.org',NULL,'$2y$10$vV6XHTLDfSl34aZo0g3kXeLveJXj87W266MISGU8JGpnHo4FNVYXG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1989-01-03','(762) 206-8332',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(247,'S86683','REG3714',3,1,NULL,'Tom','Bernier',NULL,NULL,'arielle.goldner@example.com',NULL,'$2y$10$rkzKuD.zdSDM0P.pSXy6L.m2J6UAsRRuVVZ.vO.rDXajPNloOFb36','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2012-07-02','+1 (765) 243-4441',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(248,'S95601','REG9727',3,1,NULL,'Lenna','Cartwright',NULL,NULL,'treva12@example.com',NULL,'$2y$10$SGimIqaCHnJOjyrur1ZecuqRvzwR6fts5DqspyGRiYG/C6hbRIPXC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2015-11-24','+1.754.661.6741',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:26','2025-04-11 12:40:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(249,'S87815','REG9248',1,2,NULL,'Shad','O\'Connell',NULL,NULL,'fcruickshank@example.net',NULL,'$2y$10$bd0c8uJwbLiKdho8JUii9OWjxkbQrgLDgMR7SVsr3zSEwmcqfn.Fm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2008-08-03','+1-206-846-0648',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(250,'S92030','REG4047',2,2,NULL,'Arne','Marvin',NULL,NULL,'brent43@example.net',NULL,'$2y$10$CP9TrpfPT79NB9dJbe0Ef.Lz08XWb7PXnthrUGYvYk7wFpAhnDJFq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2023-05-21','+1-386-236-3921',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(251,'S92732','REG4596',2,2,NULL,'Jaqueline','Hagenes',NULL,NULL,'jmills@example.com',NULL,'$2y$10$XsXvBiMD20fz8AN3PNRoAe56.V53a68.ceILOpUGA.hBD7huEluGK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1972-11-01','+15079259211',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(252,'S75462','REG6284',4,1,NULL,'Rollin','Gerlach',NULL,NULL,'marjory.wolf@example.com',NULL,'$2y$10$TylZeVmcRpyjlXypLYrs9.wGXOiN0ePs9tPpwMsSHa4Vlt5gYoHNW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2023-01-08','+15408915215',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(253,'S81733','REG3490',4,1,NULL,'Aaron','Haley',NULL,NULL,'paucek.christine@example.net',NULL,'$2y$10$srC2nYYb/k8zuG.Tag7n5.UR0m1.GgZudUP7b1moEkVrc2Nn2NPye','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2013-03-16','+1-281-667-4542',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(254,'S30457','REG8173',4,1,NULL,'Daniela','Buckridge',NULL,NULL,'darlene76@example.org',NULL,'$2y$10$cCQE2Rw.Gi19MXCQmEoWge75tf2Nq4j4pdKqYVcFf1YpfkC9SBEvu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1989-11-13','(854) 544-1370',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(255,'S12103','REG9815',4,1,NULL,'Charlene','Wintheiser',NULL,NULL,'cruz43@example.net',NULL,'$2y$10$i96p80uzwBvYFcFLDAEXAeiDyQqnv0H8mRw.5yES8uyNLwpKrYU1C','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1974-08-26','+1-586-482-2058',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(256,'S50160','REG6453',6,3,NULL,'Jackie','Koch',NULL,NULL,'lbarrows@example.net',NULL,'$2y$10$xCERIEGA4yDyxXAfjSU9DOzGQvl9tkPMp.78zqMzGkyaqeMJbe7.q','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2020-08-13','+1 (351) 461-6131',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(257,'S41346','REG0681',3,1,NULL,'Beverly','Anderson',NULL,NULL,'sabrina.bosco@example.com',NULL,'$2y$10$KrU6yKc1/3g2VfS5PVlOc.Tu7L52KQ557dc8Mi4xHBM05qlOwDMpy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2013-05-23','+12725887825',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:27','2025-04-11 12:40:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(258,'S69724','REG9375',5,3,NULL,'Elmira','Hickle',NULL,NULL,'fheaney@example.net',NULL,'$2y$10$mWHNXSRINTS/5KGwHxvHhOtMSNv7yUHNi4jA1AAlpljlLWBV9fiMq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2012-05-08','260.294.4957',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(259,'S68735','REG7393',2,2,NULL,'Karine','Pfannerstill',NULL,NULL,'kessler.marietta@example.org',NULL,'$2y$10$AOgCTBisx7E3KxsVM6OhwuJv6OClBIuBDO.UpC1subSDmy6URcZJm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2015-08-26','(872) 622-4773',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(260,'S44418','REG1546',4,1,NULL,'Arianna','Heller',NULL,NULL,'dalton60@example.com',NULL,'$2y$10$43ubCO2r6WI7tNwmcE7KGOCfdXlbOGGUlHQLZnvXuId4Ar7BAoM4G','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1970-04-12','725-269-1661',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(261,'S53523','REG4541',3,1,NULL,'Eldon','Breitenberg',NULL,NULL,'sporer.quinton@example.com',NULL,'$2y$10$EzsH4CxHdac16tFqY.k9qucyiTIvfiMY56d2kXoKRhiFc9B2ZfcMu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2018-03-04','361-396-1794',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(262,'S83302','REG3745',1,2,NULL,'Tess','Kuvalis',NULL,NULL,'lina89@example.org',NULL,'$2y$10$5lmiO0vOAkMnffpul6P2JOJKetdJmBUIj.vRTASSWCTRHSdxwESdm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2009-04-01','(773) 574-0742',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(263,'S40180','REG0544',3,1,NULL,'Otho','Bode',NULL,NULL,'hillary.beer@example.com',NULL,'$2y$10$O8.hELPWa8DhmrhovC9Xq.xAuv/b69Cmbk4R/Xz01L6xbASF.jRae','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2024-06-01','+1.475.377.9249',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(264,'S58229','REG3636',1,2,NULL,'Jackson','Tromp',NULL,NULL,'jovany.leuschke@example.net',NULL,'$2y$10$0Xm6BO.K8UDuSwxaxlhLn.mGZrffNM1xMSPAiD.wj8fLqG/0j6daG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1970-06-05','+1 (860) 727-7185',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(265,'S45700','REG3361',4,1,NULL,'Malvina','Ritchie',NULL,NULL,'emuller@example.com',NULL,'$2y$10$bEoAb8C2STYIwoCkZ6LP2.sAQ/FJCU1SAk5lR5n.B/ujWHcDGLQXi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1970-12-16','1-203-888-0523',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(266,'S79571','REG6172',2,2,NULL,'Viviane','Wiegand',NULL,NULL,'junior.luettgen@example.org',NULL,'$2y$10$jepoUvFgsDoduWQAY7yvW.yIdbywh/nFttlFJTNFavVgo1/Ojh3au','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1998-05-08','+1 (940) 778-4602',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(267,'S07748','REG0165',3,1,NULL,'Margot','Hoppe',NULL,NULL,'brant50@example.net',NULL,'$2y$10$4svxFqjcg0zoR23pmzcmeexPmSTGTZZPgy/neBMqw3Sj.xlM/HfZi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2003-08-29','+13857815465',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:28','2025-04-11 12:40:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(268,'S57391','REG2215',5,3,NULL,'Damaris','Emmerich',NULL,NULL,'boyer.wayne@example.net',NULL,'$2y$10$yeazG.rc5PrYwHZfLu1mZ.ekwVxd1nHzwIQdKQm4IXnVE1gnSNUmq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1999-04-07','1-859-731-1997',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(269,'S82735','REG4918',6,3,NULL,'Burnice','Schmitt',NULL,NULL,'fbechtelar@example.com',NULL,'$2y$10$ads9oCcBZ3Sji.fvGxFTJeBzdHUk7XFhgeSeL9fAIW8ZbgRWETUom','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1999-06-10','(347) 643-1053',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(270,'S31274','REG6392',5,3,NULL,'Raphael','Gaylord',NULL,NULL,'turcotte.lilian@example.org',NULL,'$2y$10$/VCHcGoFo/eGvUbgRLbU.ejNZXtpegf7uzan/sA7G2/Eeb/GH9roS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2008-04-30','+19542212877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(271,'S32194','REG8414',1,2,NULL,'Dereck','Nienow',NULL,NULL,'xrice@example.com',NULL,'$2y$10$mAtR1Zciu7oeIBje1FsRaOTiXCNhL3g0gReKnewUKC0Qq9803S/IW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2006-06-06','+1-938-479-7692',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(272,'S10870','REG5744',1,2,NULL,'Kody','Bartoletti',NULL,NULL,'heffertz@example.org',NULL,'$2y$10$ifackm0MWYSJpTtw1x1KVOBzwE8bL5PVtJSMeoRt2F0PRmzwmoCY.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1996-01-11','1-947-714-7833',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(273,'S18377','REG2747',4,1,NULL,'Anabel','Marquardt',NULL,NULL,'juliana.dooley@example.com',NULL,'$2y$10$uOzoGXLy5lcGisQuyLeDr.Ricf0SR9JjyX3SmNuzGh6xHBYnJ5iBK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1999-08-10','1-678-280-2131',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(274,'S48309','REG1792',3,1,NULL,'Breana','Walker',NULL,NULL,'cokeefe@example.org',NULL,'$2y$10$hzvA42MmqLHDGf203ECkmOyEBGQ6R8Z04CxCmCFqmIIEgLGB8bX4K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2014-10-16','585-335-0681',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(275,'S86175','REG7405',2,2,NULL,'Melba','Greenfelder',NULL,NULL,'vbradtke@example.com',NULL,'$2y$10$oAmhO5t1vB8lP8fEAm6CROZi4AyQ1DD9fkGjfx5UUf0zEPdanN1gi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1990-02-08','+1.480.741.3224',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(276,'S00428','REG3032',2,2,NULL,'Marlen','Rolfson',NULL,NULL,'bayer.sandra@example.org',NULL,'$2y$10$AYYbOkM0eWYwcc1rURP1R.pMW8Hq2L142lvFMcAZmb8vO4wgsX8wG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2015-01-24','406-961-9493',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:29','2025-04-11 12:40:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(277,'S01465','REG9947',4,1,NULL,'Dorian','Fisher',NULL,NULL,'bkoelpin@example.org',NULL,'$2y$10$aSM1DXUMsSpl/aJO4QGUl.LHA0o4/QAFs31nO.P2M37NNx.qeSpQa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1996-12-05','+1-539-793-3530',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(278,'S52260','REG6674',2,2,NULL,'Lorine','Pacocha',NULL,NULL,'fkerluke@example.net',NULL,'$2y$10$S6IsWI4npzyjiSR6IKlQd.54R0fqdwuUhfB0KeMUtR7B/Uv7FN9H2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2017-06-13','1-203-327-8771',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(279,'S61543','REG2913',4,1,NULL,'Otho','Berge',NULL,NULL,'bashirian.victoria@example.com',NULL,'$2y$10$cL14l8j2aFI.P3LbCftyFOG6ECpdNRGGxDnLNQ3pQaoCSRZ6e/rCS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1993-06-19','650-803-6506',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(280,'S07705','REG5901',6,3,NULL,'Kiera','West',NULL,NULL,'jane91@example.com',NULL,'$2y$10$L9xLQTMYNGNXC5SWWypEjuBsHBxCL124ebnC1ounKhloC2khfzena','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1996-02-29','+1 (757) 917-8849',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(281,'S75394','REG2771',5,3,NULL,'Antone','Hyatt',NULL,NULL,'blick.trudie@example.net',NULL,'$2y$10$F.4BEhm8gTIMsDcOQbthkO9XNl3Xt74s6OYOl3s001fNwsStdswdy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2001-10-25','+1-816-846-4227',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(282,'S46708','REG6388',1,2,NULL,'Van','Stokes',NULL,NULL,'geoffrey90@example.com',NULL,'$2y$10$xMcgi3g7lh/q6FFfdUX1k.w/8m8/KFmqVTVt0zqroWMBEKrV7yREq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1980-09-10','260.662.1250',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(283,'S60013','REG1666',2,2,NULL,'Maria','Spinka',NULL,NULL,'roberts.ariel@example.com',NULL,'$2y$10$203X1QaMSBbUduvB1m1ESuer.g60k3312eDgjOMe7sLyIL7C/fG/a','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1998-03-28','1-463-321-7160',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(284,'S78393','REG4581',5,3,NULL,'Eriberto','Feil',NULL,NULL,'dickens.lea@example.net',NULL,'$2y$10$bbyHadUvygLxSPZuumWBJut1r3fdM5SZWbZE8unO57Hifd43nz.Ja','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2004-02-24','+1 (660) 890-2332',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(285,'S05830','REG3111',1,2,NULL,'Golda','Adams',NULL,NULL,'shany89@example.org',NULL,'$2y$10$NDHfXjdXIjUYNNhvPuMxTO4FAQIrHqJuND71iNG9ULCCKK5jh34LS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2005-03-22','909-919-2620',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:30','2025-04-11 12:40:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(286,'S04096','REG2205',1,2,NULL,'Rita','Hills',NULL,NULL,'lreichert@example.org',NULL,'$2y$10$wyTACNl0hRmUPjjQWqOXo.0/rs8x2cxrA1cAZJqrLHAaAkrAAqrkO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1999-07-31','+1.662.638.6550',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(287,'S16782','REG0155',3,1,NULL,'Marcelo','Schamberger',NULL,NULL,'mosciski.cathy@example.com',NULL,'$2y$10$nga9PahOnERNFJwmty4BHuypaOyJYWbuThcc0u2NBgYzWCm2JNp0K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2004-10-03','336-445-3357',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(288,'S69281','REG1196',4,1,NULL,'Caitlyn','Howell',NULL,NULL,'otha33@example.org',NULL,'$2y$10$RvuczkPV.Lf3ZbdZeVwmfODeyueOekEIy7nbqMv.neSU8O79OhnXW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1997-10-27','1-380-434-5001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(289,'S00630','REG3971',5,3,NULL,'Marcella','Langworth',NULL,NULL,'avis74@example.com',NULL,'$2y$10$ZnhxIkw9EeD/OKi3wR.GYupDoDvBoyl5QtD5v8KisNF3qEYxeQP4C','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1990-03-27','347-821-1448',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(290,'S83591','REG7371',3,1,NULL,'Zora','Hackett',NULL,NULL,'marcelle47@example.net',NULL,'$2y$10$PqzWXdqewy.koPNnJOUAu.VrBhiE8ABuGHqRS2yXIBRwOw.xH21l6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1993-05-17','+13188456545',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(291,'S01118','REG3741',2,2,NULL,'Andre','Friesen',NULL,NULL,'nfahey@example.net',NULL,'$2y$10$UkpUPuwE3.iCKWpdSxK8w.BSVf4K.8Q0v4qavR6qp8J/xBIB/A83a','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1970-06-30','1-720-312-4201',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(292,'S86667','REG8146',3,1,NULL,'Mustafa','Jakubowski',NULL,NULL,'davis.jordyn@example.net',NULL,'$2y$10$.KG0ChB8GlQT6k0aHyvfAOA9ahyfISXI0IqowiWbSLJnafWs2aTHi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2001-02-23','1-934-902-5746',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(293,'S84037','REG5437',5,3,NULL,'Pinkie','Baumbach',NULL,NULL,'aliyah.mccullough@example.org',NULL,'$2y$10$OfxqIE/xFZVxLgEy/R1b5ehaNooq5Bd0ZyYjQX5uE4W9BxJigRqeq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1989-04-15','434-501-3957',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(294,'S65496','REG0177',6,3,NULL,'Melyssa','Huel',NULL,NULL,'emerson70@example.org',NULL,'$2y$10$6WsmcQWdJbi4Eu7ZaaHDZ.HDjGrooLLtCohmH6Io9ZM4VLwZShdCW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2006-12-12','743.700.8581',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:31','2025-04-11 12:40:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(295,'S94171','REG7082',4,1,NULL,'Hassan','Ondricka',NULL,NULL,'peichmann@example.org',NULL,'$2y$10$/H.MBtUC572t8xxf8m.ZCepYq2VoAmaXSRUnczROxW8dgn8LXAuWS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1999-10-17','231-768-1372',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(296,'S89189','REG8953',3,1,NULL,'Dereck','Kunze',NULL,NULL,'sarina.kessler@example.com',NULL,'$2y$10$gvJBCkTPXW4YVOmDqMnA7OeKoiaUjvi0qWyhl1MH1P6klFpu6QWiq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2004-05-19','+1 (951) 770-5772',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(297,'S43462','REG2356',2,2,NULL,'Tony','Ritchie',NULL,NULL,'everett.tillman@example.com',NULL,'$2y$10$O2cLF0xBGAQ9A6e2RrmSeeEcn/iq624VO3GTV3DkuiBtX3YhjBHXS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1983-03-20','+1.615.259.4601',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(298,'S35669','REG0464',6,3,NULL,'Helene','Trantow',NULL,NULL,'frederique94@example.org',NULL,'$2y$10$cA.nzsQhV99zGgj0q/appeS2L6YN3wnKB87i7We6hkjxouvyJi/Vq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1992-03-20','385.255.8653',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(299,'S75808','REG8051',4,1,NULL,'Alberta','Welch',NULL,NULL,'bbatz@example.com',NULL,'$2y$10$StyT/zhCL/b7ZZcmnjXmkOsypyEBliVNScv4uwp0ZITU.OON9359G','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1976-09-10','(941) 410-5367',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(300,'S98940','REG1078',6,3,NULL,'Rickie','Abshire',NULL,NULL,'tomas24@example.net',NULL,'$2y$10$xFig6m41/IQ9lF7.wS4dueAGfHQl1QMpK0vRsXtr7gmTmk28rF68S','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1976-08-22','+1 (859) 488-7811',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(301,'S94470','REG7686',5,3,NULL,'Cheyenne','Kirlin',NULL,NULL,'franz.leffler@example.org',NULL,'$2y$10$A5yaiYiPDsEXQXbwZ9kSo.TygyDqVH4kvNuZxiKuJ8VY7CZgO6y2u','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1975-01-27','865.708.5586',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(302,'S55192','REG2752',1,2,NULL,'Judge','Dickinson',NULL,NULL,'monahan.alverta@example.com',NULL,'$2y$10$zyOJqTPfTpbkwEZLMZF4J../w8Gh/6sK9rW9A.YEAG.S2U5tp1SVu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1988-04-30','+1-947-528-4396',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(303,'S81238','REG7778',5,3,NULL,'Ona','O\'Reilly',NULL,NULL,'iromaguera@example.net',NULL,'$2y$10$ygOubaTM0/ZNA0f37/FByuYo/CXR4USr2Wgll6n35E2jPE5jZBTK2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1971-10-20','(630) 717-4972',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:32','2025-04-11 12:40:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(304,'S63477','REG3054',2,2,NULL,'Uriel','Schmeler',NULL,NULL,'christiansen.citlalli@example.net',NULL,'$2y$10$seNOMqf1TeKdSe3WN9wDK.M4sTjX/qZHQTOWiyqEEvmgGb4UVi33W','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1970-05-05','+1 (332) 379-3843',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(305,'S24819','REG5067',5,3,NULL,'Lenna','McLaughlin',NULL,NULL,'humberto.gutkowski@example.net',NULL,'$2y$10$0igtJJalo2igKJ3C/P1ZP.UhLIX4ykYZa5UbslfgwhGGTSlFzbMd.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2000-06-19','323.441.8296',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(306,'S18870','REG0374',6,3,NULL,'Rodolfo','Emmerich',NULL,NULL,'elyse.rau@example.net',NULL,'$2y$10$9Zw1jVRl5z7S8PodKvKtFuxmO/ELBM3rObdxHpixXECwsRtg3nb4u','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1978-12-19','+1-820-421-8177',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(307,'S97573','REG0753',6,3,NULL,'Nicolas','Zulauf',NULL,NULL,'chanelle26@example.com',NULL,'$2y$10$rJeem4mK25D05P5Q/bk5qe8vqGpdD4KvrzvIeFltreOF2dhP/UicC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1981-03-12','+1.562.547.0187',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(308,'S36730','REG0239',2,2,NULL,'Tania','Welch',NULL,NULL,'brian35@example.org',NULL,'$2y$10$jCqr88rPpkqKqrxjcdM2JO/7EAaxOIDhT6N2YBhSNSXt.cwAWummK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2017-03-15','1-770-741-3965',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(309,'S51464','REG8699',2,2,NULL,'Travis','Tremblay',NULL,NULL,'bins.rita@example.org',NULL,'$2y$10$z41mQ05vXGztf16w4n3lbOQ7z3U6algjiUh.B413Q2DXt9nKG9SRa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2009-06-07','808.612.4984',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(310,'S14023','REG3771',5,3,NULL,'Lon','Block',NULL,NULL,'wisoky.otha@example.com',NULL,'$2y$10$3Q6Nu0.IksCI/d/OHLQudeU8mJwPVPKZgI/Lf4hQPoWtG0biWj1Me','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1980-05-19','252-956-4352',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(311,'S92475','REG8296',6,3,NULL,'Gwendolyn','Kuvalis',NULL,NULL,'hkunde@example.org',NULL,'$2y$10$ZVzO0oABO3FKK0Jt1rr4Fu3SySCKKddLypL9vklWFgnnfiorC1a4C','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1996-04-11','+1-218-755-6346',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(312,'S94252','REG8398',2,2,NULL,'Timothy','Monahan',NULL,NULL,'fhahn@example.com',NULL,'$2y$10$7Xmi9TcDVmBartPnrs5jK.0DZ1w3myvvWQMAvOodtwM2JWEG8gdlC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1970-10-11','681-885-5096',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(313,'S20033','REG3692',2,2,NULL,'Deven','Crooks',NULL,NULL,'francis71@example.com',NULL,'$2y$10$6TRGoy9GTypcNm6aZs/Bke779aLSTFxNKeFrSMTdowBoV1nx8ZU9.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1983-05-29','334.982.6603',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:33','2025-04-11 12:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(314,'S88277','REG6665',3,1,NULL,'Kelly','Goldner',NULL,NULL,'kling.cordia@example.org',NULL,'$2y$10$avjNWGyiwyi0niOd92s.ueEPb3Bw7b3q8ZBm0AcGYuYeALAdgLvtq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1986-07-01','1-937-449-4633',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(315,'S99514','REG4547',5,3,NULL,'Tobin','Johns',NULL,NULL,'harmony05@example.net',NULL,'$2y$10$WmRRCc3H2Q4Vk4vKNYar1OdsPwFlS1KOleCdbbCIEvnxXTpRkG.Su','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1971-11-17','341-503-4717',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(316,'S52822','REG6860',6,3,NULL,'Demetris','Gleason',NULL,NULL,'fkoch@example.com',NULL,'$2y$10$ZnrZe27.ABsvneDpvJbUGOS4ko5NVPeqnyma/vb7AqCQvrDdr/DF2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1991-09-22','+1-810-998-5144',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(317,'S29846','REG3805',4,1,NULL,'Josh','Kautzer',NULL,NULL,'abigail.goldner@example.org',NULL,'$2y$10$F0YaheeThWM6XnL5mFcsNuKV1Ik1G82awMrQYnHj6KATLa4GK/32i','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1997-05-04','1-906-955-0630',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(318,'S89324','REG8490',1,2,NULL,'Lenna','Auer',NULL,NULL,'norma.schroeder@example.net',NULL,'$2y$10$d0Gf9rJBSbIM3h.SRipL5O.pgi31cruwZRq5vROtjuy96E6jY.oaS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1982-05-15','+1 (281) 922-4798',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(319,'S92992','REG6003',5,3,NULL,'Solon','Hyatt',NULL,NULL,'ldickinson@example.net',NULL,'$2y$10$0YVmwT20ijjgGY/sLvUJ7OgY8BBFSZSQQdKouD1s51S7OYehBZqpG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1996-05-01','1-724-707-3863',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(320,'S07237','REG2582',6,3,NULL,'Unique','Johnston',NULL,NULL,'durgan.clarabelle@example.net',NULL,'$2y$10$Bc6qVTSLaIm/.IQkov/lZehGSdu8AJm7U6pDvuqecCfE7b0N27bSq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1992-12-29','1-631-709-2274',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(321,'S82631','REG4442',3,1,NULL,'Demetrius','Bashirian',NULL,NULL,'hmccullough@example.com',NULL,'$2y$10$O4vjBKr5Zo47zlNQI2yNnOdNmF.eWpYdtFUGXum0b1TGs9qwy/FX6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2005-12-28','(781) 523-4377',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(322,'S89373','REG8057',6,3,NULL,'Edythe','Barrows',NULL,NULL,'brionna68@example.com',NULL,'$2y$10$XIy7hiZ9R9Nexh5yo.dF/uk.YipNnhGKNy6PDy8ctdb6PGNcTaeE.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2008-10-27','+1.320.583.5649',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:34','2025-04-11 12:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(323,'S70926','REG7747',1,2,NULL,'Cassandra','Veum',NULL,NULL,'sidney.weissnat@example.org',NULL,'$2y$10$CY.wQiQOTRxUqqcPGxl5xOR.Lmkkr1dx8vIV8bDeAdDQ4Kser8JCC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2013-01-30','+13347125425',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(324,'S95060','REG7660',4,1,NULL,'Alec','Mayert',NULL,NULL,'marcella.nader@example.org',NULL,'$2y$10$b0UEpuC1eLg7yDU2Gki2N.UmGB85.0PEmKfXzjcfmusNgsocDVfA2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1984-09-06','(240) 287-1802',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(325,'S50865','REG5733',6,3,NULL,'Mark','Connelly',NULL,NULL,'hilbert.pollich@example.net',NULL,'$2y$10$x1v2Pyj8JY/4QAW6ZDWiZefziE1.CoNNwJOq3Ri17t/v.yrXTV2ey','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2018-08-12','814-495-7019',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(326,'S03536','REG1114',2,2,NULL,'Mazie','Smitham',NULL,NULL,'mason34@example.net',NULL,'$2y$10$LHx.9XQupuRYp67hjcEQg.DldjrbdeeX/VcmDkYKF/myE.uGQAotO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2001-09-25','+18207564863',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(327,'S44198','REG5961',1,2,NULL,'Trudie','Cremin',NULL,NULL,'stokes.harmon@example.org',NULL,'$2y$10$lXv2aU/ylj03mAofka.WMuOJS0Xqcl9mT7ZMF9u8880xIUiR20YbK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2011-11-15','1-620-835-9997',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(328,'S50908','REG1173',1,2,NULL,'Clementine','O\'Conner',NULL,NULL,'enola.sawayn@example.com',NULL,'$2y$10$6xdW/cI1NlYcQW6MctQz1O3Nym7fXoaS/WLOCoahWoAeVUPm/QaCO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2004-06-10','(424) 671-3879',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(329,'S02159','REG8877',2,2,NULL,'Janie','Mohr',NULL,NULL,'arianna.pagac@example.net',NULL,'$2y$10$hmC7acOYt0oDLZjf9VaIgODsTez3IRmv6CviMnCMm9l.VG0ZtYwbK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1970-12-16','586-946-9156',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(330,'S46956','REG2897',6,3,NULL,'Dorothea','Sporer',NULL,NULL,'agreenfelder@example.com',NULL,'$2y$10$Avzo/cTFv8dFQjgsnddiyeRjxOVZOGXaZe7JGZU74HAShL3P7.SDi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2005-11-09','1-619-736-8333',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(331,'S68980','REG3320',4,1,NULL,'Madisen','Boyle',NULL,NULL,'hermann.treutel@example.org',NULL,'$2y$10$hfpWy8zvDRiOb6tdReEwxOhn.xnL4sc7Snfd4pmagTsycHt0yVCiO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1997-06-26','+16627773793',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:35','2025-04-11 12:40:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(332,'S63221','REG5528',4,1,NULL,'Katlyn','Brakus',NULL,NULL,'hermann.jess@example.net',NULL,'$2y$10$bvwS30EjoQdh9Zavr9JC.uhAvsqCJOB0gJ..9i8ONvpjV9b.aJzqO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-09-22','971.796.7173',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(333,'S36352','REG0027',6,3,NULL,'Paxton','Monahan',NULL,NULL,'morar.myron@example.com',NULL,'$2y$10$B/Fk4444c3HtcOK7Pe/4JOWcSxCYRuin6FtKnkmxSvWqH7UMUmjMy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1990-08-26','623-978-4959',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(334,'S19497','REG4783',2,2,NULL,'Anya','O\'Conner',NULL,NULL,'wunsch.ross@example.net',NULL,'$2y$10$dOIQp19swoYa9kUBtuGij.AQEgU6TsgRsbLZhiAZVzEV9PF/bZUtS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1983-04-02','+1.716.813.7156',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(335,'S17733','REG2907',3,1,NULL,'Tatum','Schaefer',NULL,NULL,'chyna.gutkowski@example.org',NULL,'$2y$10$hoH1DY6tKc2REpYiJpB5numLnRnP/b/k1yxSDreOtFS5bfxU966uC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1971-06-12','1-423-637-9419',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(336,'S04135','REG9143',5,3,NULL,'Jettie','Lowe',NULL,NULL,'javier.walker@example.org',NULL,'$2y$10$saeAb1GTdrfZRwFbwq4Fr.ghE56XdO1/8Sje97bjXuP7IWBp2Qd7K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1989-10-20','+17375086074',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(337,'S87177','REG2962',4,1,NULL,'Myah','Hill',NULL,NULL,'elsie.kuhic@example.org',NULL,'$2y$10$quzVQig6joofF3TUc80YwuCUT/UJsk.HbY0I4z7qUEt2S/B3FNFeO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1983-02-03','+1 (762) 326-4265',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(338,'S91767','REG5661',3,1,NULL,'Carmel','Friesen',NULL,NULL,'ardith.reichel@example.com',NULL,'$2y$10$BpdHtRHStnpFNP165JXL1uktyIwg7ANV/3KEYaRgj3xCix6re6CFq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1985-01-16','928.963.2332',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(339,'S20435','REG3453',6,3,NULL,'Ephraim','Purdy',NULL,NULL,'axel.witting@example.org',NULL,'$2y$10$/m/ErWbyeLbFWfCrX0n96.dz4LgmdNq3FGu0ySHxP9YgxtAKPEEBu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2009-03-13','+1 (463) 673-1556',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(340,'S65609','REG3010',6,3,NULL,'Helena','Little',NULL,NULL,'tillman.henri@example.net',NULL,'$2y$10$GPb9FE2LobzvwpK.pKKI9.rzqRWlnxYsjvDYqPookhPxpK0dWsfXO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1985-10-18','1-386-373-9755',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:36','2025-04-11 12:40:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(341,'S73410','REG7874',2,2,NULL,'Branson','Bailey',NULL,NULL,'kimberly72@example.net',NULL,'$2y$10$yE1mDttIAQ0DDK9qeoyjeeZm0bMn8wlAQYFtakcr9etQhG6jc6VVu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2016-10-07','212.867.8415',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(342,'S93428','REG6727',2,2,NULL,'Brain','Runolfsdottir',NULL,NULL,'abbott.gia@example.com',NULL,'$2y$10$vqP3ocZwsQHJZjPRsqqhguaXWvUKDoyMAzxGwccOtZJZCk1F90PYm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1971-11-21','+1-207-716-6288',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(343,'S47703','REG1544',4,1,NULL,'Frank','Price',NULL,NULL,'upton.garry@example.org',NULL,'$2y$10$TGi/OAwxYXEkfo4wlehnDO/LvM4O8Rsj1wmCEchTbCwD9nEASA9M6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1996-06-21','(628) 897-3067',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(344,'S55975','REG7563',4,1,NULL,'Gayle','Carter',NULL,NULL,'mariela09@example.org',NULL,'$2y$10$BY5jSpZUpdeahr.Psguv2.nGX69/wwIhWLp5GIa2tv5MTU5IYt9V6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2001-08-06','1-234-875-4332',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(345,'S52015','REG9800',4,1,NULL,'Jan','Herzog',NULL,NULL,'heathcote.justice@example.com',NULL,'$2y$10$gMDl3YcWsbjRigfbGL1WOOlTkG10XWAiA0J9kPNywV5bQMvZUR1pa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2011-09-14','+1-971-321-0145',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(346,'S82800','REG5538',1,2,NULL,'Hollie','Swaniawski',NULL,NULL,'wnader@example.org',NULL,'$2y$10$hWWa2xLumbcUYO2usjNlL.zTTM7XYyaGvmJeIkRbQONdcowWUwxfC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2008-10-05','608.401.0447',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(347,'S68956','REG4250',2,2,NULL,'Marilie','Lowe',NULL,NULL,'vwiegand@example.com',NULL,'$2y$10$QBBeuNfNf7XVEl3fgcXcj.VXC.EZ8pDFlRFGlx41XjxMmw8trbQ8m','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1980-12-08','(857) 995-6439',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(348,'S60189','REG6487',2,2,NULL,'Jayda','Cole',NULL,NULL,'luella.hamill@example.net',NULL,'$2y$10$EP.Wdrj8E5jRwHtGzOzRweI9wnJcVEBW8iXb5CCGvz6DkQhhmklIO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2011-03-01','845-979-3394',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(349,'S35454','REG3586',4,1,NULL,'Cicero','Robel',NULL,NULL,'michele98@example.org',NULL,'$2y$10$P1gWNf2GNFiBpLjNsKdXxei2pJq.KIwKyjJwW88I/PlhGtgtswlui','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2010-12-03','205.419.7708',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(350,'S92240','REG1361',3,1,NULL,'Graham','Marquardt',NULL,NULL,'rodrick80@example.org',NULL,'$2y$10$O2e0Czc97kp5kKj2uSrb3.zWxriZvpuMdNOFmzIGHBMGU3SMf.Qt2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1991-07-05','1-832-382-6216',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:37','2025-04-11 12:40:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(351,'S44365','REG3237',5,3,NULL,'Rupert','Feeney',NULL,NULL,'abe32@example.org',NULL,'$2y$10$c9zxzSZbaRBfwFuqXgQz5uIEc2XUiy78GD.KIcE/kEgAYuN7HAPaC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1986-10-19','+1-724-415-1048',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(352,'S09838','REG7532',6,3,NULL,'Gwendolyn','Volkman',NULL,NULL,'umccullough@example.com',NULL,'$2y$10$6PL0nxE9BZ.F/HiLwBn4ROHDhXSffcLersqQ7AwxhUYu8zDLGar0S','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2017-06-26','1-757-522-9822',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(353,'S39175','REG7039',4,1,NULL,'Adam','Oberbrunner',NULL,NULL,'ullrich.richard@example.org',NULL,'$2y$10$DxL/eRO.F8D0uv8uRSvp8u8v3ACKdXEumcKOxIAmJ1h.bDEMj2dDK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1982-11-02','712.983.3331',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(354,'S80614','REG5269',4,1,NULL,'Barney','Hintz',NULL,NULL,'delfina.boyer@example.org',NULL,'$2y$10$r6z8C/c6QrZ4HgScvzeB3ufSkhJZC0ySmxXbxbwnAErYBp.DEQHgC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2019-10-31','(312) 691-9062',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(355,'S13853','REG5449',2,2,NULL,'Lizeth','Pfannerstill',NULL,NULL,'sim75@example.com',NULL,'$2y$10$zXhwb0LoH/TKCVda9SXULeeFrDzy4t2PXo1pqL.3DbfrR.1DohbDi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2012-08-04','1-843-925-7598',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(356,'S17289','REG0040',1,2,NULL,'Loy','Romaguera',NULL,NULL,'olga69@example.com',NULL,'$2y$10$YWIHO9hBxFN4Dh8lzDydN.6/3.GHrreEe4wOCYgGRd5LVD8xZ2uzG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1999-06-21','(586) 468-1152',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(357,'S71415','REG7792',2,2,NULL,'Ayla','Johnston',NULL,NULL,'vwaters@example.net',NULL,'$2y$10$H1fLz5a9/k/.CyjyDz5Qq.4iNplr/1zDMi3ZIuieqlv5l9qgnsIie','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1998-01-07','+1 (380) 835-7019',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(358,'S92777','REG3694',3,1,NULL,'Bradley','Harber',NULL,NULL,'shaun.konopelski@example.org',NULL,'$2y$10$fpVH3sl3OxBlON7XvxPyj.u.6Wr9kg.4M7rx35TF7ifV1TnTzN4EK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1982-12-02','260-965-3800',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(359,'S93451','REG6752',3,1,NULL,'Dino','Balistreri',NULL,NULL,'rgottlieb@example.org',NULL,'$2y$10$lCHYQzVOUiltPkA8CLKACety/I6r0skz9NeYb2BkupkEtCEivb6wS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2001-06-05','283.222.8020',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:38','2025-04-11 12:40:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(360,'S10179','REG4508',3,1,NULL,'Claudia','Torp',NULL,NULL,'tabitha.witting@example.net',NULL,'$2y$10$Sh1SpruR64VsjaTWdcuDXeSN07oxAa8xx0bMotn2AVKECZ4t5gNPu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2021-06-01','410.393.7355',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(361,'S40523','REG3728',3,1,NULL,'Macie','Bahringer',NULL,NULL,'mara.fahey@example.net',NULL,'$2y$10$G9j38n22CGtLt8uQ7cqpbuEg1WsjchLihESsC7gOqUHO7baLyjQHC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2013-09-08','+1-820-322-7057',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(362,'S63470','REG6707',6,3,NULL,'Brendan','Lind',NULL,NULL,'zhermiston@example.net',NULL,'$2y$10$ThGsXTbQXQtunukOELG3n.tM.wPZaKOyfMGFVEvCSAa1rX3090iSu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2011-01-30','(928) 950-3623',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(363,'S81195','REG4467',2,2,NULL,'Hardy','Kiehn',NULL,NULL,'juvenal80@example.org',NULL,'$2y$10$AGrFpdFMgsNEFcDt5FZeP.LZxW4R228hYuXKO5QDuNb1IbWIHLRyy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1999-08-15','+19075187728',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(364,'S29418','REG1353',3,1,NULL,'Forest','Roob',NULL,NULL,'nelle.schaden@example.net',NULL,'$2y$10$eZ/9wv/T4sAb8DeLqSobTeYLWzceDMHggTKBnGLjDtDsrNLKbA.Hq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2018-09-15','731-574-4505',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(365,'S35429','REG2803',4,1,NULL,'Avis','Marks',NULL,NULL,'lloyd.maggio@example.net',NULL,'$2y$10$2BZEw9kUCA32NTkznJ0u7.KZOg0Vtaxf9Sp6gY8rJyMxfhqcquc46','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1979-10-13','+1-502-900-4388',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(366,'S80539','REG2453',4,1,NULL,'August','Cruickshank',NULL,NULL,'oreilly.milford@example.org',NULL,'$2y$10$MIA8i2KHoNww7LLUc/F01ej4zwpiQIh1MwYEFaTcyvXRWUFagg9gy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2015-01-20','+1 (323) 551-5235',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(367,'S63879','REG1568',3,1,NULL,'Melody','Koepp',NULL,NULL,'hickle.maeve@example.net',NULL,'$2y$10$hWGWDyif0ynewED2W8tHS.uJwqzn9kPisTfQ3ijfNYW.X07qYCu4W','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1988-05-24','+1.865.763.9043',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(368,'S51767','REG6632',3,1,NULL,'Augustine','Volkman',NULL,NULL,'maverick.renner@example.org',NULL,'$2y$10$JdGm3pcM1VQabwOFR92DbeElKEdUx6ChvcKxriNsaYUX4V/e/JUse','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1975-09-28','551.515.4717',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:39','2025-04-11 12:40:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(369,'S67705','REG1756',5,3,NULL,'Morgan','Macejkovic',NULL,NULL,'jprohaska@example.net',NULL,'$2y$10$NbFVT8GBC47GhDSAajjWDuELOndnR5K7LmN8nLatZMqhNEiqyVfsa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1972-12-18','980.816.1692',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(370,'S37308','REG3786',6,3,NULL,'Flossie','Torp',NULL,NULL,'stephany.huels@example.com',NULL,'$2y$10$AHruSLs8OI5TkmV.tzocN.U5/ev6B85IOH17TXa/t4LZZ3hfYLwVO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1976-01-10','+1-816-468-5747',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(371,'S91341','REG5825',2,2,NULL,'Wallace','O\'Hara',NULL,NULL,'frances47@example.org',NULL,'$2y$10$2/OgwijeQkuklshzS//4d.D52prbt7w4lZP/X4TMVk7yW.GgWvtzO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2025-02-12','(928) 481-2403',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(372,'S75123','REG0714',5,3,NULL,'Addie','O\'Hara',NULL,NULL,'alexander.mraz@example.net',NULL,'$2y$10$um0mL8BQFtQOdLQ1kOkxUOopXT2kvhFx2vyMLtHQCVjFVQczLuZDm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2015-07-29','(630) 631-0043',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(373,'S63341','REG7147',1,2,NULL,'Brielle','Macejkovic',NULL,NULL,'xoconner@example.net',NULL,'$2y$10$lCLansQsJ3Eh8fUS5KoxfuhmRee0CXKTr0EgHlTke5bNumk7eqtUq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1974-03-05','346.398.3302',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(374,'S61752','REG0185',1,2,NULL,'Shyann','Williamson',NULL,NULL,'denesik.tabitha@example.net',NULL,'$2y$10$PZ6Pab.ekhBitT1HLbVjzer9w6uD0/rcWoqd2TNLwuhLSDPerDEEe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2009-08-08','1-240-855-7961',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(375,'S71586','REG1545',1,2,NULL,'Ross','Miller',NULL,NULL,'hhermiston@example.net',NULL,'$2y$10$yMQ2UbcZR7KHTfDsB3rU1Ou03GGhzlRtU17RYIaA9od/wtfrbMTLm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2018-10-27','+14056966233',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(376,'S59509','REG6945',4,1,NULL,'Sherwood','McCullough',NULL,NULL,'sheldon50@example.org',NULL,'$2y$10$Zwp5AvVscwbguP7CpB6REOCItmRNfladXqNL2YrsXeRlt9h0PtVfy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2019-02-23','+1-714-396-8093',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(377,'S45857','REG9927',3,1,NULL,'Susana','Corwin',NULL,NULL,'dustin.turner@example.com',NULL,'$2y$10$BHiu1FObkz2pF0GxY5Npx.JaFgwgrTzDgH9LsUSIBBE1rXVthTrfK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2013-03-26','+18176317150',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:40','2025-04-11 12:40:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(378,'S15887','REG6249',3,1,NULL,'Krista','Ortiz',NULL,NULL,'jbartoletti@example.org',NULL,'$2y$10$Uc1e9hciWMlcXPMrhvDrIuYV9s2.De050aUGj1IP6QKLq51.Ra1Cm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2006-06-26','1-531-564-2435',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(379,'S57671','REG7772',3,1,NULL,'Kirstin','Sporer',NULL,NULL,'schmeler.newell@example.org',NULL,'$2y$10$HpeXyUufG/l8F4sSB0NwzOHKu6ZQoF1LIaIo8phklj/1D6eyz1pyq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2014-02-04','+1-315-757-7875',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(380,'S12675','REG2427',4,1,NULL,'Ruthe','Larson',NULL,NULL,'hallie25@example.net',NULL,'$2y$10$b3ioK6lc7n4uTn.fW.YRjeuU.GEN0jRwgUcZVjWsmmpkxXAJBf0XS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2023-09-04','283-220-7280',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(381,'S56492','REG7684',5,3,NULL,'Darwin','Kris',NULL,NULL,'alberto71@example.net',NULL,'$2y$10$A/PEWtOyg2aplzEpNn5GPuX74e/LWtn0QlCnsc0hv0q/F0f1IHq6K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2011-10-26','(240) 697-5303',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(382,'S66609','REG1363',3,1,NULL,'Laurie','Muller',NULL,NULL,'nathanial66@example.net',NULL,'$2y$10$0whildSdXptSpuaEXVGDcOQMlFezOj/hLaYfoQvnbrk/0LY2b2Zyu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2021-03-25','+19207754281',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(383,'S38156','REG8669',6,3,NULL,'Marjorie','Cole',NULL,NULL,'stanley.bashirian@example.net',NULL,'$2y$10$SaZO9YMQzvD888GnMHRmJ.ur.rSPhsJA74yDz207.QNlUiZB8UJtu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2003-04-07','1-785-752-7014',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(384,'S96204','REG5030',4,1,NULL,'Jarrett','Auer',NULL,NULL,'eldon12@example.com',NULL,'$2y$10$CY0iGyubR7xlg3O2PW.bc.RLiT/nJF1BaJVvmJaznpYzpyhILbysW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1993-04-14','+1 (848) 908-0847',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(385,'S07604','REG5156',1,2,NULL,'Reuben','Blick',NULL,NULL,'ima65@example.org',NULL,'$2y$10$RYXEGij4M.XB46KJsifHZOGN4OaK4TCnertWDSrHYDIuQf3JbuUXO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1996-09-14','(484) 417-3616',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(386,'S52055','REG2380',3,1,NULL,'Davonte','Ortiz',NULL,NULL,'esenger@example.com',NULL,'$2y$10$ULotiRChm4PVSv819G7zCutxIFaDGJW0pOUKHW3E.d1blxkoPRMna','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2016-10-28','432.916.8736',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(387,'S70204','REG6808',6,3,NULL,'Ron','Bauch',NULL,NULL,'goyette.grayson@example.net',NULL,'$2y$10$HTXBgbkoN6emK33fb3NMxOTHJlytT39eiZGo9QYm./e8xfIi3u/sG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1994-06-09','252.553.4804',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:41','2025-04-11 12:40:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(388,'S42395','REG9068',1,2,NULL,'Art','Crist',NULL,NULL,'pmcglynn@example.org',NULL,'$2y$10$ZRzG9sciLENBCNwyBkf2LeTTkhrOYlAxIY9nKsvlSBIZr84vH.G6e','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1997-03-16','725-380-1780',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(389,'S71218','REG6298',2,2,NULL,'Shanel','Emard',NULL,NULL,'lenore08@example.org',NULL,'$2y$10$aSTP2mHozl.sDzfhms1kWuzEs4BYc8pEvz.t5Kvshb2lL8azwGjSu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1989-09-04','+1-586-814-4591',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(390,'S39240','REG4148',2,2,NULL,'Dock','Von',NULL,NULL,'burdette.mckenzie@example.com',NULL,'$2y$10$FdZ7ga03uJ61tpzVA7O10eXwmsaujt6HBByN8q07jqGP0tEEbua4m','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1977-05-04','+1 (518) 263-1470',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(391,'S59158','REG6404',3,1,NULL,'Sandy','Heller',NULL,NULL,'darron73@example.com',NULL,'$2y$10$Rm4L8tvQZD6s2sPxZoGGFOanVo43iu2T2oCcdx7M5S5dXin7jt6Ne','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2019-02-27','+18504583581',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(392,'S89723','REG8572',2,2,NULL,'Athena','Schamberger',NULL,NULL,'ggrady@example.org',NULL,'$2y$10$v9OYGCqV9CSIluUChg1eauhKKq/ZmW1HzQoPYO12ZIa.Ii0RNzy7S','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1999-11-24','+1.641.939.6367',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(393,'S10779','REG9906',2,2,NULL,'Noel','Rice',NULL,NULL,'genesis71@example.org',NULL,'$2y$10$RNA4bMW66bvOEbYIXRow1efmJ2/FspPqEf3449SPc/fAKcNkze5/6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1992-07-15','+12289321365',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(394,'S64934','REG9822',1,2,NULL,'Marty','Hoeger',NULL,NULL,'olga00@example.com',NULL,'$2y$10$TVwmGc6CxHSzCu27k2OBMunf6gOiI8cO7Dp4Xlpg4Ax3lJFFpiL2.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2006-07-08','+1.410.464.3022',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(395,'S34011','REG9615',4,1,NULL,'Jessica','Padberg',NULL,NULL,'alysa27@example.com',NULL,'$2y$10$WJxKGQqRqNgHjOyVIuqwV.QvV5lh2vfzENjuXnGipKTRzxTCWrDyO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2016-12-18','678.635.6950',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(396,'S88900','REG4775',5,3,NULL,'Lillian','Considine',NULL,NULL,'laurel.prosacco@example.org',NULL,'$2y$10$1NFstUz3QWXDSDE3n.dk7uGsjonB90SkpOt27dC377HBjoQ9E92eW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1970-10-16','240.334.4872',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:42','2025-04-11 12:40:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(397,'S37201','REG7184',4,1,NULL,'Elta','Feil',NULL,NULL,'imann@example.com',NULL,'$2y$10$OtZSm25gFBWarpDY6.J6HeMQf6p1KAyGx3QlxVxQYa0kN4Gj8TgS.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1975-07-12','740-932-7602',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(398,'S66470','REG0204',5,3,NULL,'Shaniya','Reichel',NULL,NULL,'keeling.sibyl@example.com',NULL,'$2y$10$14jsNCcFLQtduuw0wDUzIOtKzMyNwsUNHN7BFw/qNbDBs5F0iip1K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1997-11-17','850-274-5873',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(399,'S47204','REG4721',6,3,NULL,'Addie','Ziemann',NULL,NULL,'kale75@example.com',NULL,'$2y$10$qjnrO2cxxMwNwh9YcUlQCOin9B6HGX0XAlH2T/cWMgyyy7JOvy4Mq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1995-06-19','+1 (325) 678-3531',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(400,'S80547','REG2273',4,1,NULL,'Denis','Rutherford',NULL,NULL,'wtorphy@example.org',NULL,'$2y$10$LxoB7.8FJ/D3cnCITZBUJuGUlswh5PxT8z3ZBlGE3uDnx4ypESjSu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1998-03-11','+13232241903',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(401,'S71315','REG6271',2,2,NULL,'Baby','Ledner',NULL,NULL,'kstehr@example.com',NULL,'$2y$10$BGez1IJY0YbkxWit0VF4tuIz2XGZFhQx7llMjtUy.KQTLcNRcTm.e','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1991-04-02','+1-832-602-0508',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(402,'S53935','REG7282',6,3,NULL,'Guillermo','Predovic',NULL,NULL,'jenkins.chyna@example.org',NULL,'$2y$10$xudt8zGFapNxjbKpreEnMelAlr15cTnUOG9osuZQyAmSILF2H0Rya','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1970-10-05','475.971.9743',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(403,'S14658','REG5264',6,3,NULL,'Aniyah','Kilback',NULL,NULL,'vivianne11@example.net',NULL,'$2y$10$z5wVupCPl4ReBCP4.nuLbeX.50V1/9wIgV/GpfbTM7hNWfH8nJe5W','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2013-11-07','+1-380-221-4582',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(404,'S44108','REG3993',2,2,NULL,'Tressie','Macejkovic',NULL,NULL,'kuphal.lorine@example.org',NULL,'$2y$10$LrvZDvTaPNejf9I.YLywqu86Lh.GC4MmOhjY70Zwl8UNQTMqpZ4wK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2023-07-08','(479) 768-4811',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(405,'S46425','REG0197',5,3,NULL,'Mitchell','Weimann',NULL,NULL,'turcotte.anthony@example.net',NULL,'$2y$10$fbn86/kjaPYuMT/v4XkDJuASdPuGuT1dckyrWN1.EXs9/G43cA/Na','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1975-04-18','(475) 940-7343',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(406,'S33367','REG9931',6,3,NULL,'Thaddeus','Lubowitz',NULL,NULL,'mckenna.murazik@example.com',NULL,'$2y$10$67g1GwTlhJ62xrqSahIXkeixzLHOwNV4jkBp5k4zHll/5OBqDyNii','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1981-04-12','+1.503.516.0705',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:43','2025-04-11 12:40:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(407,'S80139','REG0145',6,3,NULL,'Vallie','Rodriguez',NULL,NULL,'bogan.erick@example.org',NULL,'$2y$10$tyXuQRVn80Q7FEfhWr1jBuC3l4R549BUjYn3dOzFefPqXaYj0HqVm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1993-09-07','(828) 637-6666',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(408,'S91858','REG6906',4,1,NULL,'Darren','Swaniawski',NULL,NULL,'pagac.wilber@example.com',NULL,'$2y$10$UNwwwvOAXWFhf9szB/vegO941rWFguoHOJ7VxpCnCXhj5zRqBaCx2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1999-07-31','1-405-557-1385',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(409,'S91562','REG1488',2,2,NULL,'Rashad','Friesen',NULL,NULL,'okuhn@example.org',NULL,'$2y$10$kQd.JciRANmL8ePrucn3tOeqGgvZOrniL2WE3q6IZ2FkcmQTXy5py','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1980-09-06','985.737.7402',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(410,'S41370','REG8351',6,3,NULL,'Devan','Berge',NULL,NULL,'ogutmann@example.com',NULL,'$2y$10$uw2NHB9JqKaMgj4U7fVlZOkcIMe5saZtoI/UeURp7NLlUw0IgB7V6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1983-04-29','+1 (757) 325-5592',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(411,'S51153','REG5932',6,3,NULL,'Isadore','Carroll',NULL,NULL,'bhegmann@example.com',NULL,'$2y$10$8qrrd1dnApK0Aeo1UCVGf./ALARvTClcPB5ODEAH0gBvPJEljFUsy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2016-04-06','+1.401.596.6920',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(412,'S12649','REG4680',6,3,NULL,'Nia','Paucek',NULL,NULL,'bosco.rafaela@example.com',NULL,'$2y$10$L5MiOjIDRCJnR5b1ZgliKuj/uZzeu9h4kBg5D3TNMUPf/r1fZQ55q','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1987-08-04','479-403-6227',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(413,'S30147','REG6777',1,2,NULL,'Delores','Hudson',NULL,NULL,'blanda.colin@example.net',NULL,'$2y$10$WASZaKtF5csp6OBR9Ov05OA..wWzDU8yzQgOXJ9hPFH2crjkwb8AG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1977-04-21','+1.765.259.2571',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(414,'S45363','REG6578',3,1,NULL,'Kara','Nitzsche',NULL,NULL,'pagac.elizabeth@example.org',NULL,'$2y$10$Gr0W/g10d.RFGn017ycVaeA6TdxKVZY5uJFXHpZ8goGbjiXn/y1/6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1970-01-10','1-754-980-7583',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(415,'S19805','REG5792',5,3,NULL,'Justus','Gerlach',NULL,NULL,'dreichel@example.net',NULL,'$2y$10$BXYCmGZ.zOSd8.qf9AFmYOOFkOKNo22KwE5N6LytvLyzHA0CYB.Uu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1984-10-21','+1-951-931-1193',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:44','2025-04-11 12:40:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(416,'S37841','REG7511',5,3,NULL,'Taryn','Von',NULL,NULL,'darron.okeefe@example.com',NULL,'$2y$10$ZzoI4BDJnwd0zzyD35B9zeo4ReyB6k/9LHbtwCeyPSVAJyEnQhbbC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1977-05-27','442.310.8593',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(417,'S95862','REG7193',6,3,NULL,'Kirstin','Considine',NULL,NULL,'fchristiansen@example.org',NULL,'$2y$10$ozwFkt7kZdePtqZ.Wo6YM.YEGDV/Ez.QHBy2gqhadS0x.7EhWMF5i','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2010-10-29','+1 (240) 316-9178',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(418,'S16942','REG0654',5,3,NULL,'Clovis','Haley',NULL,NULL,'dooley.jaunita@example.com',NULL,'$2y$10$ihH69gG3IoE4vuqm8n1kIODbNtJFoYjvPDXjSl9GU2aClDtfixwFu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1993-07-23','1-325-429-6645',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(419,'S23043','REG7383',3,1,NULL,'Ara','VonRueden',NULL,NULL,'claudia.corkery@example.com',NULL,'$2y$10$h.JJv6P4uc7/KgpgGMH4LeWVH.ERp/kgX3oq1jFeXQf7C4std4uRi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1998-04-23','386.512.6228',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(420,'S44504','REG5634',6,3,NULL,'Jeramy','Dietrich',NULL,NULL,'marge.lockman@example.com',NULL,'$2y$10$YWZzjHa5xvlQ8kLlU1A1OOiumSZJ/fP4rHDBZJjmSP3O.0J.ic31O','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1983-07-18','878.454.8668',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(421,'S76126','REG2462',5,3,NULL,'Augustus','Abbott',NULL,NULL,'aubrey.satterfield@example.com',NULL,'$2y$10$ij1DwSJUekuJ4T2qOa/hbe.uuqf5a4CLRHA/6Oi2MxOnfEs17n3bK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2007-12-07','541-315-3982',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(422,'S93380','REG8735',4,1,NULL,'Sandrine','O\'Hara',NULL,NULL,'rbeer@example.com',NULL,'$2y$10$iXNfBdtt9Wm2kBLP8p2F7OUgCRqNNwf76Bgg1mnLmrX8i/bruj19m','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2023-02-05','+1-678-584-9327',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(423,'S35594','REG1560',3,1,NULL,'Felix','Lubowitz',NULL,NULL,'atreutel@example.com',NULL,'$2y$10$6ZNe4Z./5jQtO1W7yI0seO6Ic7NFMi9orC2TCMxj3cyYokzkIb6eu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1973-06-04','901.205.9424',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(424,'S93952','REG7233',3,1,NULL,'Roberta','Stark',NULL,NULL,'aliya81@example.org',NULL,'$2y$10$HllU/zAOLOfKtkr3ExTsPOw1Khb8LkMx5R3SyvAqb/lInlSwm574.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1984-05-01','+19703366257',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:45','2025-04-11 12:40:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(425,'S56816','REG2915',1,2,NULL,'Clair','McClure',NULL,NULL,'igoodwin@example.com',NULL,'$2y$10$O90oXaemACAGJcNV7x8tmebOozTgfSdvM16nBHYgTXcEJx8Q3LX1K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2020-04-10','+17202169139',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(426,'S53612','REG3501',6,3,NULL,'Quinten','Boyer',NULL,NULL,'gleichner.major@example.org',NULL,'$2y$10$jluVstxmh3Z0HeVFcXgNSucmUbyeUeaaugwgfcLwpFsXc0TfBctx6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1976-04-05','+1 (559) 672-1709',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(427,'S73858','REG6022',6,3,NULL,'Lisandro','Stracke',NULL,NULL,'kara.kling@example.com',NULL,'$2y$10$t5CUrN0ZRWs1EaRcW5ah/e9SmgNyMYM7bgzMGwPyBw2XAXQnog7hK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1980-09-04','+1-781-433-5035',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(428,'S84444','REG1805',5,3,NULL,'Alvina','McKenzie',NULL,NULL,'milo52@example.com',NULL,'$2y$10$Xe1KuxKjDVbyexHmx/fbue2L7Y63L0G08rIHIh8MLV.ipIZ2dvC5.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1993-05-09','321.825.3557',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(429,'S21024','REG9424',2,2,NULL,'Ryder','Graham',NULL,NULL,'gibson.zaria@example.com',NULL,'$2y$10$6XsKUO/izDcdzqQnS5B4kuca.TWmVF5Lz70cGJvwdeqj0eBsXuhvi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1996-11-09','(304) 614-5787',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(430,'S88361','REG7185',2,2,NULL,'Marques','Cronin',NULL,NULL,'faustino52@example.org',NULL,'$2y$10$LpbNgLXVyp8/VzVJfkwa4e/iHeASky28L/VsBTI2BNOhivPddxmt.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1973-08-01','1-585-399-4272',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(431,'S54255','REG9948',5,3,NULL,'Liam','Goodwin',NULL,NULL,'itzel07@example.org',NULL,'$2y$10$2uKj4xcLY5ZlXuvWhf0IxuObUTzP5fN61B3MQLmDiAj8C2C.4Vy8u','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1992-06-16','214.400.5992',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(432,'S86895','REG5734',2,2,NULL,'Lera','Kohler',NULL,NULL,'nklocko@example.net',NULL,'$2y$10$lA.Cfn/bwKv8i3HgcwnbY.dzMwUp4DNW0ZKa/Q7hUC646vyLTLriq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1986-03-02','+1-931-667-5898',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(433,'S89634','REG0798',1,2,NULL,'Arturo','Kling',NULL,NULL,'thickle@example.com',NULL,'$2y$10$.gwSCDQRG6si6zcWqSua1OoTA3jTsAEBHovnoUPV8ILv5BktdjcuK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1986-09-18','380.941.9970',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:46','2025-04-11 12:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(434,'S67402','REG6894',5,3,NULL,'Isabel','Ratke',NULL,NULL,'runolfsdottir.major@example.org',NULL,'$2y$10$y3B8rtvyMDpKPGomX0op8egMlzziOlzqPpusaE2b9bWq938zDpnw.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1982-07-15','+1 (534) 253-8018',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(435,'S35653','REG3701',2,2,NULL,'Dudley','Adams',NULL,NULL,'brown.waelchi@example.com',NULL,'$2y$10$BiZJcSaVteAyWSRfyhlYD.5EKb4TSerodGDxfy4VtLk46NH47mxkW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2023-10-05','(458) 757-2503',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(436,'S89716','REG7212',3,1,NULL,'Davonte','Weber',NULL,NULL,'nicolette.kuvalis@example.org',NULL,'$2y$10$SplNwUfkTtFw9LpDvRCQ8.o3Tp0LW5gzXLCX1vSd/46d0Y54jMNEe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1979-07-08','+1 (859) 572-0613',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(437,'S65372','REG2596',6,3,NULL,'Damian','Gutkowski',NULL,NULL,'pfannerstill.syble@example.org',NULL,'$2y$10$3Nn6iI0XRlkytAMoZFpoWeDpUmYcWxGecJl4h9iE.AAkM28jaA6Tq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2018-08-05','+1.878.623.6426',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(438,'S36983','REG5849',6,3,NULL,'Grant','Kertzmann',NULL,NULL,'fletcher32@example.org',NULL,'$2y$10$965kqqRPVku3dir2RrfH2eTUqQZ0IWQmbeuWVUqdsfDixwcMG/Fy.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2012-11-12','(484) 242-3472',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(439,'S15009','REG8647',2,2,NULL,'Ismael','Wiza',NULL,NULL,'dewitt.herzog@example.net',NULL,'$2y$10$cnD6dOPMyDAs7ScgPqpJEOnVUSMFM8bnJ0gwCHYyOIl3qvB661UKy','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1997-02-23','1-571-341-2106',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(440,'S26046','REG6492',5,3,NULL,'Cassidy','Gulgowski',NULL,NULL,'winifred87@example.net',NULL,'$2y$10$cOvxnnH/GbkUR.xUf3GppeRPIjkYmTrn2076ceKT7ZyolkhFBCM.e','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1972-04-04','(385) 359-3401',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(441,'S82470','REG9072',5,3,NULL,'Maymie','Effertz',NULL,NULL,'rachael.bartell@example.com',NULL,'$2y$10$AnDa0gLHjQ.01yf5kmx.2OvOkaPfBM./l0nUWTAVmiZngcuznNNAC','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1980-05-27','640-826-4565',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(442,'S11305','REG0760',4,1,NULL,'Nellie','Terry',NULL,NULL,'rdouglas@example.net',NULL,'$2y$10$sOm57tBwQCUCs53PE5iHXOrSrEYrXHgCQqzGdC0QerWSN8HvLABy.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1985-04-09','(808) 890-8349',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:47','2025-04-11 12:40:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(443,'S46247','REG2972',1,2,NULL,'Josie','Huels',NULL,NULL,'treutel.sandy@example.com',NULL,'$2y$10$tRqhIpItssPb3F.hkl7GE.KUTmVeQavb9TfbJQwqXBGGnxxiLniP.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2000-09-05','+1.432.774.6584',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(444,'S40802','REG4472',3,1,NULL,'Claude','Schulist',NULL,NULL,'hubert.barton@example.net',NULL,'$2y$10$Q8fIK3dMBh8oY0clWdq/Ou7WdxUYA5h4y3y.DJyPYB4PgxSiclQFi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1997-09-24','+1-541-274-3577',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(445,'S15566','REG4662',6,3,NULL,'Domingo','Treutel',NULL,NULL,'zboyer@example.com',NULL,'$2y$10$jC.P5Vqj2ioUEnMESA2MH.NXncxYRMwFtTz8tlD.HN4pCHDw5b.3m','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2021-02-23','727-658-2101',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(446,'S66770','REG8224',3,1,NULL,'Tristian','Herman',NULL,NULL,'becker.glenna@example.com',NULL,'$2y$10$4CAeXdZZbn5czWI3Qc.AbO0WiP71/3H2eCBfmRn8Tno/z9eCUDrYu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2015-11-13','+1-805-489-6465',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(447,'S26847','REG5240',6,3,NULL,'Myrl','Collier',NULL,NULL,'llewellyn30@example.net',NULL,'$2y$10$MTfpL30IkZFcNBQHKyWVkuxqrKioo26n1araC.qIEK2BOQoxOn8PG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2023-04-12','+1-601-788-5491',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(448,'S88539','REG6641',5,3,NULL,'Rosamond','Cremin',NULL,NULL,'jamison.sauer@example.org',NULL,'$2y$10$x20CjTgV8MahGGuYGB1DyeEA9Z5.HEpYe8kgd4SpgP.PFhQBeOcu.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1971-04-28','+1.660.421.7057',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(449,'S54195','REG1834',5,3,NULL,'Susan','Koch',NULL,NULL,'nolan.kassandra@example.com',NULL,'$2y$10$KiIz84C0iZd3ja3rteJIRuZ3n/SEpM1ItB.hAoHJvzrBxfAxSsyea','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1982-07-23','+1 (810) 350-7588',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(450,'S32816','REG3063',4,1,NULL,'Valentina','Kertzmann',NULL,NULL,'armstrong.kaia@example.net',NULL,'$2y$10$shWtngtuMrflZUkp6kVOLeAWIgljrc0soZt8iS5TpjFDvqL.JnPa2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1972-08-02','+1.937.374.6154',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(451,'S61217','REG8639',4,1,NULL,'Dandre','Huels',NULL,NULL,'emerson92@example.com',NULL,'$2y$10$OPOOb/v8tZhY/hMuNshQa.MbVhMo.jqSdRLovvihzWQyijCyY43AK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1997-07-22','+16784635698',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(452,'S31727','REG1972',6,3,NULL,'Bessie','Ankunding',NULL,NULL,'corwin.raymundo@example.net',NULL,'$2y$10$OgrltiwvYMadVzStqgh1G.kbTiT7zYlzumNkpCEia0X.u2./BniKu','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1997-06-05','1-513-964-7755',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:48','2025-04-11 12:40:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(453,'S79924','REG0282',4,1,NULL,'Janiya','Ritchie',NULL,NULL,'yasmine.block@example.net',NULL,'$2y$10$cJa9bYMV4.pxN5itSrFPsu2dnGANvJ9vVINlcjbCV0sPKMW6X7/6S','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2012-07-08','(681) 701-9748',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(454,'S57470','REG4498',2,2,NULL,'Reymundo','Stracke',NULL,NULL,'kautzer.kolby@example.com',NULL,'$2y$10$yvPTwYeaP5a6ikkRc6IEpe1eqsNdkNdTq1WNBUuHoqZfNZYK4xdzm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1992-11-02','+1 (770) 476-7691',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(455,'S17965','REG5171',1,2,NULL,'Queenie','Considine',NULL,NULL,'ztowne@example.net',NULL,'$2y$10$rVKM7lJFNAo7AkbHkvEiwu9P3l./NZXUbhyThjM4YqnaNJO1UCcVe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2005-07-12','+1-978-935-8363',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(456,'S73466','REG9587',4,1,NULL,'Lamont','Weissnat',NULL,NULL,'satterfield.joelle@example.org',NULL,'$2y$10$MuFP4yich1ZLEgs29DK3DeBMiBRIj7i09YlpuvEJxOqU9u.FpmK/6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1982-09-27','1-941-934-2422',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(457,'S51790','REG1737',1,2,NULL,'Erica','Balistreri',NULL,NULL,'davis.alphonso@example.org',NULL,'$2y$10$XfERWvGtFyN/il2TP7r4duh4FkZhH6f5j49Sn4U5DIw4HjRfptgK6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1984-07-08','740.295.3977',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(458,'S69257','REG6205',2,2,NULL,'Lucius','Hoppe',NULL,NULL,'kaitlyn.kris@example.net',NULL,'$2y$10$oU8WpoyxZYmiyRvRc9eTKuIc4Ppzz41INqUMXRdats4bs66A6fgJW','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2000-05-07','1-351-817-6085',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(459,'S87246','REG1166',3,1,NULL,'Blanca','Bode',NULL,NULL,'fkilback@example.net',NULL,'$2y$10$XpA5gckgTyZxpB9.GKQrI.W.FPXf/4J4fCJ5C3LJh1mf4RbizVgva','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2013-10-31','+1-530-271-1597',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(460,'S17659','REG6590',5,3,NULL,'Alphonso','Bartell',NULL,NULL,'hdurgan@example.com',NULL,'$2y$10$gIji0vqjVXZYkSGlI26XceL0hPeBHHwf1Yvvd.ZvlFLAzKwGpFHAG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1995-11-24','+16808604882',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:49','2025-04-11 12:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(461,'S84818','REG0810',4,1,NULL,'Sally','Kozey',NULL,NULL,'eliseo31@example.org',NULL,'$2y$10$LpHQ19d6aC.B90hbyiPGYOKTDSY4vdvaZaXXuhXYC7PqqJ9ZJfUby','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2002-05-04','+1.760.250.4747',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(462,'S83902','REG4882',2,2,NULL,'Connie','Macejkovic',NULL,NULL,'hudson.maryam@example.com',NULL,'$2y$10$g6rTXIAF9q0erP.b4r2gVO5nDolbsFwn87YcDmw80ssYqCrkLa50a','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2022-08-21','302-333-1029',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(463,'S09836','REG1923',2,2,NULL,'Jerrold','Fahey',NULL,NULL,'marshall29@example.org',NULL,'$2y$10$msRKDEsm7Pom.WJnHxHmvO5alm5ruLolsHqGuteTzw1BfmQdEqqgm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1996-09-24','1-940-963-3726',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(464,'S96294','REG5166',4,1,NULL,'Stanford','Greenfelder',NULL,NULL,'mshields@example.com',NULL,'$2y$10$oxQ1gfL13sXoDCEcgsbom.BE/aI3fVbGzyTO2YmjPq8g2wpA0EY/y','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2006-03-19','1-520-769-4458',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(465,'S14002','REG4394',2,2,NULL,'Francesca','Fritsch',NULL,NULL,'kirlin.orpha@example.org',NULL,'$2y$10$1g37WYYGffVrwAQFWpOIAu1leLNl9WncvdbHYCdUdUThTH07nwu4q','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1975-08-19','+1-312-876-9128',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(466,'S80944','REG6407',3,1,NULL,'Fausto','Brakus',NULL,NULL,'hermann.hannah@example.com',NULL,'$2y$10$90UAPSWzea6XckhdtmgYg./pjM15YRQg.RddVNQWwd/xSnXmE12tq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2015-05-01','606-593-6013',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(467,'S99713','REG5819',3,1,NULL,'Myra','Emmerich',NULL,NULL,'damore.connor@example.net',NULL,'$2y$10$Jn4LCuyi0KzniN0/u.Qd9ejKPSpGqPIU2uF412vwlI5dvepaDPVGe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2013-04-16','1-815-288-8509',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(468,'S79223','REG6455',1,2,NULL,'Nathen','Oberbrunner',NULL,NULL,'chase53@example.net',NULL,'$2y$10$tChJcWXv20hETga5MvPQyePeB0rN0kpodvgEW50NeFlHFBLsh7MSa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1976-11-16','+1-669-433-9664',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(469,'S11567','REG1856',1,2,NULL,'Veronica','Buckridge',NULL,NULL,'ugibson@example.net',NULL,'$2y$10$5/Sy5BjJ5BKZQRk3WnRYb.MMgbgHJxwc4S6whzAaijANMXio224Si','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1991-11-20','(941) 729-6042',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:50','2025-04-11 12:40:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(470,'S32136','REG3413',5,3,NULL,'Ariane','O\'Keefe',NULL,NULL,'geoffrey.sawayn@example.net',NULL,'$2y$10$WulF5ssWB5HEcYRRcvuFSOO/xSV.VZp2XUiMmQi3hQv5L1HGARsCS','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2008-04-15','+1 (920) 667-6548',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(471,'S06193','REG6690',4,1,NULL,'Emelia','Wilderman',NULL,NULL,'turner.volkman@example.com',NULL,'$2y$10$AA5kdcXlzhGXgh8UpRRcoePWcs0ZzqtqgbUTMbs6Z2.7wO0ZBZfgG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2018-12-25','(858) 282-0083',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(472,'S04275','REG2503',6,3,NULL,'Sylvia','Terry',NULL,NULL,'cbeer@example.org',NULL,'$2y$10$BLi/kLEqO4PGDPs6GosXWOv0ABUd.9MJBh73nM1x1l8dJXAqW.n/i','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1998-04-16','571-408-8772',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(473,'S00368','REG6593',1,2,NULL,'Sofia','Maggio',NULL,NULL,'bednar.tillman@example.org',NULL,'$2y$10$xJXE90SBc1wfkTEry871AefX/6Zjr0nbAF.gQ8heDbyVyxioYhd/C','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1983-03-11','+1.270.733.6234',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(474,'S55706','REG3510',1,2,NULL,'Leopold','Torp',NULL,NULL,'carson.hansen@example.net',NULL,'$2y$10$K.y1bUfx0fiYUip19CnRTOjFmTihavh.D8EtNzzECR52ItwFp9rze','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2024-01-24','417-335-6258',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(475,'S27252','REG2683',5,3,NULL,'Howell','Schumm',NULL,NULL,'farrell.loraine@example.com',NULL,'$2y$10$AqIHPidUWvv/jKEzNq2yR.AeGZK5yrtOFdfvedgsPwSrFziwiwgGm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1989-08-23','458.303.0605',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(476,'S61588','REG7820',5,3,NULL,'Zola','Spencer',NULL,NULL,'bartell.manley@example.net',NULL,'$2y$10$Nycwsmga.LAHkneGxBNQyOWgeLidfE.K4udtt8HQGurv1VTU3MD2K','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1978-01-12','785.807.0388',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(477,'S43626','REG7151',4,1,NULL,'Darwin','Grady',NULL,NULL,'buckridge.vernice@example.com',NULL,'$2y$10$Lcv.GaLx53HmSiePBJvzKe0fDUJXqVcqTeqdNeZ/Q.R44jIhaa4aK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1977-09-16','747.857.9878',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(478,'S68449','REG5506',1,2,NULL,'Myrtis','Davis',NULL,NULL,'derrick82@example.org',NULL,'$2y$10$ubbz32QUB35RDNp.FB9FouueCFmi4Y3BXBFCiOf0EcZFaj0K7Rvou','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2019-10-28','614.340.8256',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:51','2025-04-11 12:40:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(479,'S38638','REG6293',3,1,NULL,'Jennifer','Feest',NULL,NULL,'newell90@example.com',NULL,'$2y$10$5ubRz2kS6omWom07ftmd7.i/1lRHvQMuIeQSC1RtLUpuYxJV.P1C2','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2000-07-23','1-361-397-1198',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(480,'S68593','REG8138',3,1,NULL,'Kathryn','Prosacco',NULL,NULL,'isobel28@example.net',NULL,'$2y$10$m9Rc3muACz35gr.56gSSYu3Ax0IJOoTrLLt5QlU0.bixEJv/sc142','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1988-10-24','(475) 510-1809',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(481,'S17010','REG1153',3,1,NULL,'Augustus','D\'Amore',NULL,NULL,'lmertz@example.com',NULL,'$2y$10$V5gCURs9tb4kEtTWGzXYr.mrGQ3C46ZMgX/CfqCpHjOCF0h39PKmi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1972-12-26','650-988-4045',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(482,'S21859','REG5429',3,1,NULL,'Shakira','Fahey',NULL,NULL,'cole.javonte@example.net',NULL,'$2y$10$399UJ2TjdsOB4xyN18BIUe5jCdoxAylj44MsmtZTT8vQ5e1v6xmpi','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2015-03-28','+1 (351) 892-5133',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(483,'S49550','REG3176',3,1,NULL,'Brionna','Powlowski',NULL,NULL,'keeley73@example.org',NULL,'$2y$10$hbWTMUXyIZ4pKo53eoKrW.WnfOC7taTTQtVv7D7f/qI3ygZqi7ehK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2002-09-06','+1-440-463-2402',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(484,'S06305','REG1765',3,1,NULL,'Karlie','McLaughlin',NULL,NULL,'vblanda@example.org',NULL,'$2y$10$eaGppVjIbqpK9WtCJAR4oeGh.GLGeF2tqeyMSL.bQ8uRN7XYGN5FO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2007-03-07','1-231-936-6494',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(485,'S89238','REG8219',5,3,NULL,'Viviane','Collins',NULL,NULL,'noble.adams@example.net',NULL,'$2y$10$iqq1hdFEqu43AIFDA14I1.phZeTlQWuFZgFBlH6A2OvNQ/q617pP6','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2021-07-11','+1-707-275-3961',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(486,'S57733','REG7523',6,3,NULL,'Geovany','Hoeger',NULL,NULL,'michele31@example.net',NULL,'$2y$10$T/T94DKFxaJLY3npUGFYgegvd5KybHp7HN2hgJN5nZmY4S9VUmevO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2002-03-21','(256) 876-6140',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(487,'S00230','REG2135',6,3,NULL,'Garret','Beahan',NULL,NULL,'jessie.johnson@example.com',NULL,'$2y$10$ochtI1rKo0NvS8yhLqXN.ONvHS6Bg.CsolKMSxTdYvoUlOvFOFAXa','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2000-12-03','1-283-942-3576',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(488,'S66199','REG3938',4,1,NULL,'Micaela','Jacobson',NULL,NULL,'kellie40@example.org',NULL,'$2y$10$8Sa/eLlj57yykLoFBfngcurfoGwR9lz9bY5m/PTpDo84t90Xsv/va','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1978-07-02','+1.951.724.9367',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:52','2025-04-11 12:40:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(489,'S33970','REG2032',5,3,NULL,'Armand','Morar',NULL,NULL,'pturner@example.com',NULL,'$2y$10$dzFqjnadZi4nD4X5cVOJuut1qwmFedBMOPwmSGKBDUfJouUE7v8lK','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1996-08-17','(224) 240-5333',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(490,'S88541','REG1376',1,2,NULL,'Nasir','Predovic',NULL,NULL,'oturcotte@example.net',NULL,'$2y$10$EUuXNme7O8scRmnYEnx4MOQp0t0C1QtAJRlbltRmW2UA6/6r0wyyG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'1980-02-14','+1-352-400-1086',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(491,'S46131','REG6516',6,3,NULL,'Kory','Barton',NULL,NULL,'reilly.orland@example.org',NULL,'$2y$10$TFVbvpoLwieG2kIaUK2OVOhBxa1PUm14.oltN1YEIBI9EZOunNc0C','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2000-05-31','847.912.7706',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(492,'S82094','REG2589',2,2,NULL,'Yesenia','Rogahn',NULL,NULL,'katlyn.keebler@example.net',NULL,'$2y$10$OwG.G7Fq.q9VDAme.xCPZ.EnAASHlLMVSWF79DMIOiopIcn3rYlUG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2016-11-09','(207) 918-1017',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(493,'S69238','REG1111',4,1,NULL,'Kellie','Bashirian',NULL,NULL,'hstoltenberg@example.net',NULL,'$2y$10$e1a.XL5LwpfuNK1gmr5np.AMAHowAV8w4yiMvq6ifvoOtpfnGS2Wm','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1986-05-08','828.469.5677',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(494,'S22385','REG6300',4,1,NULL,'Kamryn','Davis',NULL,NULL,'janie.lesch@example.org',NULL,'$2y$10$PG6wUy9dBrGjXVWlzi7Zu.cW5IJVCXK3QT6eMkcgDKN5QnLMvwMJe','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2012-05-20','(480) 726-0092',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(495,'S17831','REG0700',5,3,NULL,'Darryl','Effertz',NULL,NULL,'kassandra.jaskolski@example.org',NULL,'$2y$10$7Arc/Qht5NjWhJCJeMlS8uwC8gq3gcNFNC/d.Ws0BPNB9apau.DfO','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1992-10-09','1-531-730-8060',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(496,'S70429','REG6900',5,3,NULL,'Manuel','Veum',NULL,NULL,'maci13@example.net',NULL,'$2y$10$756VIBq.ab54Tkx6VJ.9heWHyVQjQzVMXOFiGP1F3YFhWlKMd1aB.','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'1981-03-15','(754) 895-5638',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(497,'S21337','REG2633',2,2,NULL,'Rudolph','Kreiger',NULL,NULL,'mharvey@example.org',NULL,'$2y$10$FUGiu70EOdvo.j95etPore.IFdSp3PdGsKHo1ePYrLJnr7LgmKemq','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2012-06-11','770-423-1829',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:53','2025-04-11 12:40:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(498,'S84502','REG6334',6,3,NULL,'Noelia','Hamill',NULL,NULL,'upton.edyth@example.net',NULL,'$2y$10$WJK0LzFKEjzyamuSyoTZlOPxwRv.dEnpen93zF6R2wpWo7sGfC4Di','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'1991-09-05','+1-986-634-3554',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:54','2025-04-11 12:40:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(499,'S97745','REG7981',2,2,NULL,'Edward','Mann',NULL,NULL,'verna42@example.org',NULL,'$2y$10$D2zkHwX2HwLB53cfQnfdNuGI51Hb5IW5my2vZxsOAC2E6LThQIxLG','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2017-02-03','979.268.6097',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:54','2025-04-11 12:40:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(500,'S52249','REG5745',2,2,NULL,'Eloy','Simonis',NULL,NULL,'emmet78@example.com',NULL,'$2y$10$xNW1EYBDEajlyAxN7p15d.g5nmw0geAFgNfmaUEw5RkOuWLWMq00G','password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2016-10-21','+17577344750',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,NULL,'2025-04-11 12:40:54','2025-04-11 12:40:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_markings`
--

DROP TABLE IF EXISTS `subject_markings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_markings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_enroll_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `exam_marks` decimal(5,2) DEFAULT NULL,
  `attendances` decimal(5,2) DEFAULT NULL,
  `assignments` decimal(5,2) DEFAULT NULL,
  `activities` decimal(5,2) DEFAULT NULL,
  `total_marks` decimal(5,2) DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `publish_time` time DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_markings_student_enroll_id_foreign` (`student_enroll_id`),
  KEY `subject_markings_subject_id_foreign` (`subject_id`),
  CONSTRAINT `subject_markings_student_enroll_id_foreign` FOREIGN KEY (`student_enroll_id`) REFERENCES `student_enrolls` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subject_markings_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_markings`
--

LOCK TABLES `subject_markings` WRITE;
/*!40000 ALTER TABLE `subject_markings` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject_markings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit_hour` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` int(11) DEFAULT NULL,
  `class_type` int(11) DEFAULT NULL,
  `total_marks` decimal(5,2) DEFAULT NULL,
  `passing_marks` decimal(5,2) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subjects_title_unique` (`title`),
  UNIQUE KEY `subjects_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'Introduction to Business','BUS 101','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(2,'English Writing and Public Speaking','BUS 102','2',1,1,NULL,NULL,NULL,1,NULL,NULL),(3,'Business Mathematics','BUS 103','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(4,'Business Communication','BUS 104','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(5,'Society, Business, and Government','BUS 105','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(6,'Business Statistics I','BUS 106','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(7,'Microeconomics','BUS 108','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(8,'Principles of Management','MGT 101','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(9,'Financial Accounting I','ACT 101','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(10,'Introduction to Psychology','BUS 110','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(11,'Business Statistics II','BUS 207','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(12,'Macroeconomics','BUS 209','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(13,'Financial Accounting II','ACT 202','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(14,'Organization Behavior','MGT 202','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(15,'Introduction to Marketing','MKT 201','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(16,'Introduction to Finance','FIN 201','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(17,'Financial Management','FIN 202','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(18,'Human Resource Management','HRM 201','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(19,'Management Accounting','ACT 203','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(20,'Legal Environment in Business','BUS 211','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(21,'Management Information System','MIS 201','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(22,'Marketing Management','MKT 202','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(23,'Production and Operation Management','BUS 312','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(24,'Taxation and Auditing','ACT 304','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(25,'Bank Management','FIN 303','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(26,'Operation Research','BUS 313','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(27,'Socio Economic Study of Bangladesh','BUS 314','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(28,'Business Ethics','BUS 315','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(29,'Entrepreneurship','BUS 416','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(30,'Business Research Methodology','BUS 417','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(31,'Advance Strategic Management','MGT 403','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(32,'Research Project','BUS 498','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(33,'Internship','BUS 499','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(34,'Advance Corporate Finance','FIN 401','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(35,'Financial Institutions and Markets','FIN 402','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(36,'Investment and Portfolio Management','FIN 403','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(37,'Real Estate Finance and Investment','FIN 404','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(38,'Financial Statement Analysis','FIN 405','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(39,'Working Capital Management','FIN 406','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(40,'Financial Engineering','FIN 407','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(41,'Public Finance','FIN 408','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(42,'International Financial Management','FIN 409','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(43,'Risk Management and Insurance','FIN 410','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(44,'Behavioral Finance','FIN 411','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(45,'Theory of Finance','FIN 412','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(46,'Selected Issues in Finance','FIN 413','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(47,'Consumer Behavior','MKT 401','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(48,'Service Marketing','MKT 402','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(49,'Marketing Channel Management','MKT 403','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(50,'Strategic Brand Management','MKT 404','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(51,'International Marketing','MKT 405','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(52,'Integrated Marketing Communication','MKT 406','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(53,'Customer Relationship Management','MKT 407','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(54,'Export Import Marketing','MKT 408','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(55,'Sales Management','MKT 409','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(56,'Product Management','MKT 410','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(57,'Fundamentals of E-Marketing','MKT 411','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(58,'Global Marketing','MKT 412','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(59,'Selected Issues in Marketing','MKT 413','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(60,'Workforce Policy and Planning','HRM 401','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(61,'Labor and Industrial Law','HRM 402','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(62,'Industrial Relations','HRM 403','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(63,'Performance Management','HRM 404','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(64,'Conflict Management','HRM 405','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(65,'Compensation Management','HRM 406','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(66,'Training and Development','HRM 407','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(67,'Trade Union and Collective Bargaining','HRM 408','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(68,'Labor Economics','HRM 409','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(69,'Selected Issues in Human Resource Management','HRM 410','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(70,'Accounting Information System','ACT 401','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(71,'Strategic Management Accounting','ACT 402','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(72,'Accounting for Government and Non-Profit Organization','ACT 403','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(73,'Cost Accounting','ACT 404','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(74,'Intermediate Accounting','ACT 405','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(75,'Advanced Financial Accounting','ACT 406','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(76,'Advanced Auditing','ACT 407','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(77,'Special Issues in Accounting','ACT 408','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(78,'System Analysis and Design','MIS 401','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(79,'Introduction to Database','MIS 402','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(80,'Object Oriented Programming','MIS 403','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(81,'Web Based Programming','MIS 404','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(82,'Network Resource Management','MIS 405','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(83,'Internet Security','MIS 406','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(84,'E-Commerce','MIS 407','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(85,'Decision Support System','MIS 408','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(86,'Selected Issues in Management Information System','MIS 409','3',0,1,NULL,NULL,NULL,1,NULL,NULL),(87,'Advanced Management Principles','MBA 601','3',1,1,NULL,NULL,'Core Course',1,NULL,NULL),(88,'Corporate Financial Reporting','MBA 602','3',1,1,NULL,NULL,'Core Course',1,NULL,NULL),(89,'Marketing Strategy','MBA 603','3',1,1,NULL,NULL,'Core Course',1,NULL,NULL),(90,'Business Ethics and Corporate Governance','MBA 604','3',1,1,NULL,NULL,'Core Course',1,NULL,NULL),(91,'Strategic Management','MBA 605','3',1,1,NULL,NULL,'Core Course',1,NULL,NULL),(92,'Corporate Finance','FIN 601','3',2,1,NULL,NULL,'Major - Finance',1,NULL,NULL),(93,'Financial Markets and Institutions','FIN 602','3',1,1,NULL,NULL,'Major - Finance',1,NULL,NULL),(94,'International Finance','FIN 603','3',1,1,NULL,NULL,'Major - Finance',1,NULL,NULL),(95,'Financial Derivatives','FIN 604','3',1,1,NULL,NULL,'Major - Finance',1,NULL,NULL),(96,'Advanced Investment Analysis','FIN 605','3',1,1,NULL,NULL,'Major - Finance',1,NULL,NULL),(97,'Digital Marketing','MKT 601','3',1,1,NULL,NULL,'Minor - Marketing',1,NULL,NULL),(98,'Consumer Insights','MKT 602','3',1,1,NULL,NULL,'Minor - Marketing',1,NULL,NULL),(99,'Dissertation in Finance','FIN 699','3',4,1,NULL,NULL,'Dissertation based on major area',1,NULL,NULL),(100,'Advance Management','MBA 501','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(101,'Managerial Economics','MBA 502','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(102,'Financial Accounting','MBA 503','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(103,'Advance Marketing Management','MBA 504','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(104,'Organizational Behavior','MBA 505','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(105,'Quantitative Techniques for Business','MBA 506','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(106,'Advance Business Communication','MBA 507','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(107,'Managerial Finance','MBA 508','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(108,'Advance Human Resource Management','MBA 509','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(109,'Operations Management','MBA 510','3',1,1,NULL,NULL,NULL,1,NULL,NULL),(110,'Banking Operations and Risk Management','FIN 631','3',2,1,NULL,NULL,'Banking and Finance',1,NULL,NULL),(111,'Investment Analysis and Portfolio Management','FIN 632','3',2,1,NULL,NULL,'Banking and Finance',1,NULL,NULL),(112,'Strategic Marketing','MKT 631','3',2,1,NULL,NULL,'Marketing',1,NULL,NULL),(113,'Advance Consumer Behavior','MKT 632','3',2,1,NULL,NULL,'Marketing',1,NULL,NULL),(114,'Performance and Compensation Management','HRM 631','3',2,1,NULL,NULL,'HR Management',1,NULL,NULL),(115,'Information Systems Management','MIS 631','3',2,1,NULL,NULL,'MIS',1,NULL,NULL),(116,'Database Systems for Business','MIS 632','3',2,1,NULL,NULL,'MIS',1,NULL,NULL),(117,'Quantitative Decision Making','QBA 631','3',2,1,NULL,NULL,'Quantitative Business Analysis',1,NULL,NULL),(118,'Project Management in Development','DM 631','3',2,1,NULL,NULL,'Development Management',1,NULL,NULL),(119,'International Trade and Business','IB 631','3',2,1,NULL,NULL,'International Business',1,NULL,NULL);
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_settings`
--

DROP TABLE IF EXISTS `tax_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `min_amount` decimal(10,2) NOT NULL,
  `max_amount` decimal(10,2) NOT NULL,
  `percentange` double(4,2) NOT NULL,
  `max_no_taxable_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_settings`
--

LOCK TABLES `tax_settings` WRITE;
/*!40000 ALTER TABLE `tax_settings` DISABLE KEYS */;
INSERT INTO `tax_settings` VALUES (1,0.00,5000.00,0.00,0.00,1,NULL,NULL),(2,5001.00,10000.00,5.00,5000.00,1,NULL,NULL),(3,10001.00,20000.00,10.00,5000.00,1,NULL,'2022-10-01 05:22:30'),(4,20001.00,50000.00,15.00,5000.00,1,NULL,NULL);
/*!40000 ALTER TABLE `tax_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testimonials`
--

DROP TABLE IF EXISTS `testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimonials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` double(2,2) NOT NULL DEFAULT '0.99',
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `testimonials_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimonials`
--

LOCK TABLES `testimonials` WRITE;
/*!40000 ALTER TABLE `testimonials` DISABLE KEYS */;
INSERT INTO `testimonials` VALUES (1,1,'Margie Dose','Web Developer','Curabitur ac tortor ante. Sed quis iaculis risus. Ut ultrices ligula aliquet odio tristique euismod. Donec efficitur dolor in turpis aliquet, at mollis.',0.99,'testi_avatar_1692915788.png',1,'2023-08-24 16:23:08','2023-08-24 16:23:08'),(2,1,'Rock Dloder','Web Developer','Curabitur ac tortor ante. Sed quis iaculis risus. Ut ultrices ligula aliquet odio tristique euismod. Donec efficitur dolor in turpis aliquet, at mollis.',0.99,'testi_avatar_02_1692915825.png',1,'2023-08-24 16:23:45','2023-08-24 16:23:45'),(3,1,'Roboto Eorure','Web Developer','Curabitur ac tortor ante. Sed quis iaculis risus. Ut ultrices ligula aliquet odio tristique euismod. Donec efficitur dolor in turpis aliquet, at mollis.',0.99,'testi_avatar_03_1692915872.png',1,'2023-08-24 16:24:32','2023-08-24 16:24:32'),(4,1,'Alex Barek','Web Developer','Curabitur ac tortor ante. Sed quis iaculis risus. Ut ultrices ligula aliquet odio tristique euismod. Donec efficitur dolor in turpis aliquet, at mollis.',0.99,'testi_avatar_1692915924.png',1,'2023-08-24 16:25:24','2023-08-24 16:25:24'),(5,1,'Devid Rogart','Web Developer','Curabitur ac tortor ante. Sed quis iaculis risus. Ut ultrices ligula aliquet odio tristique euismod. Donec efficitur dolor in turpis aliquet, at mollis.',0.99,'testi_avatar_02_1692915972.png',1,'2023-08-24 16:26:12','2023-08-24 16:26:12');
/*!40000 ALTER TABLE `testimonials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topbar_settings`
--

DROP TABLE IF EXISTS `topbar_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topbar_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `address_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_hour` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about_summery` text COLLATE utf8mb4_unicode_ci,
  `social_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_status` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topbar_settings`
--

LOCK TABLES `topbar_settings` WRITE;
/*!40000 ALTER TABLE `topbar_settings` DISABLE KEYS */;
INSERT INTO `topbar_settings` VALUES (1,NULL,'Dhaka, Bangladesh','hello@campus365.pro','+00123456789',NULL,NULL,NULL,NULL,1,1,'2023-08-24 15:52:44','2023-08-24 15:53:17');
/*!40000 ALTER TABLE `topbar_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transactionable_id` bigint(20) NOT NULL,
  `transactionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1 Creadit & 2 Debit',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transactions_transaction_id_unique` (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,2,'App\\Models\\Student','H9Cpqn51xGm7mVpE',3150.00,1,1,NULL,'2022-10-03 13:35:39','2022-10-03 13:35:39'),(2,4,'App\\Models\\Student','f5JWnxrigm6KyHgY',3150.00,1,1,NULL,'2022-10-03 13:35:58','2022-10-03 13:35:58'),(3,7,'App\\Models\\Student','yo1FhMZ8dS3UqA8M',4000.00,1,1,NULL,'2022-10-03 13:38:36','2022-10-03 13:38:36'),(4,7,'App\\Models\\Student','31iN1HVqCYzslNU8',4000.00,2,1,NULL,'2022-10-03 13:38:52','2022-10-03 13:38:52'),(5,7,'App\\Models\\Student','VPpGpvTamxJ8KZA6',4050.00,1,1,NULL,'2022-10-03 13:39:15','2022-10-03 13:39:15'),(6,7,'App\\User','AOzKLAvS6WgUjcWW',14189.00,2,1,NULL,'2022-10-03 15:36:52','2022-10-03 15:36:52'),(7,8,'App\\User','Za0r26eRfMei4lQa',16526.00,2,1,NULL,'2022-10-03 15:37:35','2022-10-03 15:37:35'),(8,3,'App\\User','8aSusUqJhjdRysWJ',3000.00,2,1,NULL,'2022-10-03 15:45:04','2022-10-03 15:45:04'),(9,14,'App\\Models\\Student','2kChl0YGtKwZCI4I',1800.00,1,1,NULL,'2022-10-04 09:21:36','2022-10-04 09:21:36'),(10,2,'App\\Models\\Student','9hAdG9i38LTJ0aPR',3150.00,2,1,NULL,'2022-10-04 09:22:16','2022-10-04 09:22:16'),(11,4,'App\\Models\\Student','cIMb0tMlA9o2te2Z',3150.00,2,1,NULL,'2022-10-04 09:22:29','2022-10-04 09:22:29'),(12,1,'App\\Models\\Student','kog5hZw38tMToRkE',3200.00,1,1,NULL,'2022-10-04 09:22:54','2022-10-04 09:22:54'),(13,4,'App\\Models\\Student','UlYXx4aja6Ak3Wly',3200.00,1,1,NULL,'2022-10-04 09:23:56','2022-10-04 09:23:56'),(14,10,'App\\Models\\Student','xfXmn8WO7BhybnAv',1800.00,1,1,NULL,'2022-10-04 09:24:08','2022-10-04 09:24:08'),(15,10,'App\\Models\\Student','BUUHGkNA9Fun4Ift',1800.00,2,1,NULL,'2022-10-04 10:10:50','2022-10-04 10:10:50'),(16,12,'App\\Models\\Student','BTXkfv9esWhw1A4Q',1800.00,1,1,NULL,'2022-10-04 10:11:18','2022-10-04 10:11:18'),(17,10,'App\\Models\\Student','7z16Tht5q9Xei6xZ',1800.00,1,1,NULL,'2022-10-04 10:11:26','2022-10-04 10:11:26'),(18,7,'App\\User','KiwXkDl0MD2rfckr',14189.00,1,1,NULL,'2022-10-04 10:22:13','2022-10-04 10:22:13'),(19,7,'App\\User','cj4IjjdIolJTJ3uK',14189.00,2,1,NULL,'2022-10-04 10:22:30','2022-10-04 10:22:30'),(20,4,'App\\Models\\Student','XbscZanSZVsUZYMx',1800.00,1,1,NULL,'2022-10-04 10:23:58','2022-10-04 10:23:58'),(21,8,'App\\Models\\Student','jWgYEu9vXOvpRWgP',1800.00,1,1,NULL,'2023-02-13 11:54:05','2023-02-13 11:54:05'),(22,5,'App\\Models\\Student','t58UYubvOVytQ6I2',1800.00,1,1,NULL,'2023-02-13 11:55:00','2023-02-13 11:55:00'),(23,7,'App\\User','uFzvvWcKEPZQo1sJ',14189.00,1,1,NULL,'2023-02-13 11:59:32','2023-02-13 11:59:32'),(24,8,'App\\User','R10BvOK5v7XdkJdm',16526.00,1,1,NULL,'2023-02-13 11:59:36','2023-02-13 11:59:36'),(25,3,'App\\User','P6cFuywfB0TxDbiQ',3000.00,1,1,NULL,'2023-02-13 12:01:45','2023-02-13 12:01:45'),(26,3,'App\\User','cSHqT2rl213GWXdd',4300.00,2,1,NULL,'2023-02-13 12:02:24','2023-02-13 12:02:24'),(27,2,'App\\User','R9kMSPcqDHBQOTCb',14886.00,2,1,NULL,'2023-02-13 12:02:40','2023-02-13 12:02:40'),(28,7,'App\\User','6qQ4EuW9m9Xuduqm',17969.00,2,1,NULL,'2023-02-13 12:02:49','2023-02-13 12:02:49'),(29,9,'App\\Models\\Student','E5CT2yfO92tLOktz',1800.00,1,1,NULL,'2023-08-25 06:29:24','2023-08-25 06:29:24'),(30,1,'App\\Models\\Student','fK6t6Dj6RoxwzF7a',1800.00,1,1,NULL,'2023-08-25 06:29:56','2023-08-25 06:29:56');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfer_creadits`
--

DROP TABLE IF EXISTS `transfer_creadits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfer_creadits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `semester_id` int(10) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `marks` decimal(10,2) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transfer_creadits_student_id_foreign` (`student_id`),
  KEY `transfer_creadits_program_id_foreign` (`program_id`),
  KEY `transfer_creadits_session_id_foreign` (`session_id`),
  KEY `transfer_creadits_semester_id_foreign` (`semester_id`),
  KEY `transfer_creadits_subject_id_foreign` (`subject_id`),
  CONSTRAINT `transfer_creadits_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transfer_creadits_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transfer_creadits_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transfer_creadits_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transfer_creadits_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfer_creadits`
--

LOCK TABLES `transfer_creadits` WRITE;
/*!40000 ALTER TABLE `transfer_creadits` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfer_creadits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_members`
--

DROP TABLE IF EXISTS `transport_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transport_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transportable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transportable_id` bigint(20) unsigned NOT NULL,
  `transport_route_id` int(10) unsigned NOT NULL,
  `transport_vehicle_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Inactive, 1 Active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transport_members_transportable_type_transportable_id_index` (`transportable_type`,`transportable_id`),
  KEY `transport_members_transport_route_id_foreign` (`transport_route_id`),
  KEY `transport_members_transport_vehicle_id_foreign` (`transport_vehicle_id`),
  CONSTRAINT `transport_members_transport_route_id_foreign` FOREIGN KEY (`transport_route_id`) REFERENCES `transport_routes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transport_members_transport_vehicle_id_foreign` FOREIGN KEY (`transport_vehicle_id`) REFERENCES `transport_vehicles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_members`
--

LOCK TABLES `transport_members` WRITE;
/*!40000 ALTER TABLE `transport_members` DISABLE KEYS */;
INSERT INTO `transport_members` VALUES (1,'App\\Models\\Student',11,1,1,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:00:43','2023-02-13 13:00:43'),(2,'App\\Models\\Student',8,2,1,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:00:52','2023-02-13 13:00:52'),(3,'App\\Models\\Student',14,1,3,'2023-02-13','2024-05-22',NULL,0,1,1,'2023-02-13 13:01:03','2024-05-22 14:01:08'),(4,'App\\Models\\Student',10,2,2,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:01:11','2023-02-13 13:01:11'),(5,'App\\User',8,1,1,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:01:42','2023-02-13 13:01:42'),(6,'App\\User',7,2,2,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:01:48','2023-02-13 13:01:48'),(7,'App\\User',3,1,3,'2023-02-13',NULL,NULL,1,1,NULL,'2023-02-13 13:01:55','2023-02-13 13:01:55'),(8,'App\\Models\\Student',7,1,1,'2024-05-22',NULL,NULL,1,1,NULL,'2024-05-22 14:01:00','2024-05-22 14:01:00');
/*!40000 ALTER TABLE `transport_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_route_transport_vehicle`
--

DROP TABLE IF EXISTS `transport_route_transport_vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transport_route_transport_vehicle` (
  `transport_route_id` int(10) unsigned NOT NULL,
  `transport_vehicle_id` int(10) unsigned NOT NULL,
  KEY `transport_route_transport_vehicle_transport_route_id_foreign` (`transport_route_id`),
  KEY `transport_route_transport_vehicle_transport_vehicle_id_foreign` (`transport_vehicle_id`),
  CONSTRAINT `transport_route_transport_vehicle_transport_route_id_foreign` FOREIGN KEY (`transport_route_id`) REFERENCES `transport_routes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transport_route_transport_vehicle_transport_vehicle_id_foreign` FOREIGN KEY (`transport_vehicle_id`) REFERENCES `transport_vehicles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_route_transport_vehicle`
--

LOCK TABLES `transport_route_transport_vehicle` WRITE;
/*!40000 ALTER TABLE `transport_route_transport_vehicle` DISABLE KEYS */;
INSERT INTO `transport_route_transport_vehicle` VALUES (1,1),(2,1),(2,2),(1,3);
/*!40000 ALTER TABLE `transport_route_transport_vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_routes`
--

DROP TABLE IF EXISTS `transport_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transport_routes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee` double(10,2) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transport_routes_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_routes`
--

LOCK TABLES `transport_routes` WRITE;
/*!40000 ALTER TABLE `transport_routes` DISABLE KEYS */;
INSERT INTO `transport_routes` VALUES (1,'Mirpur to Gulshan',50.00,NULL,1,'2023-02-13 12:59:12','2023-02-13 12:59:12'),(2,'Mirpur to Uttora',30.00,NULL,1,'2023-02-13 12:59:32','2023-02-13 12:59:32');
/*!40000 ALTER TABLE `transport_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport_vehicles`
--

DROP TABLE IF EXISTS `transport_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transport_vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_made` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `driver_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `driver_license` text COLLATE utf8mb4_unicode_ci,
  `driver_contact` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport_vehicles`
--

LOCK TABLES `transport_vehicles` WRITE;
/*!40000 ALTER TABLE `transport_vehicles` DISABLE KEYS */;
INSERT INTO `transport_vehicles` VALUES (1,'635','Bus',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2023-02-13 12:59:55','2023-02-13 12:59:55'),(2,'788','Bus',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2023-02-13 13:00:10','2023-02-13 13:00:10'),(3,'856','Bus',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2023-02-13 13:00:20','2023-02-13 13:00:20');
/*!40000 ALTER TABLE `transport_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_program`
--

DROP TABLE IF EXISTS `user_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_program` (
  `user_id` bigint(20) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  KEY `user_program_user_id_foreign` (`user_id`),
  KEY `user_program_program_id_foreign` (`program_id`),
  CONSTRAINT `user_program_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_program_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_program`
--

LOCK TABLES `user_program` WRITE;
/*!40000 ALTER TABLE `user_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `designation_id` int(10) unsigned DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_text` longtext COLLATE utf8mb4_unicode_ci,
  `gender` int(11) NOT NULL COMMENT '1 Male, 2 Female & 3 Other',
  `dob` date NOT NULL,
  `joining_date` date DEFAULT NULL,
  `ending_date` date DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mother_tongue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` int(11) DEFAULT NULL,
  `blood_group` int(11) DEFAULT NULL,
  `nationality` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `national_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `present_province` int(10) unsigned DEFAULT NULL,
  `present_district` int(10) unsigned DEFAULT NULL,
  `present_village` text COLLATE utf8mb4_unicode_ci,
  `present_address` text COLLATE utf8mb4_unicode_ci,
  `permanent_province` int(10) unsigned DEFAULT NULL,
  `permanent_district` int(10) unsigned DEFAULT NULL,
  `permanent_village` text COLLATE utf8mb4_unicode_ci,
  `permanent_address` text COLLATE utf8mb4_unicode_ci,
  `education_level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graduation_academy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_of_graduation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graduation_field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experience` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `basic_salary` double(10,2) NOT NULL DEFAULT '0.00',
  `contract_type` int(11) NOT NULL DEFAULT '1' COMMENT '1 Full Time & 2 Part Time',
  `work_shift` int(10) unsigned DEFAULT NULL,
  `salary_type` int(11) NOT NULL DEFAULT '1' COMMENT '1 Fixed & 2 Hourly',
  `bank_account_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ifsc_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_brach` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` text COLLATE utf8mb4_unicode_ci,
  `signature` text COLLATE utf8mb4_unicode_ci,
  `resume` text COLLATE utf8mb4_unicode_ci,
  `joining_letter` text COLLATE utf8mb4_unicode_ci,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `login` tinyint(1) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 Inactive, 1 Active',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `religion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caste` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `epf_no` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_staff_id_unique` (`staff_id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'1001',1,2,'Super','Admin','ABC','XYZ','admin@mail.com',NULL,'$2y$10$RdSog4xnJYQlAL8CfEkScu5fq6lAK6PAHhRLiWRqqm.5Vbx3tgLTG','eyJpdiI6ImdEZVpac0I1amdTOVF0VXFobjZDOVE9PSIsInZhbHVlIjoiTmNUOHRNb0ZGTTVKN2JrNnNGdDJZdz09IiwibWFjIjoiODMyZDI4NDQzOWI2NjFmZTY2Y2QyZjRmZmExNjRiN2MyZTBlN2NmMDE5NDcyNGMwMGEwNjkwMjFiYmE1NWU0NiIsInRhZyI6IiJ9',1,'2006-01-01','2018-10-02',NULL,'0123456789',NULL,NULL,2,1,NULL,NULL,NULL,1,1,NULL,NULL,1,1,NULL,NULL,'Minima voluptatem f','Et sunt esse non pro','2001','Eum sed do omnis mai','Quo sunt hic except','Distinctio Esse do',50000.00,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,'HLeKqVaTCQPfTpM5Jt4ieMOPgbXbBfjOqEmIaBiBO6B13QfNouKblVI0OD7I',NULL,1,'2022-09-30 12:00:46','2022-10-02 05:49:52',NULL,NULL,NULL,NULL),(2,'1002',3,5,'Laurel','Rivers','Britanney Leonard','Aubrey Russo','student@mail.com',NULL,'$2y$10$K/0iAgcd6eCsquYurinHLe.KfCfdW6t2UQCSwi0NPoXj0h4gKa/8W','eyJpdiI6ImRUVW9XUHVHL1g1dld0SU85TjE5Ymc9PSIsInZhbHVlIjoiUmN3dDdkN3RvS05ob3o2Qzd5amtqdz09IiwibWFjIjoiOTEwODg5ZTczYTJjYWE5MTk5Y2ZkMjBkMGYzODI2OGMyNDA0MjU3NDZjMDM4YzgzNGNhN2E1Mjk3N2VlMjBhMiIsInRhZyI6IiJ9',2,'1995-05-03','2016-06-04',NULL,'+1 (382) 814-8571','+1 (706) 309-2903',NULL,1,4,NULL,'548567878674564','1215454574578',3,9,'Omnis aut earum veli','Voluptatem Fugit a',3,11,'Et non sunt tempore','Aperiam reprehenderi','Sint aut sed quos l','Non qui commodo quam','2012','Sit dolores incidun','Earum ea atque expli','Maiores totam ex nul',40000.00,1,2,1,NULL,NULL,NULL,NULL,NULL,NULL,'staff1_1664711572.jpg',NULL,NULL,NULL,0,1,1,'ittiQDTYx3Gt0dkqulHRYHAB0v5OdJPsWq0Fo1Bhy5QHinecQCnDZ4ylHS5V',1,1,'2022-10-02 05:52:52','2024-05-22 14:18:45',NULL,NULL,NULL,NULL),(3,'1003',5,3,'Meredith','Hancock','Ariana Mckenzie','Carla Oneill','vopukiceg@mailinator.com',NULL,'$2y$10$iXKFZNIyP/XXx6iQpUqNYeUQLa.LjZUVGzejhJKnMvd6vwjmKwDqO','eyJpdiI6ImtDeldFeTFaQWZGMm4xNGREUEZOUWc9PSIsInZhbHVlIjoiYS92dEVxcGNsamFZeGljRUFXbWk2Zz09IiwibWFjIjoiYmNkNWE1MTA3MmU4ODUwZWFkMTlmNDRkZTc1ZWRmMGU5YmRjM2VjYTgwZmUyMDk2OGU0MDViNzliYmVmMzA0MSIsInRhZyI6IiJ9',1,'2000-10-03','2015-12-31',NULL,'+1 (232) 685-4261','+1 (347) 622-9076',NULL,3,3,NULL,'Officia non cupidita','Omnis quia sed dolor',3,10,'Porro laborum quos d','Necessitatibus sit',4,3,'Temporibus corrupti','Neque id et officiis',NULL,NULL,NULL,NULL,NULL,NULL,300.00,2,2,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,'rYaqzHBSmFAyQDRtplAIOPlGG5w1k21AbZgy8vXCDyaNUz2liqjptpgPdlcH',1,1,'2022-10-02 05:55:46','2025-04-17 12:51:08',NULL,NULL,NULL,NULL),(4,'1004',5,1,'Daphne','Padilla','Akeem Lester','Mallory Winters','foxykosen@mailinator.com',NULL,'$2y$10$LzfVRaZciCdgmYZRnvchmehBhCREFtz68CmhGYPORckO2FsYniMUW','eyJpdiI6ImVGNCtUcUVER3ZrT2RCZjBzZnhxQVE9PSIsInZhbHVlIjoiZldUR3RwZmVFWHFEc3dzeW1XNlIzZz09IiwibWFjIjoiOTMyODJlMjcxYzE2MzBiMzQ2Y2IxYmQ5OWFhMDlkYTE2NDZjZmVhNzcyOTZiZTRkZTI2OGFhNzVkOTgxMGY2NiIsInRhZyI6IiJ9',1,'1977-11-04','2010-03-08',NULL,'+1 (736) 196-8936','+1 (856) 323-9264',NULL,5,2,NULL,'757867868576','786876876876',4,5,'Incidunt aperiam pa','Excepteur fugiat nec',4,4,'Itaque magni maxime','Autem itaque quis do','Ipsa autem dolores','Velit elit hic sint','2009','Qui quia culpa aspe','Commodi deserunt lab','Possimus minus ipsa',500.00,2,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'staff2_1664711842.jpg',NULL,NULL,NULL,0,1,1,NULL,1,1,'2022-10-02 05:57:22','2022-10-02 11:51:51',NULL,NULL,NULL,NULL),(5,'1005',5,3,'Emmanuel','Harmon','Thor Rosales','Desiree Crawford','wymawocowy@mailinator.com',NULL,'$2y$10$r1R9qzdjP0z02OP0Jneaq.eXfo4o3UKrtP8XMKENhjYJPn3bhjEY6','eyJpdiI6InBYNWFoZ3dadjd6L1Z3ZW9TTzczYmc9PSIsInZhbHVlIjoiVWVmeWtqRGdwQmYxQS9YaVJvaVV1QT09IiwibWFjIjoiOGRkZmM3MDU1ODkxNDc1Yjc5MDE5MTgyMDc2MmZkZDRkNTA1ZTg0ZDdhZjNkMTcwMTBkNmYxYjA0YjM3NmNiZiIsInRhZyI6IiJ9',2,'1972-09-29','2021-09-12',NULL,'+1 (363) 404-1739','+1 (874) 534-7443',NULL,3,4,NULL,'Ratione consequatur','Officia quaerat aliq',2,13,'Beatae Nam praesenti','Qui corporis quia la',1,2,'Qui vel consectetur','Nostrum deserunt eni','Non do mollit eos vo','Culpa unde quidem f','1998','Dolore culpa proide','In fugiat sit id qu','Eaque reiciendis qui',35000.00,1,2,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,NULL,1,1,'2022-10-02 05:59:21','2022-10-02 11:52:10',NULL,NULL,NULL,NULL),(6,'1006',1,6,'Sara','Boone','Vance Carroll','Vaughan Francis','myda@mailinator.com',NULL,'$2y$10$w2tfyISrZMeHcXrHaFw1aOufZeIATXxG1lXNnUZZQJR2FGnp49xX.','eyJpdiI6IjAxZWJ6SW9iR3pZTnU3aFRPYUUxRnc9PSIsInZhbHVlIjoiOGVQMWZNdmx2S2hOWUZpYlpFOXY4Zz09IiwibWFjIjoiMjFmMjRjM2I1OGE0NmE1YzRlM2Q4MzI1OGE3ZWZhZDdjYmU0ZTkzMjlmM2IxNTk5MTM4NTY1MTQ1NWE5YzQ5ZSIsInRhZyI6IiJ9',1,'1976-02-11','2016-09-13',NULL,'+1 (168) 535-3775','+1 (254) 313-7114',NULL,3,5,NULL,'Non nihil ex tempore','Enim sit voluptate',2,7,'Duis voluptas minima','Nisi molestias error',1,2,'Culpa aliquam et et','Ullamco laudantium','Ipsam sed qui dolore','Atque totam lorem co','1976','Consequatur excepte','Debitis dolore magna','Vero voluptatem labo',40000.00,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,NULL,1,1,'2022-10-02 11:33:19','2022-10-02 11:52:30',NULL,NULL,NULL,NULL),(7,'1007',5,3,'Zorita','Rivas','Paki Boyd','Deanna Arnold','jenywox@mailinator.com',NULL,'$2y$10$tAhSlZD.8giHI9ufBYDaoOo0KWjMCr3HRI9oa7j8bHlKQAj0raegm','eyJpdiI6ImZNMGRrbDNaMzJJdlFMejROa3JNUGc9PSIsInZhbHVlIjoiOHZkbEN6Wk15YXBRK2xsVGlXNGF4Zz09IiwibWFjIjoiMmUwZDRhMDczOThjZTRmMTA0NmMyOGQ5ZDZkOGY1YTI2MTIwMmI5ZTc3NmYwNGRmNDhiMzRkMmMyMmUwMGEyNyIsInRhZyI6IiJ9',1,'1997-06-13','2021-10-31',NULL,'+1 (512) 822-9148','+1 (231) 297-5927',NULL,4,8,NULL,'Ut suscipit qui dolo','Commodi possimus cu',4,4,'Rerum error est reru','Deleniti quis fugiat',4,3,'Reprehenderit elige','Eius repudiandae dol','Rerum accusamus sequ','Nam modi soluta volu','1983','Enim fugiat obcaeca','Atque nostrum ipsum','Deserunt in totam es',38000.00,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,NULL,1,1,'2022-10-02 11:37:09','2022-10-02 11:52:53',NULL,NULL,NULL,NULL),(8,'1008',2,4,'Kessie','Lee','Colleen Burt','Wesley Pittman','jyxeto@mailinator.com',NULL,'$2y$10$xadtHaIdxqKM5mL5RIZjlu5rXl8ezO3vKPNHq4dtwWV03YI/QTxri','eyJpdiI6IlFTQlcvYk9XRXoyQ1BxRVlpMUlPblE9PSIsInZhbHVlIjoiLzMvOWFzU3NPMU13UnVKZXVxVC9lQT09IiwibWFjIjoiYzhjM2ViMjVlYWZhN2I4NjEyMWFhNmI5YzJkY2ZiNTI0NjE4MjhhYzRjYjc3YWVhMjliY2IxNjJlZjY0OTYzMiIsInRhZyI6IiJ9',2,'1979-04-27','2018-05-30',NULL,'+1 (492) 339-1114','+1 (485) 738-3534',NULL,3,6,NULL,'58765568','9841357',1,6,'Quia consequat Ut l','Commodo dolores eius',4,12,'Ducimus amet volup','Quia ullamco quo bea',NULL,NULL,NULL,NULL,NULL,NULL,35000.00,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,NULL,1,1,'2022-10-02 11:45:51','2022-10-02 11:53:10',NULL,NULL,NULL,NULL),(9,'1009',4,2,'Sophia','Hyde','Tucker Knapp','Halla Pugh','kojec@mailinator.com',NULL,'$2y$10$LFeLB5XhtE3b43nbctAvY.fRz.bEpbdnhuhy6AYbAtjNgbtI.d4SO','eyJpdiI6IjdyRUQzampIVEpaQTBhcDFkWDhvSFE9PSIsInZhbHVlIjoiTG9peUphcUNwbHFOYmNLelBFais4dz09IiwibWFjIjoiNDA5YmUyNTIzNjA0NGY1M2NiMmMyY2I5OTAwNDYxNzIwNDE5MjVkYmUzNWQ0NGZhYzQ4ZGNkY2YyYTRmOTY4NSIsInRhZyI6IiJ9',2,'1989-02-26','2022-09-23',NULL,'+1 (542) 196-8396','+1 (139) 442-4078',NULL,4,6,NULL,'9874646','4568765323',2,7,'Eos aut lorem exped','Tempora aspernatur i',1,6,'Et veniam doloribus','Enim molestias enim',NULL,NULL,NULL,NULL,NULL,NULL,30000.00,1,2,1,NULL,NULL,NULL,NULL,NULL,NULL,'staff1_1664732856.jpg',NULL,NULL,NULL,0,1,1,NULL,1,1,'2022-10-02 11:47:36','2022-10-02 11:53:26',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_purposes`
--

DROP TABLE IF EXISTS `visit_purposes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visit_purposes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `visit_purposes_title_unique` (`title`),
  UNIQUE KEY `visit_purposes_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_purposes`
--

LOCK TABLES `visit_purposes` WRITE;
/*!40000 ALTER TABLE `visit_purposes` DISABLE KEYS */;
INSERT INTO `visit_purposes` VALUES (1,'Invigilation','invigilation',NULL,1,'2022-10-01 03:39:14','2022-10-01 03:39:14'),(2,'Parent Meeting','parent-meeting',NULL,1,'2022-10-01 03:39:30','2022-10-01 03:39:30'),(3,'Enquiry','enquiry',NULL,1,'2022-10-01 03:39:51','2022-10-01 03:39:51'),(4,'Attend Event','attend-event',NULL,1,'2022-10-01 04:05:36','2022-10-01 04:05:36');
/*!40000 ALTER TABLE `visit_purposes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitors`
--

DROP TABLE IF EXISTS `visitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purpose_id` int(10) unsigned NOT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `visit_from` text COLLATE utf8mb4_unicode_ci,
  `id_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `persons` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visitors_purpose_id_foreign` (`purpose_id`),
  KEY `visitors_department_id_foreign` (`department_id`),
  CONSTRAINT `visitors_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `visitors_purpose_id_foreign` FOREIGN KEY (`purpose_id`) REFERENCES `visit_purposes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitors`
--

LOCK TABLES `visitors` WRITE;
/*!40000 ALTER TABLE `visitors` DISABLE KEYS */;
INSERT INTO `visitors` VALUES (1,4,2,'Yoko Payne','Griffith Shaw','+1 (466) 696-7792','koty@mailinator.com',NULL,'Qui quis perferendis',NULL,'Pass-100001','2021-02-16','00:00:00','11:34:00','1','Rem eu numquam dolor',NULL,1,1,NULL,'2022-10-01 11:49:03','2022-10-01 11:49:03'),(2,3,4,'Ria Hodges','Lester Weber','+1 (864) 185-6339','vubypa@mailinator.com',NULL,'Voluptas id voluptas',NULL,'Pass-100002','2020-12-01','00:00:00','23:23:00','1','Consequatur repellen',NULL,1,1,1,'2022-10-01 11:49:30','2022-10-01 11:50:04'),(3,4,4,'Astra Good','Cora Garrison','+1 (873) 471-3381','dovejyjo@mailinator.com',NULL,'Reiciendis id dolore',NULL,'Pass-100003','2022-01-21','00:00:00','03:35:00','1','Qui saepe fuga Faci','logo_1664646638.jpg',1,1,1,'2022-10-01 11:50:38','2022-10-01 11:51:10'),(4,3,3,'Maile Chavez','Macy Harper','+1 (703) 918-4114','zyxisiw@mailinator.com',NULL,'Reprehenderit odio q',NULL,'Pass-100004','2022-10-01','17:51:00','19:55:00','4','Odio id corrupti h',NULL,1,1,NULL,'2022-10-01 11:51:56','2022-10-01 11:51:56'),(5,2,3,'Winifred Poole','Linus Guzman','+1 (477) 757-3411','fysel@mailinator.com',NULL,'A facere aut consequ',NULL,'Pass-100005','2020-09-16','00:00:00','08:55:00','2','Similique totam esse',NULL,1,1,1,'2022-10-01 11:52:20','2022-10-01 11:52:42'),(6,4,5,'Lacey Mitchell','Zane Jefferson','+1 (936) 186-6298','nywac@mailinator.com',NULL,'Quis aute culpa aut',NULL,'Pass-100006','2021-10-01','17:53:00','16:11:00','2','Vitae minima maiores',NULL,1,1,NULL,'2022-10-01 11:53:27','2022-10-01 11:53:27'),(7,4,1,'Kirk Kline','Coby Rivas','+1 (423) 673-6386','tife@mailinator.com',NULL,'Porro aliquam sunt e',NULL,'Pass-100007','2020-08-20','17:53:00','03:57:00','1','Placeat eiusmod qui',NULL,1,1,NULL,'2022-10-01 11:54:12','2022-10-01 11:54:12'),(8,3,2,'Stewart Padilla','Cairo Stanton','+1 (691) 309-1928','bavoc@mailinator.com',NULL,'Cupiditate dolor pro',NULL,'Pass-100008','2021-05-22','00:00:00','10:47:00','1','Eu eos lorem ab eos',NULL,1,1,NULL,'2022-10-01 11:54:40','2022-10-01 11:54:40'),(9,4,6,'Jayme Holder','Barrett Mckee','+1 (393) 487-6252','hixuter@mailinator.com',NULL,'Maxime anim qui iust',NULL,'Pass-100009','2021-09-05','00:00:00','10:26:00','1','Ex deserunt ea tenet',NULL,1,1,NULL,'2022-10-01 11:55:21','2022-10-01 11:55:21'),(10,1,3,'Alexander Santana','Todd Clayton','+1 (876) 649-1515','lypuhava@mailinator.com',NULL,'Ab Nam eaque distinc',NULL,'Pass-100010','2022-06-12','00:00:00',NULL,'1','Culpa sequi ad in ar','background-border_1664646980.png',1,1,NULL,'2022-10-01 11:56:20','2022-10-01 11:56:20'),(11,1,2,'Neville Golden','Dane Holloway','+1 (131) 631-6741','rumahorus@mailinator.com',NULL,'Recusandae Vero eiu',NULL,'Pass-100011','2022-06-13','00:00:00',NULL,'2','Repudiandae eaque sa','background-border_1664647025.png',1,1,NULL,'2022-10-01 11:57:05','2022-10-01 11:57:05'),(12,4,6,'Keegan Mosley','Hu Blanchard','+1 (869) 255-5927','xuhylal@mailinator.com',NULL,'Quia beatae quibusda',NULL,'Pass-100012','2022-08-01','17:57:00','18:15:28','1','Placeat itaque volu',NULL,1,1,1,'2022-10-01 11:58:15','2022-10-01 12:15:28'),(13,4,4,'Donovan Greer','Uma Fitzgerald','+1 (612) 392-8493','kaqi@mailinator.com',NULL,'Veniam ex quidem vo',NULL,'Pass-100013','2023-08-25','13:24:00','14:36:00','1','Quidem qui saepe qui',NULL,1,1,NULL,'2023-08-25 07:24:40','2023-08-25 07:24:40'),(14,3,1,'Timon Ayers','Mechelle Stein','+1 (757) 657-5032','kikalemufo@mailinator.com',NULL,'Pariatur Quia modi',NULL,'Pass-100014','2023-06-03','00:00:00','01:56:00','1','Facilis omnis aliqua',NULL,1,1,NULL,'2023-08-25 07:26:47','2023-08-25 07:26:47');
/*!40000 ALTER TABLE `visitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_events`
--

DROP TABLE IF EXISTS `web_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `attach` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_events`
--

LOCK TABLES `web_events` WRITE;
/*!40000 ALTER TABLE `web_events` DISABLE KEYS */;
INSERT INTO `web_events` VALUES (1,1,'Basic UI & UX Design for new development','basic-ui-ux-design-for-new-development','2027-04-14','04:36:00','Mirpur Dhaka','<p>The world of search engine optimization is complex and ever-changing, but you can easily understand the basics, and even a small amount of SEO knowledge can make a big difference. Free SEO education is also widely available on the web, including in guides like this! (Woohoo!) This guide is designed to describe all major aspects of SEO, from finding the terms and phrases (keywords) that can generate qualified traffic to your website, to making your site friendly to search engines, to building links and marketing the unique value of your site.Etiam pharetra erat sed fermentum feugiat velit mauris egestas quam ut erat justo.</p>\r\n<p>Fusce eleifend donec sapien sed phase lusa pellentesque lacus.Vivamus lorem arcu semper duiac. Cras ornare arcu avamus nda leo Etiam ind arcu. Morbi justo mauris tempus pharetra interdum at congue semper purus. Lorem ipsum dolor sit.The world of search engine optimization is complex and ever-changing, but you can easily understand the basics.</p>\r\n<p>Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy text of the printing.</p>\r\n<p>&nbsp;</p>','evn_img_4_1692916701.jpg',1,'2023-08-24 16:38:22','2023-08-24 16:38:22'),(2,1,'Learning Network Webinars for Music Teachers','learning-network-webinars-for-music-teachers','2026-11-20','00:39:00','Rangpur, Bangladesh','<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>','evn_img_2_1692916827.jpg',1,'2023-08-24 16:40:12','2023-08-24 16:40:27'),(3,1,'Digital Art & 3D Model – a future for film company','digital-art-3d-model-a-future-for-film-company','2025-09-24','02:41:00','Mirpur Dhaka','<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>\r\n<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n<p>&nbsp;</p>','evn_img_5_1692916908.jpg',1,'2023-08-24 16:41:48','2023-08-24 16:43:36');
/*!40000 ALTER TABLE `web_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_shift_types`
--

DROP TABLE IF EXISTS `work_shift_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_shift_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_shift_types_title_unique` (`title`),
  UNIQUE KEY `work_shift_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_shift_types`
--

LOCK TABLES `work_shift_types` WRITE;
/*!40000 ALTER TABLE `work_shift_types` DISABLE KEYS */;
INSERT INTO `work_shift_types` VALUES (1,'Morning','morning',NULL,1,NULL,NULL),(2,'Evening','evening',NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `work_shift_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'campus365lms'
--

--
-- Dumping routines for database 'campus365lms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-29  2:14:20
